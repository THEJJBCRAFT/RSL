package de.rsl.ranks.hook;

import de.rsl.ranks.RSLRanksPlugin;
import de.rsl.ranks.permission.PermissionManager;
import de.rsl.ranks.rank.Rank;
import de.rsl.ranks.rank.RankManager;
import de.rsl.ranks.user.UserData;
import de.rsl.ranks.user.UserManager;
import net.milkbowl.vault.chat.Chat;
import net.milkbowl.vault.permission.Permission;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

import java.util.Locale;

public class VaultHook {
    private final RSLRanksPlugin plugin;
    private final RSLVaultPermission permissionProvider;
    private final RSLVaultChat chatProvider;

    public VaultHook(RSLRanksPlugin plugin, RankManager rankManager, UserManager userManager,
                     PermissionManager permissionManager) {
        this.plugin = plugin;
        this.permissionProvider = new RSLVaultPermission(plugin, rankManager, userManager, permissionManager);
        this.chatProvider = new RSLVaultChat(permissionProvider, rankManager, userManager);
    }

    public void register() {
        Bukkit.getServicesManager().register(Permission.class, permissionProvider, plugin, ServicePriority.Highest);
        Bukkit.getServicesManager().register(Chat.class, chatProvider, plugin, ServicePriority.Highest);
        plugin.getLogger().info("Vault Permission and Chat providers registered.");
    }

    public void unregister() {
        Bukkit.getServicesManager().unregister(Permission.class, permissionProvider);
        Bukkit.getServicesManager().unregister(Chat.class, chatProvider);
    }

    private static class RSLVaultPermission extends Permission {
        private final RSLRanksPlugin plugin;
        private final RankManager rankManager;
        private final UserManager userManager;
        private final PermissionManager permissionManager;

        private RSLVaultPermission(RSLRanksPlugin plugin, RankManager rankManager, UserManager userManager,
                                   PermissionManager permissionManager) {
            this.plugin = plugin;
            this.rankManager = rankManager;
            this.userManager = userManager;
            this.permissionManager = permissionManager;
            super.plugin = plugin;
        }

        @Override
        public String getName() {
            return "RSLRanks";
        }

        @Override
        public boolean isEnabled() {
            return plugin.isEnabled();
        }

        @Override
        public boolean hasSuperPermsCompat() {
            return true;
        }

        @Override
        @Deprecated
        public boolean playerHas(String world, String player, String permission) {
            return permissionManager.hasPermission(resolve(player), permission);
        }

        @Override
        @Deprecated
        public boolean playerAdd(String world, String player, String permission) {
            userManager.addPermission(resolve(player), permission);
            return true;
        }

        @Override
        @Deprecated
        public boolean playerRemove(String world, String player, String permission) {
            userManager.removePermission(resolve(player), permission);
            return true;
        }

        @Override
        public boolean groupHas(String world, String group, String permission) {
            return rankManager.rankHasPermission(group, permission);
        }

        @Override
        public boolean groupAdd(String world, String group, String permission) {
            if (!rankManager.exists(group)) {
                return false;
            }
            rankManager.addPermission(group, permission);
            return true;
        }

        @Override
        public boolean groupRemove(String world, String group, String permission) {
            if (!rankManager.exists(group)) {
                return false;
            }
            rankManager.removePermission(group, permission);
            return true;
        }

        @Override
        @Deprecated
        public boolean playerInGroup(String world, String player, String group) {
            return userManager.getOrCreate(resolve(player)).getRank().equalsIgnoreCase(group);
        }

        @Override
        @Deprecated
        public boolean playerAddGroup(String world, String player, String group) {
            if (!rankManager.exists(group)) {
                return false;
            }
            userManager.setRank(resolve(player), group);
            return true;
        }

        @Override
        @Deprecated
        public boolean playerRemoveGroup(String world, String player, String group) {
            OfflinePlayer offlinePlayer = resolve(player);
            UserData data = userManager.getOrCreate(offlinePlayer);
            if (data.getRank().equalsIgnoreCase(group)) {
                userManager.setRank(offlinePlayer, rankManager.getDefaultRankName());
                return true;
            }
            return false;
        }

        @Override
        @Deprecated
        public String[] getPlayerGroups(String world, String player) {
            return new String[]{getPrimaryGroup(world, player)};
        }

        @Override
        @Deprecated
        public String getPrimaryGroup(String world, String player) {
            return userManager.getOrCreate(resolve(player)).getRank();
        }

        @Override
        public String[] getGroups() {
            return rankManager.getSortedRanks().stream().map(Rank::getName).toArray(String[]::new);
        }

        @Override
        public boolean hasGroupSupport() {
            return true;
        }

        @SuppressWarnings("deprecation")
        private OfflinePlayer resolve(String player) {
            return userManager.resolvePlayer(player);
        }
    }

    private static class RSLVaultChat extends Chat {
        private final RankManager rankManager;
        private final UserManager userManager;

        private RSLVaultChat(Permission permissions, RankManager rankManager, UserManager userManager) {
            super(permissions);
            this.rankManager = rankManager;
            this.userManager = userManager;
        }

        @Override
        public String getName() {
            return "RSLRanks";
        }

        @Override
        public boolean isEnabled() {
            return true;
        }

        @Override
        @Deprecated
        public String getPlayerPrefix(String world, String player) {
            Rank rank = rankFor(player);
            return rank == null ? "" : rank.getPrefix();
        }

        @Override
        @Deprecated
        public void setPlayerPrefix(String world, String player, String prefix) {
            // RSLRanks stores prefixes on groups, not on individual players.
        }

        @Override
        @Deprecated
        public String getPlayerSuffix(String world, String player) {
            Rank rank = rankFor(player);
            return rank == null ? "" : rank.getSuffix();
        }

        @Override
        @Deprecated
        public void setPlayerSuffix(String world, String player, String suffix) {
            // RSLRanks stores suffixes on groups, not on individual players.
        }

        @Override
        public String getGroupPrefix(String world, String group) {
            Rank rank = rankManager.getRank(group);
            return rank == null ? "" : rank.getPrefix();
        }

        @Override
        public void setGroupPrefix(String world, String group, String prefix) {
            if (rankManager.exists(group)) {
                rankManager.setPrefix(group, prefix);
            }
        }

        @Override
        public String getGroupSuffix(String world, String group) {
            Rank rank = rankManager.getRank(group);
            return rank == null ? "" : rank.getSuffix();
        }

        @Override
        public void setGroupSuffix(String world, String group, String suffix) {
            if (rankManager.exists(group)) {
                rankManager.setSuffix(group, suffix);
            }
        }

        @Override
        @Deprecated
        public int getPlayerInfoInteger(String world, String player, String node, int defaultValue) {
            Rank rank = rankFor(player);
            if (rank != null && node.equalsIgnoreCase("priority")) {
                return rank.getPriority();
            }
            return defaultValue;
        }

        @Override
        @Deprecated
        public void setPlayerInfoInteger(String world, String player, String node, int value) {
        }

        @Override
        public int getGroupInfoInteger(String world, String group, String node, int defaultValue) {
            Rank rank = rankManager.getRank(group);
            if (rank != null && node.equalsIgnoreCase("priority")) {
                return rank.getPriority();
            }
            return defaultValue;
        }

        @Override
        public void setGroupInfoInteger(String world, String group, String node, int value) {
            if (node.equalsIgnoreCase("priority") && rankManager.exists(group)) {
                rankManager.setPriority(group, value);
            }
        }

        @Override
        @Deprecated
        public double getPlayerInfoDouble(String world, String player, String node, double defaultValue) {
            return defaultValue;
        }

        @Override
        @Deprecated
        public void setPlayerInfoDouble(String world, String player, String node, double value) {
        }

        @Override
        public double getGroupInfoDouble(String world, String group, String node, double defaultValue) {
            return defaultValue;
        }

        @Override
        public void setGroupInfoDouble(String world, String group, String node, double value) {
        }

        @Override
        @Deprecated
        public boolean getPlayerInfoBoolean(String world, String player, String node, boolean defaultValue) {
            return defaultValue;
        }

        @Override
        @Deprecated
        public void setPlayerInfoBoolean(String world, String player, String node, boolean value) {
        }

        @Override
        public boolean getGroupInfoBoolean(String world, String group, String node, boolean defaultValue) {
            return defaultValue;
        }

        @Override
        public void setGroupInfoBoolean(String world, String group, String node, boolean value) {
        }

        @Override
        @Deprecated
        public String getPlayerInfoString(String world, String player, String node, String defaultValue) {
            Rank rank = rankFor(player);
            if (rank == null) {
                return defaultValue;
            }
            return rankString(rank, node, defaultValue);
        }

        @Override
        @Deprecated
        public void setPlayerInfoString(String world, String player, String node, String value) {
        }

        @Override
        public String getGroupInfoString(String world, String group, String node, String defaultValue) {
            Rank rank = rankManager.getRank(group);
            if (rank == null) {
                return defaultValue;
            }
            return rankString(rank, node, defaultValue);
        }

        @Override
        public void setGroupInfoString(String world, String group, String node, String value) {
            String lowered = node.toLowerCase(Locale.ROOT);
            if (lowered.equals("prefix") && rankManager.exists(group)) {
                rankManager.setPrefix(group, value);
            } else if (lowered.equals("suffix") && rankManager.exists(group)) {
                rankManager.setSuffix(group, value);
            }
        }

        private String rankString(Rank rank, String node, String defaultValue) {
            return switch (node.toLowerCase(Locale.ROOT)) {
                case "rank", "group" -> rank.getName();
                case "displayname", "display-name" -> rank.getDisplayName();
                case "prefix" -> rank.getPrefix();
                case "suffix" -> rank.getSuffix();
                case "color" -> rank.getColor();
                default -> defaultValue;
            };
        }

        @SuppressWarnings("deprecation")
        private Rank rankFor(String player) {
            OfflinePlayer offlinePlayer = userManager.resolvePlayer(player);
            UserData data = userManager.getOrCreate(offlinePlayer);
            return rankManager.getRank(data.getRank());
        }
    }

}

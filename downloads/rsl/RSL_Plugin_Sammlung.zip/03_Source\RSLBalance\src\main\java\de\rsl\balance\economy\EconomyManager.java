package de.rsl.balance.economy;

import de.rsl.balance.RSLBalancePlugin;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class EconomyManager {
    private final RSLBalancePlugin plugin;
    private final File file;
    private final Map<UUID, EconomyUser> balances = new LinkedHashMap<>();

    public EconomyManager(RSLBalancePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
    }

    public void load() {
        if (!file.exists()) {
            plugin.saveResource("balances.yml", false);
        }

        balances.clear();
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("balances");
        if (section == null) {
            return;
        }

        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String lastName = section.getString(key + ".last-name", "");
                double balance = section.getDouble(key + ".balance", startingBalance());
                balances.put(uuid, new EconomyUser(uuid, lastName, Math.max(0.0D, balance)));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Invalid balance UUID in balances.yml: " + key);
            }
        }
    }

    public void save() {
        YamlConfiguration config = new YamlConfiguration();
        ConfigurationSection section = config.createSection("balances");
        for (EconomyUser user : balances.values()) {
            String path = user.uuid().toString();
            section.set(path + ".last-name", user.lastName());
            section.set(path + ".balance", user.balance());
        }

        try {
            config.save(file);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save balances.yml: " + exception.getMessage());
        }
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("economy.enabled", true);
    }

    public boolean createAccount(OfflinePlayer player) {
        UUID uuid = player.getUniqueId();
        String lastName = nameOf(player);
        EconomyUser existing = balances.get(uuid);
        if (existing != null) {
            balances.put(uuid, new EconomyUser(uuid, lastName, existing.balance()));
            return false;
        }

        balances.put(uuid, new EconomyUser(uuid, lastName, startingBalance()));
        save();
        return true;
    }

    public boolean hasAccount(OfflinePlayer player) {
        return balances.containsKey(player.getUniqueId());
    }

    public double getBalance(OfflinePlayer player) {
        createAccount(player);
        return balances.get(player.getUniqueId()).balance();
    }

    public boolean has(OfflinePlayer player, double amount) {
        return getBalance(player) >= amount;
    }

    public double setBalance(OfflinePlayer player, double amount) {
        UUID uuid = player.getUniqueId();
        double safeAmount = Math.max(0.0D, amount);
        balances.put(uuid, new EconomyUser(uuid, nameOf(player), safeAmount));
        save();
        return safeAmount;
    }

    public double deposit(OfflinePlayer player, double amount) {
        return setBalance(player, getBalance(player) + Math.max(0.0D, amount));
    }

    public double withdraw(OfflinePlayer player, double amount) {
        return setBalance(player, getBalance(player) - Math.max(0.0D, amount));
    }

    public String format(double amount) {
        String pattern = plugin.getConfig().getString("economy.format", "#,##0.00");
        String formatted = new DecimalFormat(pattern).format(amount);
        if (!plugin.getConfig().getBoolean("economy.show-currency-in-format", true)) {
            return formatted;
        }
        return formatted + " " + (Math.abs(amount - 1.0D) < 0.00001D ? currencySingular() : currencyPlural());
    }

    public String currencySingular() {
        return plugin.getConfig().getString("economy.currency-singular", "RSL Coin");
    }

    public String currencyPlural() {
        return plugin.getConfig().getString("economy.currency-plural", "RSL Coins");
    }

    public double startingBalance() {
        return Math.max(0.0D, plugin.getConfig().getDouble("economy.starting-balance", 0.0D));
    }

    @SuppressWarnings("deprecation")
    public OfflinePlayer resolvePlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }

        Optional<EconomyUser> saved = balances.values().stream()
                .filter(user -> user.lastName().equalsIgnoreCase(name))
                .findFirst();
        if (saved.isPresent()) {
            return Bukkit.getOfflinePlayer(saved.get().uuid());
        }

        return Bukkit.getOfflinePlayer(name);
    }

    private String nameOf(OfflinePlayer player) {
        String name = player.getName();
        return name == null ? "" : name;
    }

    private record EconomyUser(UUID uuid, String lastName, double balance) {
    }
}

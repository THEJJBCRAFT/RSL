package de.rsl.balance.hook;

import de.rsl.balance.RSLBalancePlugin;
import de.rsl.balance.economy.EconomyManager;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

import java.util.Collections;
import java.util.List;

public class VaultEconomyHook {
    private final RSLBalancePlugin plugin;
    private final RSLEconomyProvider economyProvider;

    public VaultEconomyHook(RSLBalancePlugin plugin, EconomyManager economyManager) {
        this.plugin = plugin;
        this.economyProvider = new RSLEconomyProvider(plugin, economyManager);
    }

    public void register() {
        Bukkit.getServicesManager().register(Economy.class, economyProvider, plugin, ServicePriority.Highest);
        plugin.getLogger().info("Vault Economy provider registered.");
    }

    public void unregister() {
        Bukkit.getServicesManager().unregister(Economy.class, economyProvider);
    }

    private static class RSLEconomyProvider implements Economy {
        private final RSLBalancePlugin plugin;
        private final EconomyManager economyManager;

        private RSLEconomyProvider(RSLBalancePlugin plugin, EconomyManager economyManager) {
            this.plugin = plugin;
            this.economyManager = economyManager;
        }

        @Override
        public boolean isEnabled() {
            return plugin.isEnabled() && economyManager.isEnabled();
        }

        @Override
        public String getName() {
            return "RSLBalance";
        }

        @Override
        public boolean hasBankSupport() {
            return false;
        }

        @Override
        public int fractionalDigits() {
            return 2;
        }

        @Override
        public String format(double amount) {
            return economyManager.format(amount);
        }

        @Override
        public String currencyNamePlural() {
            return economyManager.currencyPlural();
        }

        @Override
        public String currencyNameSingular() {
            return economyManager.currencySingular();
        }

        @Override
        @Deprecated
        public boolean hasAccount(String playerName) {
            return economyManager.hasAccount(economyManager.resolvePlayer(playerName));
        }

        @Override
        public boolean hasAccount(OfflinePlayer player) {
            return economyManager.hasAccount(player);
        }

        @Override
        @Deprecated
        public boolean hasAccount(String playerName, String worldName) {
            return hasAccount(playerName);
        }

        @Override
        public boolean hasAccount(OfflinePlayer player, String worldName) {
            return hasAccount(player);
        }

        @Override
        @Deprecated
        public double getBalance(String playerName) {
            return economyManager.getBalance(economyManager.resolvePlayer(playerName));
        }

        @Override
        public double getBalance(OfflinePlayer player) {
            return economyManager.getBalance(player);
        }

        @Override
        @Deprecated
        public double getBalance(String playerName, String world) {
            return getBalance(playerName);
        }

        @Override
        public double getBalance(OfflinePlayer player, String world) {
            return getBalance(player);
        }

        @Override
        @Deprecated
        public boolean has(String playerName, double amount) {
            return economyManager.has(economyManager.resolvePlayer(playerName), amount);
        }

        @Override
        public boolean has(OfflinePlayer player, double amount) {
            return economyManager.has(player, amount);
        }

        @Override
        @Deprecated
        public boolean has(String playerName, String worldName, double amount) {
            return has(playerName, amount);
        }

        @Override
        public boolean has(OfflinePlayer player, String worldName, double amount) {
            return has(player, amount);
        }

        @Override
        @Deprecated
        public EconomyResponse withdrawPlayer(String playerName, double amount) {
            return withdrawPlayer(economyManager.resolvePlayer(playerName), amount);
        }

        @Override
        public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
            if (amount < 0.0D) {
                return response(amount, getBalance(player), EconomyResponse.ResponseType.FAILURE, "Cannot withdraw negative amount.");
            }
            if (!has(player, amount)) {
                return response(amount, getBalance(player), EconomyResponse.ResponseType.FAILURE, "Not enough money.");
            }
            return response(amount, economyManager.withdraw(player, amount), EconomyResponse.ResponseType.SUCCESS, null);
        }

        @Override
        @Deprecated
        public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
            return withdrawPlayer(playerName, amount);
        }

        @Override
        public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
            return withdrawPlayer(player, amount);
        }

        @Override
        @Deprecated
        public EconomyResponse depositPlayer(String playerName, double amount) {
            return depositPlayer(economyManager.resolvePlayer(playerName), amount);
        }

        @Override
        public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
            if (amount < 0.0D) {
                return response(amount, getBalance(player), EconomyResponse.ResponseType.FAILURE, "Cannot deposit negative amount.");
            }
            return response(amount, economyManager.deposit(player, amount), EconomyResponse.ResponseType.SUCCESS, null);
        }

        @Override
        @Deprecated
        public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
            return depositPlayer(playerName, amount);
        }

        @Override
        public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
            return depositPlayer(player, amount);
        }

        @Override
        @Deprecated
        public EconomyResponse createBank(String name, String player) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse createBank(String name, OfflinePlayer player) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse deleteBank(String name) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse bankBalance(String name) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse bankHas(String name, double amount) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse bankWithdraw(String name, double amount) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse bankDeposit(String name, double amount) {
            return bankUnsupported();
        }

        @Override
        @Deprecated
        public EconomyResponse isBankOwner(String name, String playerName) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
            return bankUnsupported();
        }

        @Override
        @Deprecated
        public EconomyResponse isBankMember(String name, String playerName) {
            return bankUnsupported();
        }

        @Override
        public EconomyResponse isBankMember(String name, OfflinePlayer player) {
            return bankUnsupported();
        }

        @Override
        public List<String> getBanks() {
            return Collections.emptyList();
        }

        @Override
        @Deprecated
        public boolean createPlayerAccount(String playerName) {
            return economyManager.createAccount(economyManager.resolvePlayer(playerName));
        }

        @Override
        public boolean createPlayerAccount(OfflinePlayer player) {
            return economyManager.createAccount(player);
        }

        @Override
        @Deprecated
        public boolean createPlayerAccount(String playerName, String worldName) {
            return createPlayerAccount(playerName);
        }

        @Override
        public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
            return createPlayerAccount(player);
        }

        private EconomyResponse bankUnsupported() {
            return response(0.0D, 0.0D, EconomyResponse.ResponseType.NOT_IMPLEMENTED, "RSLBalance does not support banks.");
        }

        private EconomyResponse response(double amount, double balance, EconomyResponse.ResponseType type, String error) {
            return new EconomyResponse(amount, balance, type, error);
        }
    }
}

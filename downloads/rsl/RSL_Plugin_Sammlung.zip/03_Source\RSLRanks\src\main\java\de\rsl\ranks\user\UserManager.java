package de.rsl.ranks.user;

import de.rsl.ranks.RSLRanksPlugin;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class UserManager {
    private final RSLRanksPlugin plugin;
    private final File file;
    private final Map<UUID, UserData> users = new ConcurrentHashMap<>();
    private FileConfiguration config;

    public UserManager(RSLRanksPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        if (!file.exists()) {
            plugin.saveResource("players.yml", false);
        }
    }

    public void load() {
        users.clear();
        config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("users");
        if (section == null) {
            return;
        }

        for (String uuidText : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidText);
                String path = "users." + uuidText + ".";
                String lastName = config.getString(path + "last-name", "");
                String rank = normalize(config.getString(path + "rank", plugin.getRankManager().getDefaultRankName()));
                users.put(uuid, new UserData(uuid, lastName, rank,
                        new LinkedHashSet<>(config.getStringList(path + "extra-permissions"))));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("Invalid UUID in players.yml: " + uuidText);
            }
        }
    }

    public void save() {
        config.set("users", null);
        for (UserData user : users.values()) {
            String path = "users." + user.getUuid() + ".";
            config.set(path + "last-name", user.getLastName());
            config.set(path + "rank", user.getRank());
            config.set(path + "extra-permissions", user.getExtraPermissions().stream().toList());
        }
        try {
            config.save(file);
        } catch (IOException exception) {
            plugin.getLogger().severe("Could not save players.yml: " + exception.getMessage());
        }
    }

    public UserData getOrCreate(OfflinePlayer player) {
        UserData data = users.computeIfAbsent(player.getUniqueId(), uuid ->
                new UserData(uuid, safeName(player), plugin.getRankManager().getDefaultRankName(), new LinkedHashSet<>()));
        if (player.getName() != null && !player.getName().isBlank()) {
            data.setLastName(player.getName());
        }
        if (!plugin.getRankManager().exists(data.getRank())) {
            data.setRank(plugin.getRankManager().getDefaultRankName());
        }
        return data;
    }

    public Optional<UserData> findStoredByName(String name) {
        String lowered = name.toLowerCase(Locale.ROOT);
        return users.values().stream()
                .filter(user -> user.getLastName() != null && user.getLastName().toLowerCase(Locale.ROOT).equals(lowered))
                .findFirst();
    }

    @SuppressWarnings("deprecation")
    public OfflinePlayer resolvePlayer(String name) {
        OfflinePlayer online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        Optional<UserData> stored = findStoredByName(name);
        if (stored.isPresent()) {
            return Bukkit.getOfflinePlayer(stored.get().getUuid());
        }
        return Bukkit.getOfflinePlayer(name);
    }

    public Collection<UserData> getUsers() {
        return users.values();
    }

    public void setRank(OfflinePlayer player, String rank) {
        UserData data = getOrCreate(player);
        data.setRank(normalize(rank));
        save();
    }

    public void addPermission(OfflinePlayer player, String permission) {
        UserData data = getOrCreate(player);
        data.addExtraPermission(permission);
        save();
    }

    public void removePermission(OfflinePlayer player, String permission) {
        UserData data = getOrCreate(player);
        data.removeExtraPermission(permission);
        save();
    }

    private String safeName(OfflinePlayer player) {
        return player.getName() == null ? player.getUniqueId().toString() : player.getName();
    }

    private String normalize(String value) {
        return value == null ? plugin.getRankManager().getDefaultRankName() : value.toLowerCase(Locale.ROOT);
    }
}

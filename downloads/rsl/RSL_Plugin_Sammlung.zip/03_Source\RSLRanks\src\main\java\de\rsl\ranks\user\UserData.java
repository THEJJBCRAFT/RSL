package de.rsl.ranks.user;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public class UserData {
    private final UUID uuid;
    private String lastName;
    private String rank;
    private final Set<String> extraPermissions;

    public UserData(UUID uuid, String lastName, String rank, Set<String> extraPermissions) {
        this.uuid = uuid;
        this.lastName = lastName;
        this.rank = rank;
        this.extraPermissions = new LinkedHashSet<>(extraPermissions);
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public Set<String> getExtraPermissions() {
        return Collections.unmodifiableSet(extraPermissions);
    }

    public void addExtraPermission(String permission) {
        extraPermissions.add(permission);
    }

    public void removeExtraPermission(String permission) {
        extraPermissions.removeIf(existing -> existing.equalsIgnoreCase(permission));
    }
}

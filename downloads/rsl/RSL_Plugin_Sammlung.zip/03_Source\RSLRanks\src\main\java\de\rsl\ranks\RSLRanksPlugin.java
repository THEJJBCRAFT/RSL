package de.rsl.ranks;

import de.rsl.ranks.command.RankCommand;
import de.rsl.ranks.hook.PlaceholderHook;
import de.rsl.ranks.hook.VaultHook;
import de.rsl.ranks.permission.PermissionManager;
import de.rsl.ranks.rank.Rank;
import de.rsl.ranks.rank.RankManager;
import de.rsl.ranks.user.UserData;
import de.rsl.ranks.user.UserManager;
import de.rsl.ranks.util.ColorUtil;
import de.rsl.ranks.util.ConfigUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public class RSLRanksPlugin extends JavaPlugin {
    private ConfigUtil messages;
    private RankManager rankManager;
    private UserManager userManager;
    private PermissionManager permissionManager;
    private VaultHook vaultHook;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new ConfigUtil(this, "messages.yml");

        rankManager = new RankManager(this);
        rankManager.load();
        userManager = new UserManager(this);
        userManager.load();
        permissionManager = new PermissionManager(this, rankManager, userManager);

        Bukkit.getPluginManager().registerEvents(permissionManager, this);

        RankCommand rankCommand = new RankCommand(this);
        PluginCommand command = getCommand("rank");
        if (command != null) {
            command.setExecutor(rankCommand);
            command.setTabCompleter(rankCommand);
        }
        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            vaultHook = new VaultHook(this, rankManager, userManager, permissionManager);
            vaultHook.register();
        } else {
            getLogger().info("Vault not found, Vault hook disabled.");
        }

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderHook(this).register();
            getLogger().info("PlaceholderAPI hook enabled.");
        } else {
            getLogger().info("PlaceholderAPI not found, placeholders disabled.");
        }

        permissionManager.reloadOnlinePlayers();
        getLogger().info("RSLRanks enabled.");
    }

    @Override
    public void onDisable() {
        if (vaultHook != null) {
            vaultHook.unregister();
        }
        if (permissionManager != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                permissionManager.remove(player);
            }
        }
        if (userManager != null) {
            userManager.save();
        }
    }

    public void reloadAll() {
        reloadConfig();
        messages.reload();
        rankManager.load();
        userManager.load();
        permissionManager.reloadOnlinePlayers();
    }

    public void updateOwnTabName(Player player) {
        if (!getConfig().getBoolean("enable-own-tab-format", false)) {
            return;
        }
        if (Bukkit.getPluginManager().getPlugin("TAB") != null) {
            return;
        }
        UserData data = userManager.getOrCreate(player);
        Rank rank = rankManager.getRank(data.getRank());
        if (rank == null) {
            return;
        }
        String listName = ColorUtil.color(rank.getPrefix() + rank.getColor() + player.getName() + rank.getSuffix());
        player.setPlayerListName(listName);
    }

    public void send(org.bukkit.command.CommandSender sender, String key, Map<String, String> replacements) {
        String message = messages.message(key);
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            message = message.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        sender.sendMessage(message);
    }

    public void send(org.bukkit.command.CommandSender sender, String key) {
        send(sender, key, Map.of());
    }

    public ConfigUtil getMessages() {
        return messages;
    }

    public RankManager getRankManager() {
        return rankManager;
    }

    public UserManager getUserManager() {
        return userManager;
    }

    public PermissionManager getPermissionManager() {
        return permissionManager;
    }
}

package de.rsl.ranks.rank;

import de.rsl.ranks.RSLRanksPlugin;
import de.rsl.ranks.permission.PermissionManager;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class RankManager {
    private final RSLRanksPlugin plugin;
    private final Map<String, Rank> ranks = new LinkedHashMap<>();

    public RankManager(RSLRanksPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        ranks.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("ranks");
        if (section == null) {
            plugin.getLogger().warning("No ranks section found in config.yml");
            return;
        }

        for (String key : section.getKeys(false)) {
            String path = "ranks." + key + ".";
            Set<String> permissions = new LinkedHashSet<>(plugin.getConfig().getStringList(path + "permissions"));
            Set<String> inherits = new LinkedHashSet<>();
            for (String parent : plugin.getConfig().getStringList(path + "inherits")) {
                inherits.add(normalize(parent));
            }

            Rank rank = new Rank(
                    normalize(key),
                    plugin.getConfig().getString(path + "displayName", key),
                    plugin.getConfig().getString(path + "prefix", ""),
                    plugin.getConfig().getString(path + "suffix", ""),
                    plugin.getConfig().getString(path + "color", "&7"),
                    plugin.getConfig().getInt(path + "priority", 100),
                    permissions,
                    inherits
            );
            ranks.put(rank.getName(), rank);
        }
    }

    public String getDefaultRankName() {
        String configured = normalize(plugin.getConfig().getString("default-rank", "spieler"));
        return ranks.containsKey(configured) ? configured : firstRankName();
    }

    private String firstRankName() {
        return ranks.isEmpty() ? "spieler" : ranks.values().iterator().next().getName();
    }

    public Rank getRank(String name) {
        if (name == null) {
            return null;
        }
        return ranks.get(normalize(name));
    }

    public boolean exists(String name) {
        return getRank(name) != null;
    }

    public Collection<Rank> getRanks() {
        return ranks.values();
    }

    public List<Rank> getSortedRanks() {
        List<Rank> sorted = new ArrayList<>(ranks.values());
        sorted.sort(Comparator.comparingInt(Rank::getPriority).thenComparing(Rank::getName));
        return sorted;
    }

    public Set<String> resolvePermissions(String rankName) {
        Set<String> permissions = new LinkedHashSet<>();
        collectPermissions(normalize(rankName), permissions, new LinkedHashSet<>(), new LinkedHashSet<>());
        return permissions;
    }

    private void collectPermissions(String rankName, Set<String> permissions, Set<String> visiting, Set<String> visited) {
        if (visited.contains(rankName) || visiting.contains(rankName)) {
            return;
        }
        Rank rank = ranks.get(rankName);
        if (rank == null) {
            return;
        }

        visiting.add(rankName);
        for (String parent : rank.getInherits()) {
            collectPermissions(parent, permissions, visiting, visited);
        }
        permissions.addAll(rank.getPermissions());
        visiting.remove(rankName);
        visited.add(rankName);
    }

    public boolean rankHasPermission(String rankName, String permission) {
        for (String node : resolvePermissions(rankName)) {
            if (PermissionManager.matches(node, permission)) {
                return true;
            }
        }
        return false;
    }

    public void createRank(String name) {
        String rankName = normalize(name);
        String path = "ranks." + rankName + ".";
        plugin.getConfig().set(path + "displayName", name);
        plugin.getConfig().set(path + "prefix", "&7" + name + " &7");
        plugin.getConfig().set(path + "suffix", "");
        plugin.getConfig().set(path + "color", "&7");
        plugin.getConfig().set(path + "priority", 100);
        plugin.getConfig().set(path + "permissions", new ArrayList<String>());
        plugin.getConfig().set(path + "inherits", new ArrayList<String>());
        plugin.saveConfig();
        load();
    }

    public void deleteRank(String name) {
        plugin.getConfig().set("ranks." + normalize(name), null);
        plugin.saveConfig();
        load();
    }

    public void setPrefix(String name, String prefix) {
        plugin.getConfig().set("ranks." + normalize(name) + ".prefix", prefix);
        plugin.saveConfig();
        load();
    }

    public void setSuffix(String name, String suffix) {
        plugin.getConfig().set("ranks." + normalize(name) + ".suffix", suffix);
        plugin.saveConfig();
        load();
    }

    public void setPriority(String name, int priority) {
        plugin.getConfig().set("ranks." + normalize(name) + ".priority", priority);
        plugin.saveConfig();
        load();
    }

    public void addPermission(String name, String permission) {
        String path = "ranks." + normalize(name) + ".permissions";
        List<String> permissions = new ArrayList<>(plugin.getConfig().getStringList(path));
        if (!permissions.contains(permission)) {
            permissions.add(permission);
        }
        plugin.getConfig().set(path, permissions);
        plugin.saveConfig();
        load();
    }

    public void removePermission(String name, String permission) {
        String path = "ranks." + normalize(name) + ".permissions";
        List<String> permissions = new ArrayList<>(plugin.getConfig().getStringList(path));
        permissions.removeIf(existing -> existing.equalsIgnoreCase(permission));
        plugin.getConfig().set(path, permissions);
        plugin.saveConfig();
        load();
    }

    public String tabGroupOrder() {
        List<String> names = new ArrayList<>();
        for (Rank rank : getSortedRanks()) {
            names.add(rank.getName());
        }
        return String.join(",", names);
    }

    private String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }
}

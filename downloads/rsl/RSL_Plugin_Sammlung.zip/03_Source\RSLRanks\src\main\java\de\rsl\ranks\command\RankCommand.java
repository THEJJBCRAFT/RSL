package de.rsl.ranks.command;

import de.rsl.ranks.RSLRanksPlugin;
import de.rsl.ranks.rank.Rank;
import de.rsl.ranks.user.UserData;
import de.rsl.ranks.util.ColorUtil;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class RankCommand implements CommandExecutor, TabCompleter {
    private final RSLRanksPlugin plugin;

    public RankCommand(RSLRanksPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }

        String root = args[0].toLowerCase(Locale.ROOT);
        if (root.equals("reload")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            plugin.reloadAll();
            plugin.send(sender, "reloaded");
            return true;
        }
        if (root.equals("tabconfig")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            sendTabConfig(sender);
            return true;
        }
        if (root.equals("user")) {
            return handleUser(sender, args);
        }
        if (root.equals("group")) {
            return handleGroup(sender, args);
        }

        plugin.send(sender, "unknown-command");
        return true;
    }

    private boolean handleUser(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        if (args.length < 3) {
            plugin.send(sender, "usage-user-info");
            return true;
        }

        OfflinePlayer target = plugin.getUserManager().resolvePlayer(args[1]);
        String action = args[2].toLowerCase(Locale.ROOT);

        if (action.equals("set")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-user-set");
                return true;
            }
            String rankName = args[3].toLowerCase(Locale.ROOT);
            if (!plugin.getRankManager().exists(rankName)) {
                plugin.send(sender, "rank-not-found", Map.of("rank", rankName));
                return true;
            }
            if (!plugin.getPermissionManager().canSetRank(sender, rankName)) {
                plugin.send(sender, "rank-set-denied", Map.of("rank", rankName));
                return true;
            }
            plugin.getUserManager().setRank(target, rankName);
            reloadIfOnline(target);
            plugin.send(sender, "rank-set", Map.of("player", displayName(target), "rank", rankName));
            return true;
        }

        if (action.equals("info")) {
            UserData data = plugin.getUserManager().getOrCreate(target);
            Rank rank = plugin.getRankManager().getRank(data.getRank());
            sender.sendMessage(ColorUtil.color("&8&m----------------&r &cRSLRanks &8&m----------------"));
            sender.sendMessage(ColorUtil.color("&7Spieler: &e" + displayName(target)));
            sender.sendMessage(ColorUtil.color("&7Rang: &e" + data.getRank()));
            if (rank != null) {
                sender.sendMessage(ColorUtil.color("&7Prefix: &r" + rank.getPrefix()));
                sender.sendMessage(ColorUtil.color("&7Priority: &e" + rank.getPriority()));
            }
            sender.sendMessage(ColorUtil.color("&7Extra Permissions: &e" + String.join(", ", data.getExtraPermissions())));
            return true;
        }

        if (action.equals("addperm") || action.equals("removeperm")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-user-perm");
                return true;
            }
            String permission = args[3];
            if (action.equals("addperm")) {
                plugin.getUserManager().addPermission(target, permission);
                plugin.send(sender, "user-perm-added", Map.of("player", displayName(target), "permission", permission));
            } else {
                plugin.getUserManager().removePermission(target, permission);
                plugin.send(sender, "user-perm-removed", Map.of("player", displayName(target), "permission", permission));
            }
            reloadIfOnline(target);
            return true;
        }

        plugin.send(sender, "unknown-command");
        return true;
    }

    private boolean handleGroup(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        if (args.length < 2) {
            sendGroupList(sender);
            return true;
        }

        String action = args[1].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            sendGroupList(sender);
            return true;
        }
        if (action.equals("create")) {
            if (args.length < 3) {
                plugin.send(sender, "usage-group-create");
                return true;
            }
            String rank = args[2].toLowerCase(Locale.ROOT);
            if (plugin.getRankManager().exists(rank)) {
                plugin.send(sender, "group-exists", Map.of("rank", rank));
                return true;
            }
            plugin.getRankManager().createRank(rank);
            plugin.send(sender, "group-created", Map.of("rank", rank));
            return true;
        }
        if (action.equals("delete")) {
            if (args.length < 3) {
                plugin.send(sender, "usage-group-delete");
                return true;
            }
            String rank = args[2].toLowerCase(Locale.ROOT);
            if (rank.equals(plugin.getRankManager().getDefaultRankName())) {
                plugin.send(sender, "group-default-delete");
                return true;
            }
            if (!requireRank(sender, rank)) {
                return true;
            }
            plugin.getRankManager().deleteRank(rank);
            plugin.send(sender, "group-deleted", Map.of("rank", rank));
            plugin.getPermissionManager().reloadOnlinePlayers();
            return true;
        }
        if (args.length < 3) {
            plugin.send(sender, "unknown-command");
            return true;
        }

        String rank = args[2].toLowerCase(Locale.ROOT);
        if (!requireRank(sender, rank)) {
            return true;
        }

        if (action.equals("setprefix")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-group-setprefix");
                return true;
            }
            plugin.getRankManager().setPrefix(rank, join(args, 3));
            plugin.send(sender, "group-updated", Map.of("rank", rank));
            plugin.getPermissionManager().reloadOnlinePlayers();
            return true;
        }
        if (action.equals("setsuffix")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-group-setsuffix");
                return true;
            }
            plugin.getRankManager().setSuffix(rank, join(args, 3));
            plugin.send(sender, "group-updated", Map.of("rank", rank));
            plugin.getPermissionManager().reloadOnlinePlayers();
            return true;
        }
        if (action.equals("setpriority")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-group-setpriority");
                return true;
            }
            try {
                plugin.getRankManager().setPriority(rank, Integer.parseInt(args[3]));
                plugin.send(sender, "group-updated", Map.of("rank", rank));
            } catch (NumberFormatException exception) {
                plugin.send(sender, "invalid-number");
            }
            return true;
        }
        if (action.equals("addperm") || action.equals("removeperm")) {
            if (args.length < 4) {
                plugin.send(sender, "usage-group-perm");
                return true;
            }
            String permission = args[3];
            if (action.equals("addperm")) {
                plugin.getRankManager().addPermission(rank, permission);
                plugin.send(sender, "group-perm-added", Map.of("rank", rank, "permission", permission));
            } else {
                plugin.getRankManager().removePermission(rank, permission);
                plugin.send(sender, "group-perm-removed", Map.of("rank", rank, "permission", permission));
            }
            plugin.getPermissionManager().reloadOnlinePlayers();
            return true;
        }

        plugin.send(sender, "unknown-command");
        return true;
    }

    private boolean requireAdmin(CommandSender sender) {
        if (plugin.getPermissionManager().senderHas(sender, "rslranks.admin")) {
            return true;
        }
        plugin.send(sender, "no-permission");
        return false;
    }

    private boolean requireRank(CommandSender sender, String rank) {
        if (plugin.getRankManager().exists(rank)) {
            return true;
        }
        plugin.send(sender, "rank-not-found", Map.of("rank", rank));
        return false;
    }

    private void reloadIfOnline(OfflinePlayer player) {
        if (player.isOnline() && player.getPlayer() != null) {
            plugin.getPermissionManager().apply(player.getPlayer());
        }
    }

    private String displayName(OfflinePlayer player) {
        return player.getName() == null ? player.getUniqueId().toString() : player.getName();
    }

    private String join(String[] args, int start) {
        return String.join(" ", Arrays.copyOfRange(args, start, args.length));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ColorUtil.color("&8&m----------------&r &cRSLRanks &8&m----------------"));
        sender.sendMessage(ColorUtil.color("&e/rank user <spieler> set <rang>"));
        sender.sendMessage(ColorUtil.color("&e/rank user <spieler> info"));
        sender.sendMessage(ColorUtil.color("&e/rank user <spieler> addperm <permission>"));
        sender.sendMessage(ColorUtil.color("&e/rank user <spieler> removeperm <permission>"));
        sender.sendMessage(ColorUtil.color("&e/rank group create/delete/list <name>"));
        sender.sendMessage(ColorUtil.color("&e/rank group setprefix/setsuffix/setpriority <name> <wert>"));
        sender.sendMessage(ColorUtil.color("&e/rank group addperm/removeperm <name> <permission>"));
        sender.sendMessage(ColorUtil.color("&e/rank reload"));
        sender.sendMessage(ColorUtil.color("&e/rank tabconfig"));
    }

    private void sendGroupList(CommandSender sender) {
        sender.sendMessage(ColorUtil.color("&8&m----------------&r &cRSLRanks Gruppen &8&m----------------"));
        for (Rank rank : plugin.getRankManager().getSortedRanks()) {
            sender.sendMessage(ColorUtil.color(rank.getPrefix() + "&7" + rank.getName() + " &8- &ePriority " + rank.getPriority()));
        }
    }

    private void sendTabConfig(CommandSender sender) {
        sender.sendMessage(ColorUtil.color("&8&m----------------&r &cTAB Config Hilfe &8&m----------------"));
        sender.sendMessage(ColorUtil.color("&7TAB muss installiert sein. Vault sollte installiert sein."));
        sender.sendMessage(ColorUtil.color("&7Wenn Vault genutzt wird: &eassign-groups-by-permissions: false &7lassen."));
        sender.sendMessage(ColorUtil.color("&7Danach &e/tab reload &7ausfuehren."));
        sender.sendMessage("");
        sender.sendMessage("scoreboard-teams:");
        sender.sendMessage("  sorting-types:");
        sender.sendMessage("    - \"GROUPS:" + plugin.getRankManager().tabGroupOrder() + "\"");
        sender.sendMessage("    - \"PLACEHOLDER_A_TO_Z:%player%\"");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(args[0], List.of("help", "user", "group", "reload", "tabconfig"));
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("user")) {
            List<String> names = new ArrayList<>();
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                names.add(player.getName());
            }
            return filter(args[1], names);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("user")) {
            return filter(args[2], List.of("set", "info", "addperm", "removeperm"));
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("user") && args[2].equalsIgnoreCase("set")) {
            return filter(args[3], rankNames());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("group")) {
            return filter(args[1], List.of("create", "delete", "setprefix", "setsuffix", "setpriority", "addperm", "removeperm", "list"));
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("group") && !args[1].equalsIgnoreCase("create") && !args[1].equalsIgnoreCase("list")) {
            return filter(args[2], rankNames());
        }
        return Collections.emptyList();
    }

    private List<String> rankNames() {
        List<String> names = new ArrayList<>();
        for (Rank rank : plugin.getRankManager().getSortedRanks()) {
            names.add(rank.getName());
        }
        return names;
    }

    private List<String> filter(String input, List<String> options) {
        String lowered = input.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lowered)) {
                result.add(option);
            }
        }
        return result;
    }
}

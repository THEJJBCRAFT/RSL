RSL Plugin Sammlung

Stand: 2026-06-15

Enthaltene Plugins:
- RSLRanks 1.0.0
  Rang- und Rechte-System mit Vault/TAB Support.
- RSLBalance 1.0.0
  Eigene Vault Economy fuer Balance, TAB und andere Plugins.
- RSLWelcome 1.0.0
  Join-Welcome mit animiertem Title, Spielername-Schreibeffekt und Sounds.

Ordner:
- 01_Server_Ready
  Diese Struktur kann direkt in einen Paper/Spigot-Server kopiert werden.
  Enthalten sind Jars, wichtige Plugin-Configs und die aktuelle TAB-Integration.

- 02_Jars
  Nur die fertigen Plugin-Jars.

- 03_Source
  Die Projektquellen zum Weiterentwickeln und Neubauen.

Installation:
1. Server stoppen.
2. Inhalt von 01_Server_Ready in den Serverordner kopieren.
3. Vault, TAB und PlaceholderAPI koennen zusaetzlich installiert sein.
4. Server starten.

Wichtig:
- RSLRanks ist fuer Raenge und Rechte.
- RSLBalance ist fuer Geld/Balance.
- RSLWelcome ist fuer Join-Title und Willkommensnachricht.
- TAB nutzt die RSLRanks/Vault Gruppen und RSLBalance/Vault Economy.

Test-Befehle:
- /rank help
- /rslbalance
- /rsleco reload
- /rslwelcome test
- /rslwelcome reload

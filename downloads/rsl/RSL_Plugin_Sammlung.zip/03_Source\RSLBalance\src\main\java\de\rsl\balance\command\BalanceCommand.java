package de.rsl.balance.command;

import de.rsl.balance.RSLBalancePlugin;
import de.rsl.balance.economy.EconomyManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class BalanceCommand implements CommandExecutor, TabCompleter {
    private final RSLBalancePlugin plugin;
    private final EconomyManager economyManager;

    public BalanceCommand(RSLBalancePlugin plugin) {
        this.plugin = plugin;
        this.economyManager = plugin.getEconomyManager();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (command.getName().equalsIgnoreCase("rslbalance")) {
            return handleBalance(sender, args);
        }
        return handleEco(sender, args);
    }

    private boolean handleBalance(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                plugin.send(sender, "usage-balance");
                return true;
            }
            double balance = economyManager.getBalance(player);
            plugin.send(sender, "balance-self", Map.of("balance", economyManager.format(balance)));
            return true;
        }

        if (!isAdmin(sender)) {
            plugin.send(sender, "no-permission");
            return true;
        }

        OfflinePlayer target = economyManager.resolvePlayer(args[0]);
        double balance = economyManager.getBalance(target);
        plugin.send(sender, "balance-other", Map.of(
                "player", displayName(target, args[0]),
                "balance", economyManager.format(balance)
        ));
        return true;
    }

    private boolean handleEco(CommandSender sender, String[] args) {
        if (!isAdmin(sender)) {
            plugin.send(sender, "no-permission");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadAll();
            plugin.send(sender, "reloaded");
            return true;
        }

        if (args.length < 3) {
            plugin.send(sender, "usage-eco");
            return true;
        }

        String action = args[0].toLowerCase(Locale.ROOT);
        OfflinePlayer target = economyManager.resolvePlayer(args[1]);
        double amount;
        try {
            amount = Double.parseDouble(args[2].replace(',', '.'));
        } catch (NumberFormatException exception) {
            plugin.send(sender, "invalid-number");
            return true;
        }

        if (amount < 0.0D) {
            plugin.send(sender, "invalid-number");
            return true;
        }

        double balance;
        switch (action) {
            case "set" -> {
                balance = economyManager.setBalance(target, amount);
                plugin.send(sender, "eco-set", Map.of(
                        "player", displayName(target, args[1]),
                        "balance", economyManager.format(balance)
                ));
            }
            case "add" -> {
                balance = economyManager.deposit(target, amount);
                plugin.send(sender, "eco-add", Map.of(
                        "player", displayName(target, args[1]),
                        "amount", economyManager.format(amount),
                        "balance", economyManager.format(balance)
                ));
            }
            case "take", "remove" -> {
                balance = economyManager.withdraw(target, amount);
                plugin.send(sender, "eco-take", Map.of(
                        "player", displayName(target, args[1]),
                        "amount", economyManager.format(amount),
                        "balance", economyManager.format(balance)
                ));
            }
            default -> plugin.send(sender, "usage-eco");
        }
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String alias, @NotNull String[] args) {
        List<String> suggestions = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("rslbalance")) {
            if (args.length == 1 && isAdmin(sender)) {
                Bukkit.getOnlinePlayers().forEach(player -> suggestions.add(player.getName()));
            }
            return filter(suggestions, args);
        }

        if (!isAdmin(sender)) {
            return suggestions;
        }
        if (args.length == 1) {
            suggestions.addAll(List.of("set", "add", "take", "reload"));
        } else if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
            Bukkit.getOnlinePlayers().forEach(player -> suggestions.add(player.getName()));
        } else if (args.length == 3 && !args[0].equalsIgnoreCase("reload")) {
            suggestions.addAll(List.of("10", "100", "1000"));
        }
        return filter(suggestions, args);
    }

    private List<String> filter(List<String> suggestions, String[] args) {
        if (args.length == 0) {
            return suggestions;
        }
        String current = args[args.length - 1].toLowerCase(Locale.ROOT);
        return suggestions.stream()
                .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(current))
                .toList();
    }

    private boolean isAdmin(CommandSender sender) {
        return sender.isOp() || sender.hasPermission("rslbalance.admin");
    }

    private String displayName(OfflinePlayer player, String fallback) {
        String name = player.getName();
        return name == null || name.isBlank() ? fallback : name;
    }
}

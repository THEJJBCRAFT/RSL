package de.rsl.balance;

import de.rsl.balance.command.BalanceCommand;
import de.rsl.balance.economy.EconomyManager;
import de.rsl.balance.hook.PlaceholderHook;
import de.rsl.balance.hook.VaultEconomyHook;
import de.rsl.balance.util.ConfigUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public class RSLBalancePlugin extends JavaPlugin implements Listener {
    private ConfigUtil messages;
    private EconomyManager economyManager;
    private VaultEconomyHook vaultEconomyHook;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new ConfigUtil(this, "messages.yml");
        economyManager = new EconomyManager(this);
        economyManager.load();

        Bukkit.getPluginManager().registerEvents(this, this);

        BalanceCommand balanceCommand = new BalanceCommand(this);
        PluginCommand command = getCommand("rslbalance");
        if (command != null) {
            command.setExecutor(balanceCommand);
            command.setTabCompleter(balanceCommand);
        }
        PluginCommand ecoCommand = getCommand("rsleco");
        if (ecoCommand != null) {
            ecoCommand.setExecutor(balanceCommand);
            ecoCommand.setTabCompleter(balanceCommand);
        }

        if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            vaultEconomyHook = new VaultEconomyHook(this, economyManager);
            vaultEconomyHook.register();
        } else {
            getLogger().info("Vault not found, economy provider disabled.");
        }

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderHook(this, economyManager).register();
            getLogger().info("PlaceholderAPI hook enabled.");
        } else {
            getLogger().info("PlaceholderAPI not found, RSLBalance placeholders disabled.");
        }

        getLogger().info("RSLBalance enabled.");
    }

    @Override
    public void onDisable() {
        if (vaultEconomyHook != null) {
            vaultEconomyHook.unregister();
        }
        if (economyManager != null) {
            economyManager.save();
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        economyManager.createAccount(event.getPlayer());
    }

    public void reloadAll() {
        reloadConfig();
        messages.reload();
        economyManager.load();
    }

    public void send(CommandSender sender, String key) {
        send(sender, key, Map.of());
    }

    public void send(CommandSender sender, String key, Map<String, String> replacements) {
        String message = messages.message(key);
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            message = message.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        sender.sendMessage(message);
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }
}

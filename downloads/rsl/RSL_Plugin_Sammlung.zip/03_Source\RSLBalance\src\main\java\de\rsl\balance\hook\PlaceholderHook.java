package de.rsl.balance.hook;

import de.rsl.balance.RSLBalancePlugin;
import de.rsl.balance.economy.EconomyManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class PlaceholderHook extends PlaceholderExpansion {
    private final RSLBalancePlugin plugin;
    private final EconomyManager economyManager;

    public PlaceholderHook(RSLBalancePlugin plugin, EconomyManager economyManager) {
        this.plugin = plugin;
        this.economyManager = economyManager;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "rslbalance";
    }

    @Override
    public @NotNull String getAuthor() {
        return "RedstoneLabs";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }

        double balance = economyManager.getBalance(player);
        return switch (params.toLowerCase(Locale.ROOT)) {
            case "balance" -> String.valueOf(balance);
            case "balance_formatted" -> economyManager.format(balance);
            default -> "";
        };
    }
}

package de.rsl.navigator;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.java.JavaPlugin;

public final class RSLNavigatorPlugin extends JavaPlugin implements Listener, TabExecutor {
    private static final List<String> ROOT_COMMANDS = Arrays.asList("open", "admin", "edit", "reload", "save", "menu", "item", "help");
    private static final List<String> MENU_COMMANDS = Arrays.asList("create", "delete", "title", "size", "duplicate", "sound");
    private static final List<String> ITEM_COMMANDS = Arrays.asList("add", "set", "name", "lore", "command", "addcommand", "menu", "sound", "glow", "permission", "category", "amount", "custommodel", "close", "remove");
    private static final Pattern HEX_AMP_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final Pattern HEX_TAG_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");

    private final Map<UUID, Long> clickCooldowns = new HashMap<>();
    private final Map<UUID, PendingInput> pendingInputs = new ConcurrentHashMap<>();
    private final Map<UUID, TransferMode> transferModes = new HashMap<>();
    private String mainMenu;
    private long clickCooldownMs;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Objects.requireNonNull(getCommand("rslnav"), "rslnav command missing").setExecutor(this);
        Objects.requireNonNull(getCommand("rslnav"), "rslnav command missing").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("open")) {
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            if (!player.hasPermission("rslnavigator.open")) {
                send(player, "no-permission");
                return true;
            }
            openMenu(player, args.length >= 2 ? args[1] : mainMenu);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("help")) {
            sendHelp(sender);
            return true;
        }

        if (sub.equals("admin")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            openAdmin(player);
            return true;
        }

        if (sub.equals("edit")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            openMenuEditor(player, args.length >= 2 ? args[1] : mainMenu);
            return true;
        }

        if (sub.equals("reload")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            reloadConfig();
            loadSettings();
            send(sender, "reloaded");
            return true;
        }

        if (sub.equals("save")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            saveConfig();
            send(sender, "saved");
            return true;
        }

        if (sub.equals("menu")) {
            return handleMenuCommand(sender, args);
        }

        if (sub.equals("item")) {
            return handleItemCommand(sender, args);
        }

        sendHelp(sender);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(ROOT_COMMANDS, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("open")) {
            return filter(menuIds(), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("edit")) {
            return filter(menuIds(), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("menu")) {
            return filter(MENU_COMMANDS, args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("menu") && !args[1].equalsIgnoreCase("create")) {
            return filter(menuIds(), args[2]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("item")) {
            return filter(ITEM_COMMANDS, args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("item")) {
            return filter(menuIds(), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("item") && !isItemSetAction(args[1])) {
            return filter(itemIds(args[2]), args[3]);
        }
        return Collections.emptyList();
    }

    @EventHandler(ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        PendingInput pendingInput = pendingInputs.get(event.getPlayer().getUniqueId());
        if (pendingInput != null) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask(this, () -> handlePendingInput(event.getPlayer(), event.getMessage()));
            return;
        }

        if (!getConfig().getBoolean("settings.open-with-chat-dot", true)) {
            return;
        }
        if (!event.getMessage().trim().equals(".")) {
            return;
        }
        if (getConfig().getBoolean("settings.cancel-dot-chat-message", true)) {
            event.setCancelled(true);
        }
        Bukkit.getScheduler().runTask(this, () -> tryOpenFromTrigger(event.getPlayer()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommandDot(PlayerCommandPreprocessEvent event) {
        if (!getConfig().getBoolean("settings.open-with-command-dot", true)) {
            return;
        }
        String message = event.getMessage().trim();
        if (!message.equals("/.")) {
            return;
        }
        event.setCancelled(true);
        tryOpenFromTrigger(event.getPlayer());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (holder instanceof AdminHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleAdminClick(player, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof MenuManagerHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleMenuManagerClick(player, event.getRawSlot(), event.getClick());
            }
            return;
        }
        if (holder instanceof MenuSettingsHolder menuSettingsHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleMenuSettingsClick(player, menuSettingsHolder.menuId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof MenuEditorHolder menuEditorHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleMenuEditorClick(player, menuEditorHolder.menuId, event.getRawSlot(), event.getClick());
            }
            return;
        }
        if (holder instanceof ItemEditorHolder itemEditorHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleItemEditorClick(player, itemEditorHolder.menuId, itemEditorHolder.itemId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof MaterialPickerHolder materialPickerHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleMaterialPickerClick(player, materialPickerHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof TextDesignHolder textDesignHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleTextDesignClick(player, textDesignHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof CommandEditorHolder commandEditorHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCommandEditorClick(player, commandEditorHolder.menuId, commandEditorHolder.itemId, event.getRawSlot(), event.getClick());
            }
            return;
        }
        if (holder instanceof PickerHolder pickerHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handlePickerClick(player, pickerHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof NumberPickerHolder numberPickerHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleNumberPickerClick(player, numberPickerHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof CommandBrowserHolder commandBrowserHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCommandBrowserClick(player, commandBrowserHolder, event.getRawSlot(), event.getClick());
            }
            return;
        }
        if (holder instanceof CommandBuilderHolder commandBuilderHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCommandBuilderClick(player, commandBuilderHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof CommandArgumentHolder commandArgumentHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCommandArgumentClick(player, commandArgumentHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof AnvilInputHolder anvilInputHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleAnvilInputClick(player, anvilInputHolder, event.getRawSlot(), event.getCurrentItem());
            }
            return;
        }
        if (holder instanceof SettingsHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleSettingsClick(player, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof ConfirmHolder confirmHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleConfirmClick(player, confirmHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof MenuHolder menuHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleNavigatorClick(player, menuHolder.menuId, event.getRawSlot());
            }
        }
    }

    private boolean handleMenuCommand(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        if (args.length < 3) {
            sender.sendMessage(color(prefix() + "&cNutze: &e/rslnav menu <create|delete|title|size|duplicate|sound> <id> ..."));
            return true;
        }
        String action = args[1].toLowerCase(Locale.ROOT);
        String menuId = cleanId(args[2]);
        if (action.equals("create")) {
            int size = args.length >= 4 ? parseSize(args[3], 54) : 54;
            String title = args.length >= 5 ? join(args, 4) : "&6&l" + menuId;
            createMenu(menuId, size, title);
            sendRaw(sender, message("menu-created").replace("<menu>", menuId));
            return true;
        }
        if (!hasMenu(menuId)) {
            sendRaw(sender, message("menu-not-found").replace("<menu>", menuId));
            return true;
        }
        if (action.equals("delete")) {
            getConfig().set("menus." + menuId, null);
            saveConfig();
            sendRaw(sender, message("menu-deleted").replace("<menu>", menuId));
            return true;
        }
        if (action.equals("title")) {
            getConfig().set("menus." + menuId + ".title", join(args, 3));
        } else if (action.equals("size")) {
            getConfig().set("menus." + menuId + ".size", parseSize(args[3], 54));
        } else if (action.equals("sound")) {
            getConfig().set("menus." + menuId + ".open-sound", args[3].toUpperCase(Locale.ROOT));
        } else if (action.equals("duplicate")) {
            if (args.length < 4) {
                sender.sendMessage(color(prefix() + "&cNutze: &e/rslnav menu duplicate <quelle> <neu>"));
                return true;
            }
            duplicateMenu(menuId, cleanId(args[3]));
        } else {
            sender.sendMessage(color(prefix() + "&cUnbekannte Menu-Aktion."));
            return true;
        }
        saveConfig();
        send(sender, "saved");
        return true;
    }

    private boolean handleItemCommand(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(color(prefix() + "&cNutze: &e/rslnav item <add|set|name|lore|command|addcommand|menu|sound|glow|permission|category|amount|custommodel|close|remove> <menu> <item> ..."));
            return true;
        }
        String action = args[1].toLowerCase(Locale.ROOT);
        String menuId = cleanId(args[2]);
        if (!hasMenu(menuId)) {
            sendRaw(sender, message("menu-not-found").replace("<menu>", menuId));
            return true;
        }

        if (isItemSetAction(action)) {
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            int slot = parseInt(args[3], -1);
            if (slot < 0 || slot >= menuSize(menuId)) {
                sender.sendMessage(color(prefix() + "&cSlot muss zwischen 0 und " + (menuSize(menuId) - 1) + " sein."));
                return true;
            }
            String itemId = args.length >= 5 ? cleanId(args[4]) : "item_" + slot;
            setItemFromHand(player, menuId, slot, itemId);
            return true;
        }

        String itemId = cleanId(args[3]);
        if (!hasItem(menuId, itemId) && !action.equals("remove")) {
            sendRaw(sender, message("item-not-found").replace("<item>", itemId));
            return true;
        }
        String base = itemPath(menuId, itemId);
        if (action.equals("remove")) {
            getConfig().set(base, null);
            saveConfig();
            sendRaw(sender, message("item-removed").replace("<item>", itemId));
            return true;
        }
        if (action.equals("name")) {
            getConfig().set(base + ".name", join(args, 4));
        } else if (action.equals("lore")) {
            getConfig().set(base + ".lore", Arrays.asList(join(args, 4).split("\\|")));
        } else if (action.equals("command")) {
            getConfig().set(base + ".commands", Arrays.asList(join(args, 4).split("\\s*;\\s*")));
        } else if (action.equals("addcommand")) {
            List<String> commands = getConfig().getStringList(base + ".commands");
            commands.add(join(args, 4));
            getConfig().set(base + ".commands", commands);
        } else if (action.equals("menu")) {
            getConfig().set(base + ".menu", cleanId(args[4]));
        } else if (action.equals("sound")) {
            getConfig().set(base + ".sound", args[4].toUpperCase(Locale.ROOT));
        } else if (action.equals("glow")) {
            getConfig().set(base + ".glow", Boolean.parseBoolean(args[4]));
        } else if (action.equals("permission")) {
            getConfig().set(base + ".permission", args[4].equalsIgnoreCase("none") ? "" : args[4]);
        } else if (action.equals("category")) {
            getConfig().set(base + ".category", join(args, 4));
        } else if (action.equals("amount")) {
            getConfig().set(base + ".amount", clamp(parseInt(args[4], 1), 1, 64));
        } else if (action.equals("custommodel")) {
            getConfig().set(base + ".custom-model-data", args[4].equalsIgnoreCase("none") ? 0 : Math.max(0, parseInt(args[4], 0)));
        } else if (action.equals("close")) {
            getConfig().set(base + ".close-after-click", Boolean.parseBoolean(args[4]));
        } else {
            sender.sendMessage(color(prefix() + "&cUnbekannte Item-Aktion."));
            return true;
        }
        saveConfig();
        sendRaw(sender, message("item-updated").replace("<item>", itemId));
        return true;
    }

    private void tryOpenFromTrigger(Player player) {
        if (!getConfig().getBoolean("settings.enabled", true)) {
            return;
        }
        if (!player.hasPermission("rslnavigator.open")) {
            playSound(player, getConfig().getString("sounds.menu-error", "BLOCK_NOTE_BLOCK_BASS"));
            send(player, "no-permission");
            return;
        }
        openMenu(player, mainMenu);
    }

    private void openAdmin(Player player) {
        AdminHolder holder = new AdminHolder();
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6&lRSL Navigator Admin"));
        holder.inventory = inventory;
        inventory.setItem(10, button(Material.COMPASS, "&6Navigator oeffnen", "&7Oeffnet das Hauptmenue normal."));
        inventory.setItem(12, button(Material.WRITABLE_BOOK, "&eHauptmenue bearbeiten", "&7Oeffnet den visuellen Editor."));
        inventory.setItem(14, button(Material.CHEST, "&6Menues verwalten", "&7Alle Menues ansehen, bearbeiten, loeschen."));
        inventory.setItem(16, button(Material.LIME_DYE, "&aNeues Menue", "&7Startet den GUI-Ersteller per Chat-Prompt."));
        inventory.setItem(28, button(Material.REPEATER, "&dGlobale Settings", "&7Punkt-Trigger, Cooldown und Plugin-Status."));
        inventory.setItem(30, button(Material.EMERALD, "&aSpeichern", "&7Speichert die Config."));
        inventory.setItem(32, button(Material.REDSTONE, "&cReload", "&7Laedt die Config neu."));
        inventory.setItem(34, button(Material.BOOK, "&bHilfe", "&7Zeigt die wichtigsten Editor-Aktionen."));
        player.openInventory(inventory);
        playSound(player, getConfig().getString("sounds.menu-open", "UI_BUTTON_CLICK"));
    }

    private void handleAdminClick(Player player, int rawSlot) {
        if (rawSlot == 10) {
            openMenu(player, mainMenu);
        } else if (rawSlot == 12) {
            openMenuEditor(player, mainMenu);
        } else if (rawSlot == 14) {
            openMenuManager(player);
        } else if (rawSlot == 16) {
            beginInput(player, new PendingInput(InputType.MENU_CREATE_ID, "", "", -1), "&eNeue Menue-ID eingeben. &7Zum Abbrechen: &ccancel");
        } else if (rawSlot == 28) {
            openSettings(player);
        } else if (rawSlot == 30) {
            saveConfig();
            send(player, "saved");
            openAdmin(player);
        } else if (rawSlot == 32) {
            reloadConfig();
            loadSettings();
            send(player, "reloaded");
            openAdmin(player);
        } else if (rawSlot == 34) {
            sendHelp(player);
            send(player, "editor-help");
        }
    }

    private void openMenuManager(Player player) {
        MenuManagerHolder holder = new MenuManagerHolder();
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6&lRSL Menues"));
        holder.inventory = inventory;
        int slot = 0;
        for (String menuId : menuIds()) {
            if (slot >= 45) {
                break;
            }
            inventory.setItem(slot++, button(Material.CHEST, "&6Menue: &e" + menuId,
                "&7Linksklick: Layout bearbeiten",
                "&7Rechtsklick: Menue-Einstellungen",
                "&7Shift-Rechtsklick: loeschen"));
        }
        inventory.setItem(45, button(Material.LIME_DYE, "&aNeues Menue", "&7Erstellt ein neues Menue per Chat-Prompt."));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Admin-Dashboard."));
        inventory.setItem(53, button(Material.EMERALD, "&aSpeichern", "&7Speichert die Config."));
        player.openInventory(inventory);
    }

    private void handleMenuManagerClick(Player player, int rawSlot, ClickType click) {
        if (rawSlot == 45) {
            beginInput(player, new PendingInput(InputType.MENU_CREATE_ID, "", "", -1), "&eNeue Menue-ID eingeben. &7Zum Abbrechen: &ccancel");
            return;
        }
        if (rawSlot == 49) {
            openAdmin(player);
            return;
        }
        if (rawSlot == 53) {
            saveConfig();
            send(player, "saved");
            openMenuManager(player);
            return;
        }
        List<String> menus = menuIds();
        if (rawSlot < 0 || rawSlot >= menus.size()) {
            return;
        }
        String menuId = menus.get(rawSlot);
        if (click.isShiftClick() && click.isRightClick()) {
            openConfirm(player, ConfirmType.DELETE_MENU, menuId, "", -1, "&cMenue loeschen?", "&7Menue: &e" + menuId);
        } else if (click.isRightClick()) {
            openMenuSettings(player, menuId);
        } else {
            openMenuEditor(player, menuId);
        }
    }

    private void openMenuSettings(Player player, String menuId) {
        if (!hasMenu(menuId)) {
            sendRaw(player, message("menu-not-found").replace("<menu>", menuId));
            return;
        }
        MenuSettingsHolder holder = new MenuSettingsHolder(menuId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&6Menue Settings &8- &e" + menuId));
        holder.inventory = inventory;
        inventory.setItem(2, button(Material.NAME_TAG, "&eTitel aendern", "&7Aktuell: &f" + getConfig().getString("menus." + menuId + ".title", menuId)));
        inventory.setItem(4, button(Material.CHEST, "&6Groesse aendern", "&7Aktuell: &e" + menuSize(menuId), "&7Oeffnet einen Zahlen-Picker."));
        inventory.setItem(6, button(Material.NOTE_BLOCK, "&dOpen-Sound", "&7Aktuell: &e" + getConfig().getString("menus." + menuId + ".open-sound", "-"), "&7Oeffnet den Sound-Picker."));
        inventory.setItem(10, button(Material.GRAY_STAINED_GLASS_PANE, "&7Filler umschalten", "&7Aktuell: &e" + getConfig().getBoolean("menus." + menuId + ".filler.enabled", false)));
        inventory.setItem(12, button(Material.HOPPER, "&7Filler aus Hand", "&7Setzt Material aus deiner Haupthand."));
        inventory.setItem(14, button(Material.AMETHYST_SHARD, "&bMenue duplizieren", "&7Neue ID wird per Chat abgefragt."));
        inventory.setItem(16, button(Material.BARRIER, "&cMenue loeschen", "&7Oeffnet eine Bestaetigung."));
        inventory.setItem(22, button(Material.WRITABLE_BOOK, "&eLayout bearbeiten", "&7Oeffnet den visuellen Editor."));
        inventory.setItem(26, button(Material.ARROW, "&eZurueck", "&7Zur Menue-Liste."));
        player.openInventory(inventory);
    }

    private void handleMenuSettingsClick(Player player, String menuId, int rawSlot) {
        if (rawSlot == 2) {
            beginInput(player, new PendingInput(InputType.MENU_TITLE, menuId, "", -1), "&eNeuen Menue-Titel eingeben. &7Farbcodes mit &: &ccancel &7bricht ab.");
        } else if (rawSlot == 4) {
            openNumberPicker(player, NumberKind.MENU_SIZE, menuId, "", -1);
        } else if (rawSlot == 6) {
            openPicker(player, PickerKind.MENU_SOUND, menuId, "", 0);
        } else if (rawSlot == 10) {
            String path = "menus." + menuId + ".filler.enabled";
            getConfig().set(path, !getConfig().getBoolean(path, false));
            saveConfig();
            openMenuSettings(player, menuId);
        } else if (rawSlot == 12) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand == null || hand.getType().isAir()) {
                send(player, "editor-help");
                return;
            }
            getConfig().set("menus." + menuId + ".filler.enabled", true);
            getConfig().set("menus." + menuId + ".filler.material", hand.getType().name());
            saveConfig();
            openMenuSettings(player, menuId);
        } else if (rawSlot == 14) {
            beginInput(player, new PendingInput(InputType.MENU_DUPLICATE_ID, menuId, "", -1), "&eNeue Menue-ID fuer Kopie eingeben.");
        } else if (rawSlot == 16) {
            openConfirm(player, ConfirmType.DELETE_MENU, menuId, "", -1, "&cMenue loeschen?", "&7Menue: &e" + menuId);
        } else if (rawSlot == 22) {
            openMenuEditor(player, menuId);
        } else if (rawSlot == 26) {
            openMenuManager(player);
        }
    }

    private void openSettings(Player player) {
        SettingsHolder holder = new SettingsHolder();
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&d&lRSLNavigator Settings"));
        holder.inventory = inventory;
        inventory.setItem(10, button(Material.LEVER, "&6Plugin aktiv", "&7Aktuell: &e" + getConfig().getBoolean("settings.enabled", true)));
        inventory.setItem(11, button(Material.PAPER, "&6Chat-Punkt", "&7Aktuell: &e" + getConfig().getBoolean("settings.open-with-chat-dot", true)));
        inventory.setItem(12, button(Material.COMMAND_BLOCK, "&6Befehl /.", "&7Aktuell: &e" + getConfig().getBoolean("settings.open-with-command-dot", true)));
        inventory.setItem(13, button(Material.INK_SAC, "&6Punkt im Chat verstecken", "&7Aktuell: &e" + getConfig().getBoolean("settings.cancel-dot-chat-message", true)));
        inventory.setItem(14, button(Material.CLOCK, "&6Click-Cooldown", "&7Aktuell: &e" + clickCooldownMs + "ms", "&7Oeffnet einen Zahlen-Picker."));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zum Admin-Dashboard."));
        player.openInventory(inventory);
    }

    private void handleSettingsClick(Player player, int rawSlot) {
        if (rawSlot == 10) {
            toggle("settings.enabled");
        } else if (rawSlot == 11) {
            toggle("settings.open-with-chat-dot");
        } else if (rawSlot == 12) {
            toggle("settings.open-with-command-dot");
        } else if (rawSlot == 13) {
            toggle("settings.cancel-dot-chat-message");
        } else if (rawSlot == 14) {
            openNumberPicker(player, NumberKind.SETTINGS_COOLDOWN, "", "", -1);
            return;
        } else if (rawSlot == 22) {
            openAdmin(player);
            return;
        }
        saveConfig();
        loadSettings();
        openSettings(player);
    }

    private void openMenu(Player player, String menuId) {
        if (!hasMenu(menuId)) {
            sendRaw(player, message("menu-not-found").replace("<menu>", menuId));
            return;
        }
        MenuHolder holder = new MenuHolder(menuId);
        Inventory inventory = Bukkit.createInventory(holder, menuSize(menuId), color(menuTitle(menuId, false)));
        holder.inventory = inventory;
        fillMenu(menuId, inventory);

        for (String itemId : itemIds(menuId)) {
            ConfigurationSection item = itemSection(menuId, itemId);
            if (item == null) {
                continue;
            }
            int slot = item.getInt("slot", -1);
            if (slot < 0 || slot >= inventory.getSize()) {
                continue;
            }
            String permission = item.getString("permission", "");
            if (permission != null && !permission.isBlank() && !player.hasPermission(permission)) {
                continue;
            }
            inventory.setItem(slot, buildItem(menuId, itemId, false));
        }

        player.openInventory(inventory);
        playSound(player, getConfig().getString("menus." + menuId + ".open-sound", getConfig().getString("sounds.menu-open", "UI_BUTTON_CLICK")));
    }

    private void openMenuEditor(Player player, String menuId) {
        if (!hasMenu(menuId)) {
            sendRaw(player, message("menu-not-found").replace("<menu>", menuId));
            return;
        }
        MenuEditorHolder holder = new MenuEditorHolder(menuId);
        Inventory inventory = Bukkit.createInventory(holder, menuSize(menuId), color(menuTitle(menuId, true)));
        holder.inventory = inventory;
        fillMenu(menuId, inventory);

        for (String itemId : itemIds(menuId)) {
            ConfigurationSection item = itemSection(menuId, itemId);
            if (item == null) {
                continue;
            }
            int slot = item.getInt("slot", -1);
            if (slot >= 0 && slot < inventory.getSize()) {
                inventory.setItem(slot, buildItem(menuId, itemId, true));
            }
        }

        player.openInventory(inventory);
        send(player, "editor-help");
    }

    private void fillMenu(String menuId, Inventory inventory) {
        if (!getConfig().getBoolean("menus." + menuId + ".filler.enabled", false)) {
            return;
        }
        Material material = material(getConfig().getString("menus." + menuId + ".filler.material", "BLACK_STAINED_GLASS_PANE"));
        String name = getConfig().getString("menus." + menuId + ".filler.name", " ");
        ItemStack item = button(material, name);
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, item);
        }
    }

    private void handleNavigatorClick(Player player, String menuId, int slot) {
        if (isCoolingDown(player)) {
            return;
        }
        String itemId = itemIdAt(menuId, slot);
        if (itemId == null) {
            return;
        }
        ConfigurationSection item = itemSection(menuId, itemId);
        if (item == null) {
            return;
        }
        String permission = item.getString("permission", "");
        if (permission != null && !permission.isBlank() && !player.hasPermission(permission)) {
            playSound(player, getConfig().getString("sounds.menu-error", "BLOCK_NOTE_BLOCK_BASS"));
            send(player, "no-permission");
            return;
        }
        playSound(player, item.getString("sound", getConfig().getString("sounds.menu-click", "UI_BUTTON_CLICK")));
        String targetMenu = item.getString("menu", "");
        if (targetMenu != null && !targetMenu.isBlank()) {
            openMenu(player, targetMenu);
        }
        for (String action : item.getStringList("commands")) {
            runAction(player, action);
        }
        if (item.getBoolean("close-after-click", false)) {
            player.closeInventory();
        }
    }

    private void handleMenuEditorClick(Player player, String menuId, int slot, ClickType click) {
        TransferMode transfer = transferModes.get(player.getUniqueId());
        if (transfer != null && click.isLeftClick()) {
            finishTransfer(player, transfer, slot, click.isShiftClick());
            return;
        }

        String existing = itemIdAt(menuId, slot);
        if (click.isShiftClick() && click.isRightClick()) {
            if (existing != null) {
                openConfirm(player, ConfirmType.DELETE_ITEM, menuId, existing, -1, "&cItem loeschen?", "&7Item: &e" + existing);
            }
            return;
        }
        if (click.isShiftClick() && click.isLeftClick()) {
            if (existing != null) {
                transferModes.put(player.getUniqueId(), new TransferMode(menuId, existing));
                player.closeInventory();
                player.sendMessage(color(prefix() + "&eMove/Copy gestartet: &f" + existing));
                player.sendMessage(color(prefix() + "&7Oeffne den Editor neu. Linksklick verschiebt, Shift-Linksklick kopiert."));
                Bukkit.getScheduler().runTaskLater(this, () -> openMenuEditor(player, menuId), 2L);
            }
            return;
        }
        if (click.isRightClick()) {
            if (existing != null) {
                openItemEditor(player, menuId, existing);
            }
            return;
        }
        if (click.isLeftClick()) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand == null || hand.getType().isAir()) {
                String target = existing == null ? uniqueItemId(menuId, "item_" + slot) : existing;
                if (existing == null) {
                    createDefaultItem(menuId, slot, target);
                }
                openItemEditor(player, menuId, target);
                return;
            }
            setItemFromHand(player, menuId, slot, existing == null ? "item_" + slot : existing);
            openMenuEditor(player, menuId);
        }
    }

    private void openItemEditor(Player player, String menuId, String itemId) {
        if (!hasItem(menuId, itemId)) {
            sendRaw(player, message("item-not-found").replace("<item>", itemId));
            return;
        }
        ItemEditorHolder holder = new ItemEditorHolder(menuId, itemId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Item Editor &8- &e" + itemId));
        holder.inventory = inventory;
        inventory.setItem(4, buildItem(menuId, itemId, true));
        inventory.setItem(10, button(Material.NAME_TAG, "&eName schreiben", "&7Freier Text per Chat.", "&8Nur Namen/Texte nutzen Chat."));
        inventory.setItem(11, button(Material.PAINTING, "&6Name-Design", "&7Farben, Styles, Hex und RSL-Presets per GUI."));
        inventory.setItem(12, button(Material.BOOK, "&eLore schreiben", "&7Freier Text per Chat.", "&7Trenne Zeilen mit |"));
        inventory.setItem(13, button(Material.WRITABLE_BOOK, "&6Lore-Design", "&7Wendet Farben und Styles auf alle Lore-Zeilen an."));
        inventory.setItem(14, button(Material.CHEST, "&eMaterial waehlen", "&7Alle Minecraft-Items per Kategorie-Browser."));
        inventory.setItem(15, button(Material.ITEM_FRAME, "&eMaterial aus Hand", "&7Nimmt Item, Menge und Meta aus deiner Hand."));
        inventory.setItem(16, button(Material.OAK_SIGN, "&eKategorie", "&7Kategorie per GUI auswaehlen.", "&7Aktuell: &e" + getConfig().getString(itemPath(menuId, itemId) + ".category", "-")));
        inventory.setItem(19, button(Material.NOTE_BLOCK, "&dSound", "&7Sound per GUI auswaehlen.", "&7Aktuell: &e" + getConfig().getString(itemPath(menuId, itemId) + ".sound", "-")));
        inventory.setItem(20, button(Material.GLOWSTONE_DUST, "&6Glow", "&7Aktuell: &e" + getConfig().getBoolean(itemPath(menuId, itemId) + ".glow", false)));
        inventory.setItem(21, button(Material.IRON_DOOR, "&cPermission", "&7Permission per GUI auswaehlen.", "&7Aktuell: &e" + getConfig().getString(itemPath(menuId, itemId) + ".permission", "none")));
        inventory.setItem(22, button(Material.CHEST, "&aUntermenue", "&7Ziel-Menue per GUI auswaehlen.", "&7Aktuell: &e" + getConfig().getString(itemPath(menuId, itemId) + ".menu", "none")));
        inventory.setItem(23, button(Material.COMMAND_BLOCK, "&cCommands", "&7Aktionen verwalten."));
        inventory.setItem(24, button(Material.ITEM_FRAME, "&bMenge", "&7Item-Menge per GUI setzen.", "&7Aktuell: &e" + getConfig().getInt(itemPath(menuId, itemId) + ".amount", 1)));
        inventory.setItem(25, button(Material.MAP, "&bCustomModelData", "&7Zahl per GUI setzen.", "&7Aktuell: &e" + getConfig().getInt(itemPath(menuId, itemId) + ".custom-model-data", 0)));
        inventory.setItem(28, button(Material.OAK_TRAPDOOR, "&6Close after click", "&7Aktuell: &e" + getConfig().getBoolean(itemPath(menuId, itemId) + ".close-after-click", false)));
        inventory.setItem(29, button(Material.LIME_DYE, "&aNeues Untermenue", "&7Erstellt ein neues Menue,", "&7verlinkt dieses Item sofort", "&7und oeffnet danach den Editor."));
        inventory.setItem(30, button(Material.ENDER_PEARL, "&dMove/Copy", "&7Naechster Klick im Layout verschiebt/kopiert."));
        inventory.setItem(31, button(Material.ARROW, "&eZurueck zum Layout", "&7Oeffnet den visuellen Editor."));
        inventory.setItem(32, button(Material.BARRIER, "&cLoeschen", "&7Item mit Bestaetigung loeschen."));
        inventory.setItem(49, button(Material.EMERALD, "&aSpeichern", "&7Speichert die Config."));
        player.openInventory(inventory);
    }

    private void handleItemEditorClick(Player player, String menuId, String itemId, int rawSlot) {
        String base = itemPath(menuId, itemId);
        if (rawSlot == 10) {
            beginInput(player, new PendingInput(InputType.ITEM_NAME, menuId, itemId, -1), "&eNeuen Item-Namen eingeben. &7Farbcodes mit &.");
        } else if (rawSlot == 11) {
            openTextDesign(player, menuId, itemId, TextTarget.NAME);
        } else if (rawSlot == 12) {
            beginInput(player, new PendingInput(InputType.ITEM_LORE, menuId, itemId, -1), "&eNeue Lore eingeben. &7Zeilen mit &f| &7trennen.");
        } else if (rawSlot == 13) {
            openTextDesign(player, menuId, itemId, TextTarget.LORE);
        } else if (rawSlot == 14) {
            openMaterialPicker(player, menuId, itemId, MaterialCategory.FAVORITES, 0);
        } else if (rawSlot == 15) {
            setItemMaterialFromHand(player, menuId, itemId);
            openItemEditor(player, menuId, itemId);
        } else if (rawSlot == 16) {
            openPicker(player, PickerKind.CATEGORY, menuId, itemId, 0);
        } else if (rawSlot == 19) {
            openPicker(player, PickerKind.ITEM_SOUND, menuId, itemId, 0);
        } else if (rawSlot == 20) {
            getConfig().set(base + ".glow", !getConfig().getBoolean(base + ".glow", false));
            saveConfig();
            openItemEditor(player, menuId, itemId);
        } else if (rawSlot == 21) {
            openPicker(player, PickerKind.PERMISSION, menuId, itemId, 0);
        } else if (rawSlot == 22) {
            openPicker(player, PickerKind.TARGET_MENU, menuId, itemId, 0);
        } else if (rawSlot == 23) {
            openCommandEditor(player, menuId, itemId);
        } else if (rawSlot == 24) {
            openNumberPicker(player, NumberKind.ITEM_AMOUNT, menuId, itemId, -1);
        } else if (rawSlot == 25) {
            openNumberPicker(player, NumberKind.ITEM_CUSTOM_MODEL_DATA, menuId, itemId, -1);
        } else if (rawSlot == 28) {
            getConfig().set(base + ".close-after-click", !getConfig().getBoolean(base + ".close-after-click", false));
            saveConfig();
            openItemEditor(player, menuId, itemId);
        } else if (rawSlot == 29) {
            beginInput(player, new PendingInput(InputType.SUBMENU_CREATE_ID, menuId, itemId, -1), "&eNeue Untermenue-ID eingeben. &7Dieses Item wird danach direkt verlinkt.");
        } else if (rawSlot == 30) {
            transferModes.put(player.getUniqueId(), new TransferMode(menuId, itemId));
            player.sendMessage(color(prefix() + "&eMove/Copy gestartet. Linksklick verschiebt, Shift-Linksklick kopiert."));
            openMenuEditor(player, menuId);
        } else if (rawSlot == 31) {
            openMenuEditor(player, menuId);
        } else if (rawSlot == 32) {
            openConfirm(player, ConfirmType.DELETE_ITEM, menuId, itemId, -1, "&cItem loeschen?", "&7Item: &e" + itemId);
        } else if (rawSlot == 49) {
            saveConfig();
            send(player, "saved");
            openItemEditor(player, menuId, itemId);
        }
    }

    private void openMaterialPicker(Player player, String menuId, String itemId, MaterialCategory category, int page) {
        MaterialPickerHolder holder = new MaterialPickerHolder(menuId, itemId, category, page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&eMaterial waehlen &8- &6" + category.label));
        holder.inventory = inventory;
        MaterialCategory[] categories = MaterialCategory.values();
        for (int i = 0; i < Math.min(18, categories.length); i++) {
            MaterialCategory option = categories[i];
            String selected = option == category ? "&aAktiv" : "&7Klick zum Wechseln";
            inventory.setItem(i, button(option.icon, option.label, selected));
        }

        List<Material> materials = materialsForCategory(category);
        int maxPage = Math.max(0, (materials.size() - 1) / 27);
        int safePage = clamp(page, 0, maxPage);
        holder.page = safePage;
        int start = safePage * 27;
        for (int i = 0; i < 27 && start + i < materials.size(); i++) {
            Material material = materials.get(start + i);
            inventory.setItem(18 + i, button(material, "&f" + prettifyPlain(material.name()), "&7Klick setzt dieses Item.", "&8" + material.name()));
        }
        inventory.setItem(45, button(Material.ARROW, "&eVorherige Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        inventory.setItem(49, button(Material.BARRIER, "&cZurueck", "&7Zum Item-Editor."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handleMaterialPickerClick(Player player, MaterialPickerHolder holder, int rawSlot) {
        MaterialCategory[] categories = MaterialCategory.values();
        if (rawSlot >= 0 && rawSlot < Math.min(18, categories.length)) {
            openMaterialPicker(player, holder.menuId, holder.itemId, categories[rawSlot], 0);
            return;
        }
        if (rawSlot == 45) {
            openMaterialPicker(player, holder.menuId, holder.itemId, holder.category, holder.page - 1);
            return;
        }
        if (rawSlot == 49) {
            openItemEditor(player, holder.menuId, holder.itemId);
            return;
        }
        if (rawSlot == 53) {
            openMaterialPicker(player, holder.menuId, holder.itemId, holder.category, holder.page + 1);
            return;
        }
        if (rawSlot < 18 || rawSlot > 44) {
            return;
        }
        List<Material> materials = materialsForCategory(holder.category);
        int index = holder.page * 27 + (rawSlot - 18);
        if (index < 0 || index >= materials.size()) {
            return;
        }
        Material material = materials.get(index);
        getConfig().set(itemPath(holder.menuId, holder.itemId) + ".material", material.name());
        saveConfig();
        openItemEditor(player, holder.menuId, holder.itemId);
    }

    private List<Material> materialsForCategory(MaterialCategory category) {
        List<Material> materials = new ArrayList<>();
        for (Material material : Material.values()) {
            if (!material.isItem() || material.isAir() || material.name().startsWith("LEGACY_")) {
                continue;
            }
            if (category.matches(material)) {
                materials.add(material);
            }
        }
        materials.sort(Comparator.comparing(Material::name));
        return materials;
    }

    private void openTextDesign(Player player, String menuId, String itemId, TextTarget target) {
        TextDesignHolder holder = new TextDesignHolder(menuId, itemId, target);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Text Design &8- &e" + target.label));
        holder.inventory = inventory;
        inventory.setItem(4, buildItem(menuId, itemId, true));

        String[] colors = {"&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", "&8", "&9", "&a", "&b", "&c", "&d", "&e", "&f"};
        Material[] colorMaterials = {
            Material.BLACK_CONCRETE, Material.BLUE_CONCRETE, Material.GREEN_CONCRETE, Material.CYAN_CONCRETE,
            Material.RED_CONCRETE, Material.PURPLE_CONCRETE, Material.ORANGE_CONCRETE, Material.LIGHT_GRAY_CONCRETE,
            Material.GRAY_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.LIME_CONCRETE, Material.LIGHT_BLUE_STAINED_GLASS,
            Material.RED_STAINED_GLASS, Material.MAGENTA_CONCRETE, Material.YELLOW_CONCRETE, Material.WHITE_CONCRETE
        };
        for (int i = 0; i < colors.length; i++) {
            inventory.setItem(9 + i, button(colorMaterials[i], colors[i] + "Farbe " + colors[i], "&7Klick setzt diese Farbe."));
        }

        inventory.setItem(27, button(Material.GOLD_INGOT, "&lFett", "&7Schaltet &f&l&7 um."));
        inventory.setItem(28, button(Material.FEATHER, "&oKursiv", "&7Schaltet &f&oKursiv&7 um."));
        inventory.setItem(29, button(Material.STRING, "&nUnterstrichen", "&7Schaltet &f&nUnterstrichen&7 um."));
        inventory.setItem(30, button(Material.IRON_BARS, "&mDurchgestrichen", "&7Schaltet &f&mDurchgestrichen&7 um."));
        inventory.setItem(31, button(Material.BARRIER, "&cReset Design", "&7Entfernt fuehrende Farb-/Stylecodes."));

        TextPreset[] presets = TextPreset.values();
        for (int i = 0; i < Math.min(9, presets.length); i++) {
            TextPreset preset = presets[i];
            inventory.setItem(36 + i, button(preset.icon, preset.label, "&7Klick wendet dieses RSL-Design an."));
        }

        inventory.setItem(48, button(Material.NAME_TAG, "&eText schreiben", "&7Oeffnet die freie Texteingabe."));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Item-Editor."));
        player.openInventory(inventory);
    }

    private void handleTextDesignClick(Player player, TextDesignHolder holder, int rawSlot) {
        String[] colors = {"&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", "&8", "&9", "&a", "&b", "&c", "&d", "&e", "&f"};
        if (rawSlot >= 9 && rawSlot < 25) {
            applyTextColor(holder.menuId, holder.itemId, holder.target, colors[rawSlot - 9]);
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot == 27) {
            toggleTextStyle(holder.menuId, holder.itemId, holder.target, "&l");
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot == 28) {
            toggleTextStyle(holder.menuId, holder.itemId, holder.target, "&o");
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot == 29) {
            toggleTextStyle(holder.menuId, holder.itemId, holder.target, "&n");
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot == 30) {
            toggleTextStyle(holder.menuId, holder.itemId, holder.target, "&m");
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot == 31) {
            applyTextPreset(holder.menuId, holder.itemId, holder.target, TextPreset.RESET);
            openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            return;
        }
        if (rawSlot >= 36 && rawSlot < 45) {
            TextPreset[] presets = TextPreset.values();
            int index = rawSlot - 36;
            if (index < presets.length) {
                applyTextPreset(holder.menuId, holder.itemId, holder.target, presets[index]);
                openTextDesign(player, holder.menuId, holder.itemId, holder.target);
            }
            return;
        }
        if (rawSlot == 48) {
            InputType type = holder.target == TextTarget.NAME ? InputType.ITEM_NAME : InputType.ITEM_LORE;
            String prompt = holder.target == TextTarget.NAME
                ? "&eNeuen Item-Namen eingeben. &7Farbcodes mit &."
                : "&eNeue Lore eingeben. &7Zeilen mit &f| &7trennen.";
            beginInput(player, new PendingInput(type, holder.menuId, holder.itemId, -1), prompt);
            return;
        }
        if (rawSlot == 49) {
            openItemEditor(player, holder.menuId, holder.itemId);
        }
    }

    private void openCommandEditor(Player player, String menuId, String itemId) {
        CommandEditorHolder holder = new CommandEditorHolder(menuId, itemId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&cCommands &8- &e" + itemId));
        holder.inventory = inventory;
        List<String> commands = getConfig().getStringList(itemPath(menuId, itemId) + ".commands");
        for (int i = 0; i < Math.min(45, commands.size()); i++) {
            inventory.setItem(i, button(Material.COMMAND_BLOCK, "&c#" + (i + 1), "&f" + commands.get(i), "&7Linksklick: Argument-Builder", "&7Rechtsklick: loeschen"));
        }
        inventory.setItem(45, button(Material.LIME_DYE, "&aServer-Command hinzufuegen", "&7Oeffnet alle bekannten Plugin-/Server-Commands."));
        inventory.setItem(46, button(Material.OAK_DOOR, "&6Close-Aktion hinzufuegen", "&7Schliesst das Menue beim Klick."));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Item-Editor."));
        player.openInventory(inventory);
    }

    private void handleCommandEditorClick(Player player, String menuId, String itemId, int rawSlot, ClickType click) {
        List<String> commands = getConfig().getStringList(itemPath(menuId, itemId) + ".commands");
        if (rawSlot == 45) {
            openCommandBrowser(player, menuId, itemId, -1, "all", 0);
            return;
        }
        if (rawSlot == 46) {
            commands.add("close");
            getConfig().set(itemPath(menuId, itemId) + ".commands", commands);
            saveConfig();
            openCommandEditor(player, menuId, itemId);
            return;
        }
        if (rawSlot == 49) {
            openItemEditor(player, menuId, itemId);
            return;
        }
        if (rawSlot >= 0 && rawSlot < commands.size()) {
            if (click.isRightClick()) {
                openConfirm(player, ConfirmType.DELETE_COMMAND, menuId, itemId, rawSlot, "&cCommand loeschen?", "&f" + commands.get(rawSlot));
            } else {
                openBuilderForAction(player, menuId, itemId, rawSlot, commands.get(rawSlot), "all");
            }
        }
    }

    private void openPicker(Player player, PickerKind kind, String menuId, String itemId, int page) {
        openPicker(player, kind, menuId, itemId, -1, "all", page);
    }

    private void openPicker(Player player, PickerKind kind, String menuId, String itemId, int index, String group, int page) {
        PickerHolder holder = new PickerHolder(kind, menuId, itemId, index, group, page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color(pickerTitle(kind)));
        holder.inventory = inventory;
        List<PickerOption> options = pickerOptions(kind);
        int maxPage = Math.max(0, (options.size() - 1) / 45);
        int safePage = clamp(page, 0, maxPage);
        holder.page = safePage;
        int start = safePage * 45;
        for (int i = 0; i < 45 && start + i < options.size(); i++) {
            PickerOption option = options.get(start + i);
            inventory.setItem(i, button(option.material, option.label, option.lore.toArray(new String[0])));
        }
        inventory.setItem(45, button(Material.ARROW, "&eVorherige Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        inventory.setItem(49, button(Material.BARRIER, "&cZurueck", "&7Ohne Aenderung zurueck."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handlePickerClick(Player player, PickerHolder holder, int rawSlot) {
        if (rawSlot == 45) {
            openPicker(player, holder.kind, holder.menuId, holder.itemId, holder.index, holder.group, holder.page - 1);
            return;
        }
        if (rawSlot == 49) {
            reopenAfterPicker(player, holder);
            return;
        }
        if (rawSlot == 53) {
            openPicker(player, holder.kind, holder.menuId, holder.itemId, holder.index, holder.group, holder.page + 1);
            return;
        }
        List<PickerOption> options = pickerOptions(holder.kind);
        int optionIndex = holder.page * 45 + rawSlot;
        if (rawSlot < 0 || rawSlot >= 45 || optionIndex < 0 || optionIndex >= options.size()) {
            return;
        }
        applyPickerValue(player, holder, options.get(optionIndex).value);
    }

    private void applyPickerValue(Player player, PickerHolder holder, String value) {
        if (holder.kind == PickerKind.COMMAND_GROUP) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, value, 0);
            return;
        }
        if (holder.kind == PickerKind.MENU_SOUND) {
            getConfig().set("menus." + holder.menuId + ".open-sound", value.equals("none") ? "" : value);
            saveConfig();
            openMenuSettings(player, holder.menuId);
            return;
        }
        String base = itemPath(holder.menuId, holder.itemId);
        if (holder.kind == PickerKind.ITEM_SOUND) {
            getConfig().set(base + ".sound", value.equals("none") ? "" : value);
        } else if (holder.kind == PickerKind.CATEGORY) {
            getConfig().set(base + ".category", value);
        } else if (holder.kind == PickerKind.PERMISSION) {
            getConfig().set(base + ".permission", value.equals("none") ? "" : value);
        } else if (holder.kind == PickerKind.TARGET_MENU) {
            getConfig().set(base + ".menu", value.equals("none") ? "" : value);
        }
        saveConfig();
        openItemEditor(player, holder.menuId, holder.itemId);
    }

    private void reopenAfterPicker(Player player, PickerHolder holder) {
        if (holder.kind == PickerKind.MENU_SOUND) {
            openMenuSettings(player, holder.menuId);
        } else if (holder.kind == PickerKind.COMMAND_GROUP) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, holder.group, 0);
        } else {
            openItemEditor(player, holder.menuId, holder.itemId);
        }
    }

    private String pickerTitle(PickerKind kind) {
        return switch (kind) {
            case ITEM_SOUND, MENU_SOUND -> "&dSound auswaehlen";
            case CATEGORY -> "&eKategorie auswaehlen";
            case PERMISSION -> "&cPermission auswaehlen";
            case TARGET_MENU -> "&aUntermenue auswaehlen";
            case COMMAND_GROUP -> "&6Command-Gruppe auswaehlen";
        };
    }

    private List<PickerOption> pickerOptions(PickerKind kind) {
        if (kind == PickerKind.ITEM_SOUND || kind == PickerKind.MENU_SOUND) {
            return soundOptions();
        }
        if (kind == PickerKind.CATEGORY) {
            return categoryOptions();
        }
        if (kind == PickerKind.PERMISSION) {
            return permissionOptions();
        }
        if (kind == PickerKind.TARGET_MENU) {
            return menuOptions();
        }
        return commandGroupOptions();
    }

    private List<PickerOption> soundOptions() {
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add("none");
        names.addAll(Arrays.asList(
            "UI_BUTTON_CLICK",
            "BLOCK_NOTE_BLOCK_PLING",
            "ENTITY_PLAYER_LEVELUP",
            "ENTITY_ENDERMAN_TELEPORT",
            "BLOCK_PORTAL_TRIGGER",
            "UI_TOAST_CHALLENGE_COMPLETE",
            "BLOCK_NOTE_BLOCK_BASS",
            "ENTITY_EXPERIENCE_ORB_PICKUP",
            "BLOCK_AMETHYST_BLOCK_CHIME",
            "ENTITY_FIREWORK_ROCKET_LAUNCH"
        ));
        for (Sound sound : Sound.values()) {
            names.add(sound.name());
        }
        List<PickerOption> options = new ArrayList<>();
        for (String name : names) {
            Material material = name.equals("none") ? Material.BARRIER : Material.NOTE_BLOCK;
            String label = name.equals("none") ? "&cKein Sound" : "&d" + name;
            options.add(new PickerOption(name, label, material, "&7Klick zum Auswaehlen."));
        }
        return options;
    }

    private List<PickerOption> categoryOptions() {
        LinkedHashSet<String> categories = new LinkedHashSet<>(Arrays.asList("Server", "Welten", "Teleport", "Wirtschaft", "Shop", "Community", "Info", "Admin", "Neu"));
        for (String menuId : menuIds()) {
            for (String itemId : itemIds(menuId)) {
                String category = getConfig().getString(itemPath(menuId, itemId) + ".category", "");
                if (category != null && !category.isBlank()) {
                    categories.add(category);
                }
            }
        }
        return categories.stream()
            .map(category -> new PickerOption(category, "&e" + category, Material.OAK_SIGN, "&7Klick zum Setzen."))
            .collect(Collectors.toList());
    }

    private List<PickerOption> permissionOptions() {
        LinkedHashSet<String> permissions = new LinkedHashSet<>();
        permissions.add("none");
        permissions.add("rslnavigator.open");
        permissions.add("rslnavigator.admin");
        for (Permission permission : Bukkit.getPluginManager().getPermissions()) {
            permissions.add(permission.getName());
        }
        List<String> sorted = new ArrayList<>(permissions);
        sorted.sort(String.CASE_INSENSITIVE_ORDER);
        if (sorted.remove("none")) {
            sorted.add(0, "none");
        }
        List<PickerOption> options = new ArrayList<>();
        for (String permission : sorted) {
            Material material = permission.equals("none") ? Material.BARRIER : Material.IRON_DOOR;
            String label = permission.equals("none") ? "&cKeine Permission" : "&c" + permission;
            options.add(new PickerOption(permission, label, material, "&7Klick zum Setzen."));
        }
        return options;
    }

    private List<PickerOption> menuOptions() {
        List<PickerOption> options = new ArrayList<>();
        options.add(new PickerOption("none", "&cKein Untermenue", Material.BARRIER, "&7Entfernt das Ziel-Menue."));
        for (String menuId : menuIds()) {
            options.add(new PickerOption(menuId, "&a" + menuId, Material.CHEST, "&7Klick setzt dieses Untermenue."));
        }
        return options;
    }

    private List<PickerOption> commandGroupOptions() {
        LinkedHashSet<String> groups = new LinkedHashSet<>();
        groups.add("all");
        for (CommandEntry entry : commandEntries()) {
            groups.add(entry.group);
        }
        List<PickerOption> options = new ArrayList<>();
        for (String group : groups) {
            String label = group.equals("all") ? "&6Alle Commands" : "&e" + group;
            Material material = group.equals("all") ? Material.COMMAND_BLOCK : Material.PAPER;
            options.add(new PickerOption(group, label, material, "&7Klick filtert den Command-Browser."));
        }
        return options;
    }

    private void openNumberPicker(Player player, NumberKind kind, String menuId, String itemId, int index) {
        NumberPickerHolder holder = new NumberPickerHolder(kind, menuId, itemId, index);
        Inventory inventory = Bukkit.createInventory(holder, 27, color(numberTitle(kind)));
        holder.inventory = inventory;
        int value = numberValue(kind, menuId, itemId);
        inventory.setItem(4, button(numberMaterial(kind), "&eAktuell: &f" + numberLabel(kind, value), "&7Klick auf Plus/Minus aendert direkt."));
        inventory.setItem(9, button(Material.REDSTONE_BLOCK, "&c-" + numberBigStep(kind), "&7Wert stark senken."));
        inventory.setItem(11, button(Material.REDSTONE, "&c-" + numberSmallStep(kind), "&7Wert senken."));
        inventory.setItem(13, button(Material.PAPER, "&6Wert", "&f" + numberLabel(kind, value)));
        inventory.setItem(15, button(Material.EMERALD, "&a+" + numberSmallStep(kind), "&7Wert erhoehen."));
        inventory.setItem(17, button(Material.EMERALD_BLOCK, "&a+" + numberBigStep(kind), "&7Wert stark erhoehen."));
        inventory.setItem(20, button(Material.BARRIER, "&cReset", "&7Setzt den Standardwert."));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zurueck zum Editor."));
        player.openInventory(inventory);
    }

    private void handleNumberPickerClick(Player player, NumberPickerHolder holder, int rawSlot) {
        if (rawSlot == 22) {
            reopenAfterNumberPicker(player, holder);
            return;
        }
        int value = numberValue(holder.kind, holder.menuId, holder.itemId);
        if (rawSlot == 9) {
            value -= numberBigStep(holder.kind);
        } else if (rawSlot == 11) {
            value -= numberSmallStep(holder.kind);
        } else if (rawSlot == 15) {
            value += numberSmallStep(holder.kind);
        } else if (rawSlot == 17) {
            value += numberBigStep(holder.kind);
        } else if (rawSlot == 20) {
            value = numberDefault(holder.kind);
        } else {
            return;
        }
        setNumberValue(holder.kind, holder.menuId, holder.itemId, value);
        openNumberPicker(player, holder.kind, holder.menuId, holder.itemId, holder.index);
    }

    private void reopenAfterNumberPicker(Player player, NumberPickerHolder holder) {
        if (holder.kind == NumberKind.MENU_SIZE) {
            openMenuSettings(player, holder.menuId);
        } else if (holder.kind == NumberKind.SETTINGS_COOLDOWN) {
            loadSettings();
            openSettings(player);
        } else {
            openItemEditor(player, holder.menuId, holder.itemId);
        }
    }

    private int numberValue(NumberKind kind, String menuId, String itemId) {
        return switch (kind) {
            case MENU_SIZE -> menuSize(menuId);
            case ITEM_AMOUNT -> getConfig().getInt(itemPath(menuId, itemId) + ".amount", 1);
            case ITEM_CUSTOM_MODEL_DATA -> getConfig().getInt(itemPath(menuId, itemId) + ".custom-model-data", 0);
            case SETTINGS_COOLDOWN -> (int) clickCooldownMs;
        };
    }

    private void setNumberValue(NumberKind kind, String menuId, String itemId, int value) {
        int normalized = normalizeNumber(kind, value);
        if (kind == NumberKind.MENU_SIZE) {
            getConfig().set("menus." + menuId + ".size", normalized);
        } else if (kind == NumberKind.ITEM_AMOUNT) {
            getConfig().set(itemPath(menuId, itemId) + ".amount", normalized);
        } else if (kind == NumberKind.ITEM_CUSTOM_MODEL_DATA) {
            getConfig().set(itemPath(menuId, itemId) + ".custom-model-data", normalized);
        } else if (kind == NumberKind.SETTINGS_COOLDOWN) {
            getConfig().set("settings.click-cooldown-ms", normalized);
            clickCooldownMs = normalized;
        }
        saveConfig();
    }

    private int normalizeNumber(NumberKind kind, int value) {
        return switch (kind) {
            case MENU_SIZE -> parseSize(String.valueOf(value), 54);
            case ITEM_AMOUNT -> clamp(value, 1, 64);
            case ITEM_CUSTOM_MODEL_DATA -> clamp(value, 0, 999999);
            case SETTINGS_COOLDOWN -> clamp(value, 0, 10000);
        };
    }

    private int numberSmallStep(NumberKind kind) {
        return kind == NumberKind.MENU_SIZE ? 9 : 1;
    }

    private int numberBigStep(NumberKind kind) {
        return switch (kind) {
            case MENU_SIZE -> 9;
            case ITEM_AMOUNT -> 10;
            case ITEM_CUSTOM_MODEL_DATA -> 100;
            case SETTINGS_COOLDOWN -> 100;
        };
    }

    private int numberDefault(NumberKind kind) {
        return switch (kind) {
            case MENU_SIZE -> 54;
            case ITEM_AMOUNT -> 1;
            case ITEM_CUSTOM_MODEL_DATA -> 0;
            case SETTINGS_COOLDOWN -> 350;
        };
    }

    private String numberTitle(NumberKind kind) {
        return switch (kind) {
            case MENU_SIZE -> "&6Menue-Groesse";
            case ITEM_AMOUNT -> "&bItem-Menge";
            case ITEM_CUSTOM_MODEL_DATA -> "&bCustomModelData";
            case SETTINGS_COOLDOWN -> "&6Click-Cooldown";
        };
    }

    private Material numberMaterial(NumberKind kind) {
        return switch (kind) {
            case MENU_SIZE -> Material.CHEST;
            case ITEM_AMOUNT -> Material.ITEM_FRAME;
            case ITEM_CUSTOM_MODEL_DATA -> Material.MAP;
            case SETTINGS_COOLDOWN -> Material.CLOCK;
        };
    }

    private String numberLabel(NumberKind kind, int value) {
        return kind == NumberKind.SETTINGS_COOLDOWN ? value + "ms" : String.valueOf(value);
    }

    private void openCommandBrowser(Player player, String menuId, String itemId, int index, String group, int page) {
        CommandBrowserHolder holder = new CommandBrowserHolder(menuId, itemId, index, group == null ? "all" : group, page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&cServer-Commands &8- &e" + (holder.group.equals("all") ? "alle" : holder.group)));
        holder.inventory = inventory;
        List<CommandEntry> entries = filteredCommandEntries(holder.group);
        int maxPage = Math.max(0, (entries.size() - 1) / 45);
        int safePage = clamp(page, 0, maxPage);
        holder.page = safePage;
        int start = safePage * 45;
        for (int i = 0; i < 45 && start + i < entries.size(); i++) {
            CommandEntry entry = entries.get(start + i);
            inventory.setItem(i, button(Material.COMMAND_BLOCK, "&e/" + entry.label,
                "&7Gruppe: &f" + entry.group,
                "&7Plugin: &f" + entry.plugin,
                "&7Beschreibung: &f" + blankDash(entry.description),
                "&7Linksklick: &aplayer:" + entry.label,
                "&7Rechtsklick: &cconsole:" + entry.label,
                "&7Shift-Klick: Argument-Presets"));
        }
        inventory.setItem(45, button(Material.ARROW, "&eVorherige Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        inventory.setItem(46, button(Material.HOPPER, "&6Gruppe/Plugin filtern", "&7Aktuell: &e" + holder.group));
        inventory.setItem(49, button(Material.BARRIER, "&cZurueck", "&7Zum Command-Editor."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handleCommandBrowserClick(Player player, CommandBrowserHolder holder, int rawSlot, ClickType click) {
        if (rawSlot == 45) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, holder.group, holder.page - 1);
            return;
        }
        if (rawSlot == 46) {
            openPicker(player, PickerKind.COMMAND_GROUP, holder.menuId, holder.itemId, holder.index, holder.group, 0);
            return;
        }
        if (rawSlot == 49) {
            openCommandEditor(player, holder.menuId, holder.itemId);
            return;
        }
        if (rawSlot == 53) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, holder.group, holder.page + 1);
            return;
        }
        List<CommandEntry> entries = filteredCommandEntries(holder.group);
        int entryIndex = holder.page * 45 + rawSlot;
        if (rawSlot < 0 || rawSlot >= 45 || entryIndex < 0 || entryIndex >= entries.size()) {
            return;
        }
        CommandEntry entry = entries.get(entryIndex);
        CommandMode mode = click.isRightClick() ? CommandMode.CONSOLE : CommandMode.PLAYER;
        openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, mode, entry.label, Collections.emptyList(), entry.group);
    }

    private void openBuilderForAction(Player player, String menuId, String itemId, int index, String action, String group) {
        String lower = action.toLowerCase(Locale.ROOT);
        CommandMode mode;
        String commandLine;
        if (lower.startsWith("console:")) {
            mode = CommandMode.CONSOLE;
            commandLine = action.substring(8).trim();
        } else if (lower.startsWith("player:")) {
            mode = CommandMode.PLAYER;
            commandLine = action.substring(7).trim();
        } else {
            player.sendMessage(color(prefix() + "&cDieser Eintrag ist keine player:/console: Aktion. Nutze Rechtsklick zum Loeschen oder fuege einen neuen Command hinzu."));
            openCommandEditor(player, menuId, itemId);
            return;
        }
        if (commandLine.isBlank()) {
            openCommandBrowser(player, menuId, itemId, index, group, 0);
            return;
        }
        String[] parts = commandLine.split("\\s+");
        String command = parts[0];
        List<String> args = new ArrayList<>();
        for (int i = 1; i < parts.length; i++) {
            args.add(parts[i]);
        }
        openCommandBuilder(player, menuId, itemId, index, mode, command, args, group);
    }

    private void openCommandBuilder(Player player, String menuId, String itemId, int index, CommandMode mode, String command, List<String> args, String group) {
        CommandBuilderHolder holder = new CommandBuilderHolder(menuId, itemId, index, mode, command, args, group == null ? "all" : group);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Command Builder &8- &e/" + command));
        holder.inventory = inventory;

        inventory.setItem(4, button(Material.COMMAND_BLOCK, "&eVorschau",
            "&f" + buildActionPreview(holder),
            "&7Argumente: &e" + holder.args.size()));
        inventory.setItem(10, button(Material.REPEATER, "&6Modus wechseln", "&7Aktuell: &e" + holder.mode.prefix, "&7Wechselt Player/Console."));
        inventory.setItem(11, button(Material.EMERALD_BLOCK, "&aSpeichern", "&7Speichert den Command beim Item."));
        inventory.setItem(12, button(Material.ARROW, "&eZurueck", "&7Zur Command-Liste."));
        inventory.setItem(13, button(Material.SHEARS, "&cLetztes Argument loeschen", "&7Entfernt den letzten Baustein."));
        inventory.setItem(14, button(Material.NAME_TAG, "&bEigener Wert", "&7Oeffnet Amboss-GUI fuer ein freies Argument."));
        inventory.setItem(16, button(Material.HOPPER, "&6Anderen Command waehlen", "&7Zurueck zum Command-Browser."));

        renderCommandTemplate(player, holder, inventory);
        inventory.setItem(41, button(Material.BARRIER, "&cLeeren", "&7Entfernt alle Argumente."));
        player.openInventory(inventory);
    }

    private void handleCommandBuilderClick(Player player, CommandBuilderHolder holder, int rawSlot) {
        if (rawSlot == 10) {
            CommandMode nextMode = holder.mode == CommandMode.PLAYER ? CommandMode.CONSOLE : CommandMode.PLAYER;
            openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, nextMode, holder.command, holder.args, holder.group);
            return;
        }
        if (rawSlot == 11) {
            addOrReplaceCommand(player, holder.menuId, holder.itemId, holder.index, buildActionPreview(holder));
            return;
        }
        if (rawSlot == 12) {
            openCommandEditor(player, holder.menuId, holder.itemId);
            return;
        }
        if (rawSlot == 13) {
            List<String> args = new ArrayList<>(holder.args);
            if (!args.isEmpty()) {
                args.remove(args.size() - 1);
            }
            openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, holder.mode, holder.command, args, holder.group);
            return;
        }
        if (rawSlot == 14) {
            openAnvilInput(player, holder, "argument");
            return;
        }
        if (rawSlot == 16) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, holder.group, 0);
            return;
        }
        if (rawSlot == 41) {
            openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, holder.mode, holder.command, Collections.emptyList(), holder.group);
            return;
        }

        if (handleTemplateSpecial(player, holder, rawSlot)) {
            return;
        }
        String argument = templateArgument(player, holder, rawSlot);
        if (argument != null) {
            appendBuilderArgument(player, holder, argument);
        }
    }

    private void renderCommandTemplate(Player player, CommandBuilderHolder holder, Inventory inventory) {
        CommandTemplate template = templateFor(holder.command);
        inventory.setItem(18, button(Material.KNOWLEDGE_BOOK, "&6Layout: &e" + template.label, "&7Passende Bausteine fuer diesen Command.", "&8Command: " + holder.command));
        if (template == CommandTemplate.TELEPORT) {
            inventory.setItem(19, button(Material.PLAYER_HEAD, "&aZiel: @a", "&7Alle Spieler."));
            inventory.setItem(20, button(Material.PLAYER_HEAD, "&aZiel: @p", "&7Naechster Spieler."));
            inventory.setItem(21, button(Material.PAPER, "&aZiel: <player>", "&7Klickender Spieler."));
            inventory.setItem(22, button(Material.LODESTONE, "&6Feste Admin-Koordinaten", "&f" + fixedBlockCoordinates(player)));
            inventory.setItem(23, button(Material.ENDER_EYE, "&bLaufzeit-Koordinaten", "&7<x> <y> <z>"));
            inventory.setItem(28, button(Material.COMPASS, "&bLaufzeit-Blockkoordinaten", "&7<block_x> <block_y> <block_z>"));
            inventory.setItem(29, button(Material.TARGET, "&dRelative Koordinaten", "&7~ ~ ~"));
            inventory.setItem(30, button(Material.OBSERVER, "&dBlickrichtung", "&7<yaw> <pitch>"));
            inventory.setItem(31, button(Material.PLAYER_HEAD, "&aZiel: @s", "&7Ausfuehrender Spieler."));
            inventory.setItem(32, button(Material.ZOMBIE_HEAD, "&aZiel: @e", "&7Alle Entities."));
        } else if (template == CommandTemplate.GIVE) {
            inventory.setItem(19, button(Material.PAPER, "&aZiel: <player>", "&7Klickender Spieler."));
            inventory.setItem(20, button(Material.PLAYER_HEAD, "&aZiel: @a", "&7Alle Spieler."));
            inventory.setItem(21, button(Material.NAME_TAG, "&bItem per Amboss", "&7z.B. minecraft:diamond"));
            inventory.setItem(22, button(Material.DIAMOND, "&bItem: minecraft:diamond", "&7Direkt anhaengen."));
            inventory.setItem(23, button(Material.STONE, "&bItem: minecraft:stone", "&7Direkt anhaengen."));
            inventory.setItem(28, button(Material.EMERALD, "&aMenge 1", "&7Direkt anhaengen."));
            inventory.setItem(29, button(Material.EMERALD, "&aMenge 10", "&7Direkt anhaengen."));
            inventory.setItem(30, button(Material.EMERALD, "&aMenge 64", "&7Direkt anhaengen."));
        } else if (template == CommandTemplate.GAMEMODE) {
            inventory.setItem(19, button(Material.GRASS_BLOCK, "&aSurvival", "&7survival"));
            inventory.setItem(20, button(Material.COMMAND_BLOCK, "&bCreative", "&7creative"));
            inventory.setItem(21, button(Material.MAP, "&6Adventure", "&7adventure"));
            inventory.setItem(22, button(Material.ENDER_EYE, "&7Spectator", "&7spectator"));
            inventory.setItem(28, button(Material.PAPER, "&aZiel: <player>", "&7Klickender Spieler."));
            inventory.setItem(29, button(Material.PLAYER_HEAD, "&aZiel: @a", "&7Alle Spieler."));
        } else if (template == CommandTemplate.EFFECT) {
            inventory.setItem(19, button(Material.LIME_DYE, "&aAktion: give", "&7Effekt geben."));
            inventory.setItem(20, button(Material.RED_DYE, "&cAktion: clear", "&7Effekte loeschen."));
            inventory.setItem(21, button(Material.PAPER, "&aZiel: <player>", "&7Klickender Spieler."));
            inventory.setItem(22, button(Material.PLAYER_HEAD, "&aZiel: @a", "&7Alle Spieler."));
            inventory.setItem(23, button(Material.NAME_TAG, "&bEffekt per Amboss", "&7z.B. minecraft:speed"));
            inventory.setItem(28, button(Material.SUGAR, "&bEffekt: minecraft:speed", "&7Direkt anhaengen."));
            inventory.setItem(29, button(Material.CLOCK, "&aDauer 30", "&7Sekunden/Ticks je nach Command."));
            inventory.setItem(30, button(Material.CLOCK, "&aDauer 60", "&7Sekunden/Ticks je nach Command."));
            inventory.setItem(31, button(Material.GLOWSTONE_DUST, "&aStaerke 1", "&7Direkt anhaengen."));
            inventory.setItem(32, button(Material.GLOWSTONE, "&aStaerke 2", "&7Direkt anhaengen."));
        } else if (template == CommandTemplate.MULTIVERSE) {
            inventory.setItem(19, button(Material.ENDER_PEARL, "&aUnterbefehl: tp", "&7Fuer /mv tp."));
            inventory.setItem(20, button(Material.PAPER, "&aZiel: <player>", "&7Optionaler Spieler."));
            renderWorldButtons(inventory, 21);
            inventory.setItem(32, button(Material.NAME_TAG, "&bWelt per Amboss", "&7Eigener Weltname."));
        } else if (template == CommandTemplate.SPAWN) {
            inventory.setItem(19, button(Material.EMERALD_BLOCK, "&aDirekt speichern", "&7Spawn-Command braucht meist keine Argumente."));
            inventory.setItem(20, button(Material.PAPER, "&aOptional: <player>", "&7Falls ein Plugin Zielspieler erlaubt."));
        } else if (template == CommandTemplate.NAMED_LOCATION) {
            inventory.setItem(19, button(Material.NAME_TAG, "&bName per Amboss", "&7Warp/Home/SetHome Name."));
            inventory.setItem(20, button(Material.BEACON, "&aName: spawn", "&7Direkt anhaengen."));
            inventory.setItem(21, button(Material.GRASS_BLOCK, "&aName: survival", "&7Direkt anhaengen."));
            inventory.setItem(22, button(Material.NETHER_STAR, "&aName: lobby", "&7Direkt anhaengen."));
        } else if (template == CommandTemplate.MESSAGE) {
            inventory.setItem(19, button(Material.PAPER, "&aZiel: <player>", "&7Klickender Spieler."));
            inventory.setItem(20, button(Material.PLAYER_HEAD, "&aZiel: @a", "&7Alle Spieler, falls unterstuetzt."));
            inventory.setItem(21, button(Material.NAME_TAG, "&bNachricht per Amboss", "&7Freien Nachrichtentext anhaengen."));
        } else {
            renderGenericCommandTemplate(player, inventory);
        }
    }

    private void renderGenericCommandTemplate(Player player, Inventory inventory) {
        inventory.setItem(19, button(Material.PLAYER_HEAD, "&aSelector @a", "&7Alle Spieler anhaengen."));
        inventory.setItem(20, button(Material.PLAYER_HEAD, "&aSelector @p", "&7Naechster Spieler anhaengen."));
        inventory.setItem(21, button(Material.PLAYER_HEAD, "&aSelector @s", "&7Ausfuehrender Spieler anhaengen."));
        inventory.setItem(22, button(Material.PLAYER_HEAD, "&aSelector @r", "&7Zufaelliger Spieler anhaengen."));
        inventory.setItem(23, button(Material.ZOMBIE_HEAD, "&aSelector @e", "&7Alle Entities anhaengen."));
        inventory.setItem(28, button(Material.PAPER, "&b<player>", "&7Name des klickenden Spielers."));
        inventory.setItem(29, button(Material.GRASS_BLOCK, "&b<world>", "&7Welt des klickenden Spielers."));
        inventory.setItem(30, button(Material.ENDER_EYE, "&bLaufzeit-Koordinaten", "&7Fuegt <x> <y> <z> ein."));
        inventory.setItem(31, button(Material.COMPASS, "&bLaufzeit-Blockkoordinaten", "&7Fuegt <block_x> <block_y> <block_z> ein."));
        inventory.setItem(32, button(Material.LODESTONE, "&6Feste Admin-Koordinaten", "&7Nimmt deine aktuelle Position jetzt.", "&f" + fixedBlockCoordinates(player)));
        inventory.setItem(33, button(Material.TARGET, "&dRelative Koordinaten", "&7Fuegt ~ ~ ~ ein."));
        inventory.setItem(34, button(Material.OBSERVER, "&dBlickrichtung", "&7Fuegt <yaw> <pitch> ein."));
        inventory.setItem(37, button(Material.EMERALD, "&aZahl 1", "&7Fuegt 1 ein."));
        inventory.setItem(38, button(Material.EMERALD, "&aZahl 10", "&7Fuegt 10 ein."));
        inventory.setItem(39, button(Material.EMERALD, "&aZahl 64", "&7Fuegt 64 ein."));
        inventory.setItem(40, button(Material.EMERALD, "&aZahl 100", "&7Fuegt 100 ein."));
    }

    private boolean handleTemplateSpecial(Player player, CommandBuilderHolder holder, int rawSlot) {
        CommandTemplate template = templateFor(holder.command);
        if (template == CommandTemplate.GIVE && rawSlot == 21) {
            openAnvilInput(player, holder, "minecraft:diamond");
            return true;
        }
        if (template == CommandTemplate.EFFECT && rawSlot == 23) {
            openAnvilInput(player, holder, "minecraft:speed");
            return true;
        }
        if (template == CommandTemplate.MULTIVERSE && rawSlot == 32) {
            openAnvilInput(player, holder, "world");
            return true;
        }
        if (template == CommandTemplate.SPAWN && rawSlot == 19) {
            addOrReplaceCommand(player, holder.menuId, holder.itemId, holder.index, buildActionPreview(holder));
            return true;
        }
        if (template == CommandTemplate.NAMED_LOCATION && rawSlot == 19) {
            openAnvilInput(player, holder, "spawn");
            return true;
        }
        if (template == CommandTemplate.MESSAGE && rawSlot == 21) {
            openAnvilInput(player, holder, "Hallo");
            return true;
        }
        return false;
    }

    private String templateArgument(Player player, CommandBuilderHolder holder, int rawSlot) {
        CommandTemplate template = templateFor(holder.command);
        return switch (template) {
            case TELEPORT -> teleportArgument(player, rawSlot);
            case GIVE -> giveArgument(rawSlot);
            case GAMEMODE -> gamemodeArgument(rawSlot);
            case EFFECT -> effectArgument(rawSlot);
            case MULTIVERSE -> multiverseArgument(rawSlot);
            case SPAWN -> rawSlot == 20 ? "<player>" : null;
            case NAMED_LOCATION -> namedLocationArgument(rawSlot);
            case MESSAGE -> messageArgument(rawSlot);
            case GENERIC -> genericArgument(player, rawSlot);
        };
    }

    private String teleportArgument(Player player, int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "@a";
            case 20 -> "@p";
            case 21 -> "<player>";
            case 22 -> fixedBlockCoordinates(player);
            case 23 -> "<x> <y> <z>";
            case 28 -> "<block_x> <block_y> <block_z>";
            case 29 -> "~ ~ ~";
            case 30 -> "<yaw> <pitch>";
            case 31 -> "@s";
            case 32 -> "@e";
            default -> null;
        };
    }

    private String giveArgument(int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "<player>";
            case 20 -> "@a";
            case 22 -> "minecraft:diamond";
            case 23 -> "minecraft:stone";
            case 28 -> "1";
            case 29 -> "10";
            case 30 -> "64";
            default -> null;
        };
    }

    private String gamemodeArgument(int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "survival";
            case 20 -> "creative";
            case 21 -> "adventure";
            case 22 -> "spectator";
            case 28 -> "<player>";
            case 29 -> "@a";
            default -> null;
        };
    }

    private String effectArgument(int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "give";
            case 20 -> "clear";
            case 21 -> "<player>";
            case 22 -> "@a";
            case 28 -> "minecraft:speed";
            case 29 -> "30";
            case 30 -> "60";
            case 31 -> "1";
            case 32 -> "2";
            default -> null;
        };
    }

    private String multiverseArgument(int rawSlot) {
        if (rawSlot == 19) {
            return "tp";
        }
        if (rawSlot == 20) {
            return "<player>";
        }
        int worldIndex = rawSlot - 21;
        List<World> worlds = Bukkit.getWorlds();
        if (worldIndex >= 0 && worldIndex < Math.min(11, worlds.size())) {
            return worlds.get(worldIndex).getName();
        }
        return null;
    }

    private String namedLocationArgument(int rawSlot) {
        return switch (rawSlot) {
            case 20 -> "spawn";
            case 21 -> "survival";
            case 22 -> "lobby";
            default -> null;
        };
    }

    private String messageArgument(int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "<player>";
            case 20 -> "@a";
            default -> null;
        };
    }

    private String genericArgument(Player player, int rawSlot) {
        return switch (rawSlot) {
            case 19 -> "@a";
            case 20 -> "@p";
            case 21 -> "@s";
            case 22 -> "@r";
            case 23 -> "@e";
            case 28 -> "<player>";
            case 29 -> "<world>";
            case 30 -> "<x> <y> <z>";
            case 31 -> "<block_x> <block_y> <block_z>";
            case 32 -> fixedBlockCoordinates(player);
            case 33 -> "~ ~ ~";
            case 34 -> "<yaw> <pitch>";
            case 37 -> "1";
            case 38 -> "10";
            case 39 -> "64";
            case 40 -> "100";
            default -> null;
        };
    }

    private void renderWorldButtons(Inventory inventory, int startSlot) {
        List<World> worlds = Bukkit.getWorlds();
        int max = Math.min(11, worlds.size());
        for (int i = 0; i < max; i++) {
            World world = worlds.get(i);
            inventory.setItem(startSlot + i, button(Material.GRASS_BLOCK, "&aWelt: &e" + world.getName(), "&7Fuegt diesen Welt-Namen ein."));
        }
    }

    private CommandTemplate templateFor(String command) {
        String key = commandKey(command);
        if (key.equals("teleport") || key.equals("tp")) {
            return CommandTemplate.TELEPORT;
        }
        if (key.equals("give")) {
            return CommandTemplate.GIVE;
        }
        if (key.equals("gamemode") || key.equals("gm")) {
            return CommandTemplate.GAMEMODE;
        }
        if (key.equals("effect")) {
            return CommandTemplate.EFFECT;
        }
        if (key.equals("mvtp") || key.equals("mv") || key.equals("multiverse")) {
            return CommandTemplate.MULTIVERSE;
        }
        if (key.equals("spawn") || key.equals("rslspawn")) {
            return CommandTemplate.SPAWN;
        }
        if (key.equals("warp") || key.equals("home") || key.equals("sethome")) {
            return CommandTemplate.NAMED_LOCATION;
        }
        if (key.equals("tell") || key.equals("msg") || key.equals("w") || key.equals("teammsg")) {
            return CommandTemplate.MESSAGE;
        }
        return CommandTemplate.GENERIC;
    }

    private String commandKey(String command) {
        String lower = command.toLowerCase(Locale.ROOT);
        int namespace = lower.indexOf(':');
        if (namespace >= 0 && namespace + 1 < lower.length()) {
            lower = lower.substring(namespace + 1);
        }
        return lower;
    }

    private void appendBuilderArgument(Player player, CommandBuilderHolder holder, String argument) {
        List<String> args = new ArrayList<>(holder.args);
        args.add(argument);
        openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, holder.mode, holder.command, args, holder.group);
    }

    private void openAnvilInput(Player player, CommandBuilderHolder builder, String initialText) {
        AnvilInputHolder holder = new AnvilInputHolder(builder.menuId, builder.itemId, builder.index, builder.mode, builder.command, builder.args, builder.group);
        Inventory inventory = Bukkit.createInventory(holder, InventoryType.ANVIL, color("&bFreies Argument"));
        holder.inventory = inventory;
        inventory.setItem(0, button(Material.PAPER, initialText, "&7Benenne dieses Item im Amboss um.", "&7Klicke danach auf das Ergebnis."));
        player.openInventory(inventory);
    }

    private void handleAnvilInputClick(Player player, AnvilInputHolder holder, int rawSlot, ItemStack clicked) {
        if (rawSlot != 2) {
            return;
        }
        String value = itemDisplayName(clicked);
        if (value.isBlank()) {
            value = "argument";
        }
        List<String> args = new ArrayList<>(holder.args);
        args.add(value);
        openCommandBuilder(player, holder.menuId, holder.itemId, holder.index, holder.mode, holder.command, args, holder.group);
    }

    private String itemDisplayName(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return "";
        }
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return ChatColor.stripColor(meta.getDisplayName()).trim();
        }
        return "";
    }

    private String buildActionPreview(CommandBuilderHolder holder) {
        StringBuilder builder = new StringBuilder(holder.mode.prefix).append(holder.command);
        for (String arg : holder.args) {
            if (arg != null && !arg.isBlank()) {
                builder.append(' ').append(arg.trim());
            }
        }
        return builder.toString();
    }

    private String fixedBlockCoordinates(Player player) {
        Location location = player.getLocation();
        return location.getBlockX() + " " + location.getBlockY() + " " + location.getBlockZ();
    }

    private void openArgumentEditorForAction(Player player, String menuId, String itemId, int index, String action) {
        String lower = action.toLowerCase(Locale.ROOT);
        CommandMode mode;
        String command;
        if (lower.startsWith("console:")) {
            mode = CommandMode.CONSOLE;
            command = action.substring(8).trim();
        } else if (lower.startsWith("player:")) {
            mode = CommandMode.PLAYER;
            command = action.substring(7).trim();
        } else {
            player.sendMessage(color(prefix() + "&cArgument-Presets gehen nur fuer player:/console: Commands."));
            openCommandEditor(player, menuId, itemId);
            return;
        }
        String baseCommand = command.split("\\s+", 2)[0];
        openCommandArguments(player, menuId, itemId, index, mode, baseCommand, "all");
    }

    private void openCommandArguments(Player player, String menuId, String itemId, int index, CommandMode mode, String command, String group) {
        CommandArgumentHolder holder = new CommandArgumentHolder(menuId, itemId, index, mode, command, group);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&6Argumente &8- &e/" + command));
        holder.inventory = inventory;
        inventory.setItem(4, button(Material.COMMAND_BLOCK, "&e/" + command, "&7Modus: &f" + mode.prefix, "&7Waehle ein Preset."));
        inventory.setItem(10, button(Material.PAPER, "&aOhne Argumente", "&f" + mode.prefix + command));
        inventory.setItem(11, button(Material.PLAYER_HEAD, "&a+ <player>", "&f" + mode.prefix + command + " <player>"));
        inventory.setItem(12, button(Material.GRASS_BLOCK, "&a+ <world>", "&f" + mode.prefix + command + " <world>"));
        inventory.setItem(13, button(Material.COMPASS, "&a+ <player> <world>", "&f" + mode.prefix + command + " <player> <world>"));
        inventory.setItem(14, button(Material.TARGET, "&a+ ~ ~ ~", "&f" + mode.prefix + command + " ~ ~ ~"));
        inventory.setItem(15, button(Material.EMERALD, "&a+ 1", "&f" + mode.prefix + command + " 1"));
        inventory.setItem(16, button(Material.EXPERIENCE_BOTTLE, "&a+ <player> 1", "&f" + mode.prefix + command + " <player> 1"));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zur Command-Liste."));
        player.openInventory(inventory);
    }

    private void handleCommandArgumentClick(Player player, CommandArgumentHolder holder, int rawSlot) {
        if (rawSlot == 22) {
            openCommandBrowser(player, holder.menuId, holder.itemId, holder.index, holder.group, 0);
            return;
        }
        String suffix = switch (rawSlot) {
            case 10 -> "";
            case 11 -> " <player>";
            case 12 -> " <world>";
            case 13 -> " <player> <world>";
            case 14 -> " ~ ~ ~";
            case 15 -> " 1";
            case 16 -> " <player> 1";
            default -> null;
        };
        if (suffix == null) {
            return;
        }
        addOrReplaceCommand(player, holder.menuId, holder.itemId, holder.index, holder.mode.prefix + holder.command + suffix);
    }

    private void addOrReplaceCommand(Player player, String menuId, String itemId, int index, String action) {
        List<String> commands = getConfig().getStringList(itemPath(menuId, itemId) + ".commands");
        if (index >= 0 && index < commands.size()) {
            commands.set(index, action);
        } else {
            commands.add(action);
        }
        getConfig().set(itemPath(menuId, itemId) + ".commands", commands);
        saveConfig();
        openCommandEditor(player, menuId, itemId);
    }

    private List<CommandEntry> filteredCommandEntries(String group) {
        List<CommandEntry> entries = commandEntries();
        if (group == null || group.equals("all")) {
            return entries;
        }
        return entries.stream()
            .filter(entry -> entry.group.equalsIgnoreCase(group))
            .collect(Collectors.toList());
    }

    private List<CommandEntry> commandEntries() {
        Map<String, Command> knownCommands = knownCommands();
        List<CommandEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Command> known : knownCommands.entrySet()) {
            String label = known.getKey();
            Command command = known.getValue();
            if (label == null || label.isBlank() || command == null) {
                continue;
            }
            String group = commandGroup(label, command);
            String plugin = commandPlugin(command, group);
            entries.add(new CommandEntry(label, group, plugin, command.getDescription(), command.getUsage()));
        }
        entries.sort(Comparator
            .comparing((CommandEntry entry) -> entry.group, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(entry -> entry.label, String.CASE_INSENSITIVE_ORDER));
        return entries;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Command> knownCommands() {
        try {
            Method method = Bukkit.getServer().getClass().getMethod("getCommandMap");
            Object commandMap = method.invoke(Bukkit.getServer());
            Field field = findField(commandMap.getClass(), "knownCommands");
            if (field == null) {
                return Collections.emptyMap();
            }
            field.setAccessible(true);
            Object value = field.get(commandMap);
            if (value instanceof Map<?, ?> rawMap) {
                Map<String, Command> result = new HashMap<>();
                for (Map.Entry<?, ?> entry : rawMap.entrySet()) {
                    if (entry.getKey() instanceof String key && entry.getValue() instanceof Command command) {
                        result.put(key, command);
                    }
                }
                return result;
            }
        } catch (ReflectiveOperationException | SecurityException ex) {
            getLogger().warning("Konnte Server-Commands nicht lesen: " + ex.getMessage());
        }
        return Collections.emptyMap();
    }

    private Field findField(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    private String commandGroup(String label, Command command) {
        int namespaceIndex = label.indexOf(':');
        if (namespaceIndex > 0) {
            return label.substring(0, namespaceIndex);
        }
        if (command instanceof PluginCommand pluginCommand) {
            return pluginCommand.getPlugin().getName();
        }
        return "server";
    }

    private String commandPlugin(Command command, String fallback) {
        if (command instanceof PluginCommand pluginCommand) {
            return pluginCommand.getPlugin().getName();
        }
        return fallback;
    }

    private String blankDash(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }

    private void openConfirm(Player player, ConfirmType type, String menuId, String itemId, int index, String title, String detail) {
        ConfirmHolder holder = new ConfirmHolder(type, menuId, itemId, index);
        Inventory inventory = Bukkit.createInventory(holder, 27, color(title));
        holder.inventory = inventory;
        inventory.setItem(11, button(Material.LIME_CONCRETE, "&aBestaetigen", detail));
        inventory.setItem(15, button(Material.RED_CONCRETE, "&cAbbrechen", "&7Nichts wird geaendert."));
        player.openInventory(inventory);
    }

    private void handleConfirmClick(Player player, ConfirmHolder holder, int rawSlot) {
        if (rawSlot == 15) {
            reopenAfterConfirm(player, holder);
            return;
        }
        if (rawSlot != 11) {
            return;
        }
        if (holder.type == ConfirmType.DELETE_MENU) {
            getConfig().set("menus." + holder.menuId, null);
            saveConfig();
            sendRaw(player, message("menu-deleted").replace("<menu>", holder.menuId));
            openMenuManager(player);
        } else if (holder.type == ConfirmType.DELETE_ITEM) {
            getConfig().set(itemPath(holder.menuId, holder.itemId), null);
            saveConfig();
            sendRaw(player, message("item-removed").replace("<item>", holder.itemId));
            openMenuEditor(player, holder.menuId);
        } else if (holder.type == ConfirmType.DELETE_COMMAND) {
            List<String> commands = getConfig().getStringList(itemPath(holder.menuId, holder.itemId) + ".commands");
            if (holder.index >= 0 && holder.index < commands.size()) {
                commands.remove(holder.index);
                getConfig().set(itemPath(holder.menuId, holder.itemId) + ".commands", commands);
                saveConfig();
            }
            openCommandEditor(player, holder.menuId, holder.itemId);
        }
    }

    private void reopenAfterConfirm(Player player, ConfirmHolder holder) {
        if (holder.type == ConfirmType.DELETE_MENU) {
            openMenuSettings(player, holder.menuId);
        } else if (holder.type == ConfirmType.DELETE_ITEM) {
            openItemEditor(player, holder.menuId, holder.itemId);
        } else if (holder.type == ConfirmType.DELETE_COMMAND) {
            openCommandEditor(player, holder.menuId, holder.itemId);
        }
    }

    private void handlePendingInput(Player player, String rawInput) {
        PendingInput input = pendingInputs.remove(player.getUniqueId());
        if (input == null) {
            return;
        }
        String value = rawInput.trim();
        if (value.equalsIgnoreCase("cancel")) {
            player.sendMessage(color(prefix() + "&cEingabe abgebrochen."));
            reopenAfterInput(player, input);
            return;
        }

        switch (input.type) {
            case MENU_CREATE_ID -> {
                String menuId = cleanId(value);
                if (menuId.isBlank() || hasMenu(menuId)) {
                    player.sendMessage(color(prefix() + "&cDiese Menue-ID ist leer oder existiert schon."));
                    beginInput(player, input, "&eAndere Menue-ID eingeben.");
                    return;
                }
                PendingInput next = new PendingInput(InputType.MENU_CREATE_TITLE, menuId, "", 54);
                beginInput(player, next, "&eTitel fuer &f" + menuId + " &eeingeben. &7Groesse aenderst du danach im GUI.");
            }
            case MENU_CREATE_TITLE -> {
                createMenu(input.menuId, input.index, value);
                sendRaw(player, message("menu-created").replace("<menu>", input.menuId));
                openMenuSettings(player, input.menuId);
            }
            case MENU_TITLE -> {
                getConfig().set("menus." + input.menuId + ".title", value);
                saveConfig();
                openMenuSettings(player, input.menuId);
            }
            case MENU_DUPLICATE_ID -> {
                String target = cleanId(value);
                if (target.isBlank() || hasMenu(target)) {
                    player.sendMessage(color(prefix() + "&cDiese Menue-ID ist leer oder existiert schon."));
                    beginInput(player, input, "&eAndere ID fuer die Kopie eingeben.");
                    return;
                }
                duplicateMenu(input.menuId, target);
                openMenuSettings(player, target);
            }
            case SUBMENU_CREATE_ID -> {
                String submenuId = cleanId(value);
                if (submenuId.isBlank() || hasMenu(submenuId)) {
                    player.sendMessage(color(prefix() + "&cDiese Untermenue-ID ist leer oder existiert schon."));
                    beginInput(player, input, "&eAndere Untermenue-ID eingeben.");
                    return;
                }
                PendingInput next = new PendingInput(InputType.SUBMENU_CREATE_TITLE, input.menuId, input.itemId, -1, submenuId);
                beginInput(player, next, "&eTitel fuer Untermenue &f" + submenuId + " &eeingeben.");
            }
            case SUBMENU_CREATE_TITLE -> {
                createMenu(input.extra, 54, value);
                getConfig().set(itemPath(input.menuId, input.itemId) + ".menu", input.extra);
                saveConfig();
                sendRaw(player, message("menu-created").replace("<menu>", input.extra));
                openMenuEditor(player, input.extra);
            }
            case ITEM_NAME -> setItemValue(player, input, "name", value);
            case ITEM_LORE -> setItemValue(player, input, "lore", Arrays.asList(value.split("\\|")));
        }
    }

    private void setItemValue(Player player, PendingInput input, String key, Object value) {
        getConfig().set(itemPath(input.menuId, input.itemId) + "." + key, value);
        saveConfig();
        openItemEditor(player, input.menuId, input.itemId);
    }

    private void reopenAfterInput(Player player, PendingInput input) {
        if (input.itemId != null && !input.itemId.isBlank() && hasItem(input.menuId, input.itemId)) {
            openItemEditor(player, input.menuId, input.itemId);
        } else if (input.menuId != null && !input.menuId.isBlank() && hasMenu(input.menuId)) {
            openMenuSettings(player, input.menuId);
        } else {
            openAdmin(player);
        }
    }

    private void beginInput(Player player, PendingInput input, String prompt) {
        pendingInputs.put(player.getUniqueId(), input);
        player.closeInventory();
        player.sendMessage(color(prefix() + prompt));
        player.sendMessage(color(prefix() + "&7Schreibe &ccancel&7 zum Abbrechen."));
    }

    private void finishTransfer(Player player, TransferMode transfer, int targetSlot, boolean copy) {
        transferModes.remove(player.getUniqueId());
        if (!hasItem(transfer.menuId, transfer.itemId)) {
            openMenuEditor(player, transfer.menuId);
            return;
        }
        String existing = itemIdAt(transfer.menuId, targetSlot);
        if (existing != null && !existing.equals(transfer.itemId)) {
            player.sendMessage(color(prefix() + "&cDer Zielslot ist belegt. Entferne das Item zuerst."));
            openMenuEditor(player, transfer.menuId);
            return;
        }
        if (copy) {
            String newId = uniqueItemId(transfer.menuId, "item_" + targetSlot);
            copySection(itemPath(transfer.menuId, transfer.itemId), itemPath(transfer.menuId, newId));
            getConfig().set(itemPath(transfer.menuId, newId) + ".slot", targetSlot);
            sendRaw(player, "&aItem wurde kopiert nach Slot &e" + targetSlot + "&a.");
        } else {
            getConfig().set(itemPath(transfer.menuId, transfer.itemId) + ".slot", targetSlot);
            sendRaw(player, "&aItem wurde verschoben nach Slot &e" + targetSlot + "&a.");
        }
        saveConfig();
        openMenuEditor(player, transfer.menuId);
    }

    private void setItemFromHand(Player player, String menuId, int slot, String itemId) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            send(player, "editor-help");
            return;
        }
        ItemMeta meta = hand.getItemMeta();
        String base = itemPath(menuId, itemId);
        getConfig().set(base + ".slot", slot);
        getConfig().set(base + ".material", hand.getType().name());
        getConfig().set(base + ".amount", clamp(hand.getAmount(), 1, 64));
        getConfig().set(base + ".name", meta != null && meta.hasDisplayName() ? meta.getDisplayName() : prettify(hand.getType().name()));
        getConfig().set(base + ".lore", meta != null && meta.hasLore() ? meta.getLore() : Collections.singletonList("&7Neues Navigator-Item."));
        getConfig().set(base + ".category", getConfig().getString(base + ".category", "Neu"));
        getConfig().set(base + ".glow", getConfig().getBoolean(base + ".glow", false));
        getConfig().set(base + ".close-after-click", getConfig().getBoolean(base + ".close-after-click", false));
        getConfig().set(base + ".custom-model-data", meta != null && meta.hasCustomModelData() ? meta.getCustomModelData() : getConfig().getInt(base + ".custom-model-data", 0));
        getConfig().set(base + ".commands", getConfig().getStringList(base + ".commands"));
        saveConfig();
        sendRaw(player, message("item-set").replace("<item>", itemId).replace("<slot>", String.valueOf(slot)));
    }

    private void createDefaultItem(String menuId, int slot, String itemId) {
        String base = itemPath(menuId, itemId);
        getConfig().set(base + ".slot", slot);
        getConfig().set(base + ".material", "CHEST");
        getConfig().set(base + ".amount", 1);
        getConfig().set(base + ".name", "&eNeues Item");
        getConfig().set(base + ".lore", Collections.singletonList("&7Im Item-Editor bearbeiten."));
        getConfig().set(base + ".category", "Neu");
        getConfig().set(base + ".custom-model-data", 0);
        getConfig().set(base + ".close-after-click", false);
        getConfig().set(base + ".glow", false);
        getConfig().set(base + ".commands", Collections.emptyList());
        saveConfig();
    }

    private void setItemMaterialFromHand(Player player, String menuId, String itemId) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            send(player, "editor-help");
            return;
        }
        String base = itemPath(menuId, itemId);
        ItemMeta meta = hand.getItemMeta();
        getConfig().set(base + ".material", hand.getType().name());
        getConfig().set(base + ".amount", clamp(hand.getAmount(), 1, 64));
        if (meta != null && meta.hasCustomModelData()) {
            getConfig().set(base + ".custom-model-data", meta.getCustomModelData());
        }
        saveConfig();
    }

    private void applyTextColor(String menuId, String itemId, TextTarget target, String colorCode) {
        List<String> values = textValues(menuId, itemId, target);
        List<String> styled = new ArrayList<>();
        for (String value : values) {
            TextFormatState state = readFormatState(value);
            state.color = colorCode;
            styled.add(state.prefix() + stripLeadingFormatting(value));
        }
        setTextValues(menuId, itemId, target, styled);
    }

    private void toggleTextStyle(String menuId, String itemId, TextTarget target, String styleCode) {
        List<String> values = textValues(menuId, itemId, target);
        List<String> styled = new ArrayList<>();
        for (String value : values) {
            TextFormatState state = readFormatState(value);
            if (state.styles.contains(styleCode)) {
                state.styles.remove(styleCode);
            } else {
                state.styles.add(styleCode);
            }
            styled.add(state.prefix() + stripLeadingFormatting(value));
        }
        setTextValues(menuId, itemId, target, styled);
    }

    private void applyTextPreset(String menuId, String itemId, TextTarget target, TextPreset preset) {
        List<String> values = textValues(menuId, itemId, target);
        List<String> styled = new ArrayList<>();
        for (String value : values) {
            String text = stripLeadingFormatting(value);
            if (preset.gradient) {
                styled.add(gradientText(text, preset.gradientStart, preset.gradientEnd, preset.prefix));
            } else {
                styled.add(preset.prefix + text);
            }
        }
        setTextValues(menuId, itemId, target, styled);
    }

    private List<String> textValues(String menuId, String itemId, TextTarget target) {
        String base = itemPath(menuId, itemId);
        if (target == TextTarget.NAME) {
            return Collections.singletonList(getConfig().getString(base + ".name", "&eNeues Item"));
        }
        List<String> lore = getConfig().getStringList(base + ".lore");
        if (lore.isEmpty()) {
            lore.add("&7Im Item-Editor bearbeiten.");
        }
        return lore;
    }

    private void setTextValues(String menuId, String itemId, TextTarget target, List<String> values) {
        String base = itemPath(menuId, itemId);
        if (target == TextTarget.NAME) {
            getConfig().set(base + ".name", values.isEmpty() ? "" : values.get(0));
        } else {
            getConfig().set(base + ".lore", values);
        }
        saveConfig();
    }

    private TextFormatState readFormatState(String value) {
        TextFormatState state = new TextFormatState();
        int index = 0;
        String text = value == null ? "" : value;
        while (index < text.length()) {
            String code = readFormatCode(text, index);
            if (code == null) {
                break;
            }
            String lower = code.toLowerCase(Locale.ROOT);
            if (lower.equals("&r")) {
                state.color = "";
                state.styles.clear();
            } else if (isColorFormat(lower)) {
                state.color = code;
            } else if (isStyleFormat(lower) && !state.styles.contains(lower)) {
                state.styles.add(lower);
            }
            index += code.length();
        }
        return state;
    }

    private String stripLeadingFormatting(String value) {
        String text = value == null ? "" : value;
        int index = 0;
        while (index < text.length()) {
            String code = readFormatCode(text, index);
            if (code == null) {
                break;
            }
            index += code.length();
        }
        return text.substring(index);
    }

    private String readFormatCode(String text, int index) {
        if (index + 2 <= text.length() && text.charAt(index) == '&') {
            if (index + 8 <= text.length() && text.charAt(index + 1) == '#'
                && text.substring(index + 2, index + 8).matches("[A-Fa-f0-9]{6}")) {
                return text.substring(index, index + 8);
            }
            if (index + 2 <= text.length()) {
                char code = Character.toLowerCase(text.charAt(index + 1));
                if ("0123456789abcdefklmnor".indexOf(code) >= 0) {
                    return text.substring(index, index + 2).toLowerCase(Locale.ROOT);
                }
            }
        }
        if (index + 9 <= text.length() && text.charAt(index) == '<' && text.charAt(index + 1) == '#'
            && text.charAt(index + 8) == '>' && text.substring(index + 2, index + 8).matches("[A-Fa-f0-9]{6}")) {
            return text.substring(index, index + 9);
        }
        return null;
    }

    private boolean isColorFormat(String code) {
        return code.matches("&[0-9a-f]") || code.matches("&#[A-Fa-f0-9]{6}") || code.matches("<#[A-Fa-f0-9]{6}>");
    }

    private boolean isStyleFormat(String code) {
        return code.equals("&l") || code.equals("&o") || code.equals("&n") || code.equals("&m") || code.equals("&k");
    }

    private String gradientText(String text, String startHex, String endHex, String styles) {
        if (text == null || text.isBlank()) {
            return text == null ? "" : text;
        }
        int visible = Math.max(1, text.length() - 1);
        int start = Integer.parseInt(startHex.substring(1), 16);
        int end = Integer.parseInt(endHex.substring(1), 16);
        int sr = (start >> 16) & 0xFF;
        int sg = (start >> 8) & 0xFF;
        int sb = start & 0xFF;
        int er = (end >> 16) & 0xFF;
        int eg = (end >> 8) & 0xFF;
        int eb = end & 0xFF;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            double t = visible == 0 ? 0 : (double) i / visible;
            int r = (int) Math.round(sr + (er - sr) * t);
            int g = (int) Math.round(sg + (eg - sg) * t);
            int b = (int) Math.round(sb + (eb - sb) * t);
            builder.append(String.format(Locale.US, "&#%02X%02X%02X", r, g, b)).append(styles).append(text.charAt(i));
        }
        return builder.toString();
    }

    private void runAction(Player player, String rawAction) {
        String action = replace(rawAction, player).trim();
        if (action.isBlank()) {
            return;
        }
        if (action.equalsIgnoreCase("close")) {
            player.closeInventory();
            return;
        }
        if (action.toLowerCase(Locale.ROOT).startsWith("menu:")) {
            openMenu(player, action.substring(5).trim());
            return;
        }
        if (action.toLowerCase(Locale.ROOT).startsWith("player:")) {
            player.performCommand(action.substring(7).trim());
            return;
        }
        if (action.toLowerCase(Locale.ROOT).startsWith("console:")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), action.substring(8).trim());
            return;
        }
        if (action.toLowerCase(Locale.ROOT).startsWith("message:")) {
            player.sendMessage(color(action.substring(8)));
            return;
        }
        if (action.toLowerCase(Locale.ROOT).startsWith("sound:")) {
            playSound(player, action.substring(6).trim());
        }
    }

    private ItemStack buildItem(String menuId, String itemId, boolean editor) {
        ConfigurationSection item = itemSection(menuId, itemId);
        Material material = material(item.getString("material", "STONE"));
        ItemStack stack = new ItemStack(material, clamp(item.getInt("amount", 1), 1, 64));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(item.getString("name", prettify(material.name()))));
            List<String> lore = new ArrayList<>();
            for (String line : item.getStringList("lore")) {
                lore.add(color(line));
            }
            if (editor) {
                lore.add("");
                lore.add(color("&8Editor-Key: &e" + itemId));
                lore.add(color("&8Slot: &e" + item.getInt("slot")));
                lore.add(color("&8Kategorie: &e" + item.getString("category", "-")));
                lore.add(color("&8Menge: &e" + item.getInt("amount", 1)));
                lore.add(color("&8CustomModelData: &e" + item.getInt("custom-model-data", 0)));
                lore.add(color("&8Close: &e" + item.getBoolean("close-after-click", false)));
                String permission = item.getString("permission", "");
                if (permission != null && !permission.isBlank()) {
                    lore.add(color("&8Permission: &e" + permission));
                }
                String menu = item.getString("menu", "");
                if (menu != null && !menu.isBlank()) {
                    lore.add(color("&8Oeffnet: &e" + menu));
                }
                lore.add(color("&7Rechtsklick: Item-Editor"));
                lore.add(color("&7Shift-Rechtsklick: entfernen"));
                lore.add(color("&7Shift-Linksklick: Move/Copy"));
            }
            meta.setLore(lore);
            int customModelData = item.getInt("custom-model-data", 0);
            if (customModelData > 0) {
                meta.setCustomModelData(customModelData);
            }
            if (item.getBoolean("glow", false)) {
                meta.addEnchant(Enchantment.DURABILITY, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack button(Material material, String name, String... loreLines) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            List<String> lore = Arrays.stream(loreLines).map(this::color).collect(Collectors.toList());
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void createMenu(String menuId, int size, String title) {
        String path = "menus." + menuId;
        getConfig().set(path + ".title", title);
        getConfig().set(path + ".size", parseSize(String.valueOf(size), 54));
        getConfig().set(path + ".open-sound", "UI_BUTTON_CLICK");
        getConfig().set(path + ".filler.enabled", false);
        getConfig().set(path + ".filler.material", "BLACK_STAINED_GLASS_PANE");
        getConfig().set(path + ".filler.name", " ");
        getConfig().createSection(path + ".items");
        saveConfig();
    }

    private void duplicateMenu(String sourceMenu, String targetMenu) {
        copySection("menus." + sourceMenu, "menus." + targetMenu);
        saveConfig();
    }

    private void copySection(String sourcePath, String targetPath) {
        ConfigurationSection source = getConfig().getConfigurationSection(sourcePath);
        if (source == null) {
            return;
        }
        getConfig().set(targetPath, null);
        for (String key : source.getKeys(false)) {
            Object value = source.get(key);
            if (value instanceof ConfigurationSection) {
                copySection(sourcePath + "." + key, targetPath + "." + key);
            } else {
                getConfig().set(targetPath + "." + key, value);
            }
        }
    }

    private void toggle(String path) {
        getConfig().set(path, !getConfig().getBoolean(path, false));
    }

    private void playSound(Player player, String soundName) {
        if (soundName == null || soundName.isBlank()) {
            return;
        }
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
            float volume = (float) getConfig().getDouble("sounds.volume", 0.7);
            float pitch = (float) getConfig().getDouble("sounds.pitch", 1.15);
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ignored) {
            getLogger().warning("Unbekannter Sound: " + soundName);
        }
    }

    private boolean isCoolingDown(Player player) {
        long now = System.currentTimeMillis();
        long last = clickCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < clickCooldownMs) {
            return true;
        }
        clickCooldowns.put(player.getUniqueId(), now);
        return false;
    }

    private void loadSettings() {
        mainMenu = getConfig().getString("settings.main-menu", "main");
        clickCooldownMs = getConfig().getLong("settings.click-cooldown-ms", 350);
    }

    private boolean hasMenu(String menuId) {
        return getConfig().isConfigurationSection("menus." + menuId);
    }

    private boolean hasItem(String menuId, String itemId) {
        return getConfig().isConfigurationSection(itemPath(menuId, itemId));
    }

    private String itemPath(String menuId, String itemId) {
        return "menus." + menuId + ".items." + itemId;
    }

    private ConfigurationSection itemSection(String menuId, String itemId) {
        return getConfig().getConfigurationSection(itemPath(menuId, itemId));
    }

    private int menuSize(String menuId) {
        return parseSize(String.valueOf(getConfig().getInt("menus." + menuId + ".size", 54)), 54);
    }

    private String menuTitle(String menuId, boolean editor) {
        String title = getConfig().getString("menus." + menuId + ".title", "&6&l" + menuId);
        return editor ? "&cEditor &8- &r" + title : title;
    }

    private List<String> menuIds() {
        ConfigurationSection section = getConfig().getConfigurationSection("menus");
        if (section == null) {
            return Collections.emptyList();
        }
        return new ArrayList<>(section.getKeys(false));
    }

    private List<String> itemIds(String menuId) {
        ConfigurationSection section = getConfig().getConfigurationSection("menus." + menuId + ".items");
        if (section == null) {
            return Collections.emptyList();
        }
        return new ArrayList<>(section.getKeys(false));
    }

    private String itemIdAt(String menuId, int slot) {
        for (String itemId : itemIds(menuId)) {
            if (getConfig().getInt(itemPath(menuId, itemId) + ".slot", -1) == slot) {
                return itemId;
            }
        }
        return null;
    }

    private String uniqueItemId(String menuId, String base) {
        String candidate = cleanId(base);
        int index = 2;
        while (hasItem(menuId, candidate)) {
            candidate = cleanId(base) + "_" + index++;
        }
        return candidate;
    }

    private boolean requireAdmin(CommandSender sender) {
        if (sender.hasPermission("rslnavigator.admin")) {
            return true;
        }
        send(sender, "no-permission");
        return false;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(color(prefix() + "&6RSLNavigator Befehle:"));
        sender.sendMessage(color("&e/rslnav open [menu] &7- Navigator oeffnen"));
        sender.sendMessage(color("&e/rslnav admin &7- Voller GUI-Editor"));
        sender.sendMessage(color("&e/rslnav edit <menu> &7- Visueller Layout-Editor"));
        sender.sendMessage(color("&e/rslnav menu create <id> <size> <title>"));
        sender.sendMessage(color("&e/rslnav item add <menu> <slot> [key] &7- Hand-Item hinzufuegen"));
    }

    private boolean isItemSetAction(String action) {
        return action.equalsIgnoreCase("set") || action.equalsIgnoreCase("add");
    }

    private void send(CommandSender sender, String key) {
        sender.sendMessage(color(prefix() + message(key)));
    }

    private void sendRaw(CommandSender sender, String rawMessage) {
        sender.sendMessage(color(prefix() + rawMessage));
    }

    private String message(String key) {
        return getConfig().getString("messages." + key, "");
    }

    private String prefix() {
        return message("prefix");
    }

    private String color(String value) {
        return ChatColor.translateAlternateColorCodes('&', translateHexColors(value == null ? "" : value));
    }

    private String translateHexColors(String value) {
        String translated = replaceHexPattern(HEX_AMP_PATTERN, value);
        return replaceHexPattern(HEX_TAG_PATTERN, translated);
    }

    private String replaceHexPattern(Pattern pattern, String value) {
        Matcher matcher = pattern.matcher(value);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String replacement;
            try {
                replacement = net.md_5.bungee.api.ChatColor.of("#" + matcher.group(1)).toString();
            } catch (IllegalArgumentException ignored) {
                replacement = matcher.group(0);
            }
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(buffer);
        return buffer.toString();
    }

    private String replace(String value, Player player) {
        Location location = player.getLocation();
        return value
            .replace("<player>", player.getName())
            .replace("%player%", player.getName())
            .replace("<world>", player.getWorld().getName())
            .replace("<x>", formatCoordinate(location.getX()))
            .replace("<y>", formatCoordinate(location.getY()))
            .replace("<z>", formatCoordinate(location.getZ()))
            .replace("<block_x>", String.valueOf(location.getBlockX()))
            .replace("<block_y>", String.valueOf(location.getBlockY()))
            .replace("<block_z>", String.valueOf(location.getBlockZ()))
            .replace("<yaw>", formatCoordinate(location.getYaw()))
            .replace("<pitch>", formatCoordinate(location.getPitch()));
    }

    private String formatCoordinate(double value) {
        return String.format(Locale.US, "%.2f", value);
    }

    private List<String> filter(List<String> values, String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        return values.stream()
            .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower))
            .collect(Collectors.toList());
    }

    private String join(String[] args, int start) {
        if (args.length <= start) {
            return "";
        }
        return String.join(" ", Arrays.copyOfRange(args, start, args.length));
    }

    private int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private int parseSize(String value, int fallback) {
        int size = parseInt(value, fallback);
        if (size < 9) {
            size = 9;
        }
        if (size > 54) {
            size = 54;
        }
        return ((size + 8) / 9) * 9;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private String cleanId(String raw) {
        return raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
    }

    private Material material(String name) {
        Material material = Material.matchMaterial(name == null ? "" : name);
        return material == null ? Material.STONE : material;
    }

    private String prettify(String material) {
        return "&f" + prettifyPlain(material);
    }

    private String prettifyPlain(String material) {
        String lower = material.toLowerCase(Locale.ROOT).replace('_', ' ');
        StringBuilder builder = new StringBuilder();
        boolean nextUpper = true;
        for (char c : lower.toCharArray()) {
            if (nextUpper && Character.isLetter(c)) {
                builder.append(Character.toUpperCase(c));
                nextUpper = false;
            } else {
                builder.append(c);
            }
            if (c == ' ') {
                nextUpper = true;
            }
        }
        return builder.toString();
    }

    private enum InputType {
        MENU_CREATE_ID,
        MENU_CREATE_TITLE,
        MENU_TITLE,
        MENU_DUPLICATE_ID,
        SUBMENU_CREATE_ID,
        SUBMENU_CREATE_TITLE,
        ITEM_NAME,
        ITEM_LORE
    }

    private enum ConfirmType {
        DELETE_MENU,
        DELETE_ITEM,
        DELETE_COMMAND
    }

    private enum PickerKind {
        ITEM_SOUND,
        MENU_SOUND,
        CATEGORY,
        PERMISSION,
        TARGET_MENU,
        COMMAND_GROUP
    }

    private enum MaterialCategory {
        FAVORITES("&6Favoriten", Material.NETHER_STAR),
        BLOCKS("&fBloecke", Material.STONE),
        DECORATION("&dDeko", Material.PAINTING),
        TOOLS("&bTools/Waffen", Material.DIAMOND_PICKAXE),
        ARMOR("&9Ruestung", Material.DIAMOND_CHESTPLATE),
        FOOD("&aEssen", Material.COOKED_BEEF),
        REDSTONE("&cRedstone", Material.REDSTONE),
        NATURAL("&2Natur", Material.OAK_SAPLING),
        UTILITY("&eUtility", Material.CRAFTING_TABLE),
        SPAWN_EGGS("&5Spawn-Eggs", Material.ZOMBIE_SPAWN_EGG),
        ALL("&fAlle", Material.CHEST);

        private final String label;
        private final Material icon;

        MaterialCategory(String label, Material icon) {
            this.label = label;
            this.icon = icon;
        }

        private boolean matches(Material material) {
            String name = material.name();
            return switch (this) {
                case FAVORITES -> Arrays.asList(
                    "COMPASS", "CHEST", "GRASS_BLOCK", "BEACON", "EMERALD", "DIAMOND", "BOOK",
                    "COMMAND_BLOCK", "ENDER_PEARL", "NETHER_STAR", "PAPER", "OAK_SIGN", "REDSTONE",
                    "CLOCK", "EXPERIENCE_BOTTLE", "BARRIER", "ARROW", "PLAYER_HEAD"
                ).contains(name);
                case BLOCKS -> material.isBlock();
                case DECORATION -> containsAny(name, "BANNER", "SIGN", "GLASS", "WOOL", "CARPET", "CONCRETE", "TERRACOTTA", "CANDLE", "LANTERN", "FLOWER_POT", "BED", "PAINTING", "ITEM_FRAME", "HEAD", "SKULL");
                case TOOLS -> endsAny(name, "SWORD", "PICKAXE", "AXE", "SHOVEL", "HOE") || containsAny(name, "BOW", "TRIDENT", "SHIELD", "FISHING_ROD", "SHEARS", "FLINT_AND_STEEL", "BRUSH");
                case ARMOR -> endsAny(name, "HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS") || containsAny(name, "ELYTRA", "HORSE_ARMOR", "TURTLE_HELMET");
                case FOOD -> material.isEdible();
                case REDSTONE -> containsAny(name, "REDSTONE", "PISTON", "HOPPER", "DISPENSER", "DROPPER", "OBSERVER", "COMPARATOR", "REPEATER", "LEVER", "BUTTON", "PRESSURE_PLATE", "TRIPWIRE", "DAYLIGHT", "TARGET", "SCULK_SENSOR");
                case NATURAL -> containsAny(name, "SAPLING", "LEAVES", "LOG", "WOOD", "FLOWER", "GRASS", "DIRT", "STONE", "ORE", "SAND", "GRAVEL", "ICE", "SNOW", "MOSS", "VINE", "CORAL", "KELP", "SEAGRASS", "MUSHROOM", "DEEPSLATE", "TUFF", "CALCITE", "DRIPSTONE");
                case UTILITY -> containsAny(name, "CRAFTING_TABLE", "FURNACE", "CHEST", "BARREL", "ANVIL", "ENCHANTING_TABLE", "BREWING_STAND", "BEACON", "ENDER_CHEST", "LECTERN", "CARTOGRAPHY_TABLE", "SMITHING_TABLE", "GRINDSTONE", "STONECUTTER", "LOOM", "COMPOSTER", "BELL");
                case SPAWN_EGGS -> name.endsWith("_SPAWN_EGG");
                case ALL -> true;
            };
        }

        private static boolean containsAny(String value, String... parts) {
            for (String part : parts) {
                if (value.contains(part)) {
                    return true;
                }
            }
            return false;
        }

        private static boolean endsAny(String value, String... parts) {
            for (String part : parts) {
                if (value.endsWith(part)) {
                    return true;
                }
            }
            return false;
        }
    }

    private enum TextTarget {
        NAME("Name"),
        LORE("Lore");

        private final String label;

        TextTarget(String label) {
            this.label = label;
        }
    }

    private enum TextPreset {
        GOLD_COPPER("&6&l", "&6&lGold/Kupfer", Material.GOLD_INGOT, false, "", ""),
        DARK_NOBLE("&8&l", "&8&lDunkel-Edel", Material.NETHERITE_INGOT, false, "", ""),
        WARNING("&c&l", "&c&lWarnung", Material.REDSTONE_BLOCK, false, "", ""),
        SUCCESS("&a&l", "&a&lErfolg", Material.EMERALD, false, "", ""),
        INFO("&b&l", "&b&lInfo", Material.DIAMOND, false, "", ""),
        ADMIN("&4&l", "&4&lAdmin", Material.COMMAND_BLOCK, false, "", ""),
        PLAYER("&e", "&eSpieler", Material.PLAYER_HEAD, false, "", ""),
        MUTED("&7", "&7Dezent", Material.GRAY_DYE, false, "", ""),
        GOLD_GRADIENT("&l", "&6&lGold-Gradient", Material.AMETHYST_SHARD, true, "#FFF1B8", "#B86A3B"),
        RESET("", "&cReset", Material.BARRIER, false, "", "");

        private final String prefix;
        private final String label;
        private final Material icon;
        private final boolean gradient;
        private final String gradientStart;
        private final String gradientEnd;

        TextPreset(String prefix, String label, Material icon, boolean gradient, String gradientStart, String gradientEnd) {
            this.prefix = prefix;
            this.label = label;
            this.icon = icon;
            this.gradient = gradient;
            this.gradientStart = gradientStart;
            this.gradientEnd = gradientEnd;
        }
    }

    private enum NumberKind {
        MENU_SIZE,
        ITEM_AMOUNT,
        ITEM_CUSTOM_MODEL_DATA,
        SETTINGS_COOLDOWN
    }

    private enum CommandTemplate {
        TELEPORT("Teleport"),
        GIVE("Give"),
        GAMEMODE("Gamemode"),
        EFFECT("Effect"),
        MULTIVERSE("Multiverse"),
        SPAWN("Spawn"),
        NAMED_LOCATION("Warp/Home"),
        MESSAGE("Message"),
        GENERIC("Generisch");

        private final String label;

        CommandTemplate(String label) {
            this.label = label;
        }
    }

    private enum CommandMode {
        PLAYER("player:"),
        CONSOLE("console:");

        private final String prefix;

        CommandMode(String prefix) {
            this.prefix = prefix;
        }
    }

    private static final class PendingInput {
        private final InputType type;
        private final String menuId;
        private final String itemId;
        private final int index;
        private final String extra;

        private PendingInput(InputType type, String menuId, String itemId, int index) {
            this(type, menuId, itemId, index, "");
        }

        private PendingInput(InputType type, String menuId, String itemId, int index, String extra) {
            this.type = type;
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.extra = extra;
        }
    }

    private static final class TransferMode {
        private final String menuId;
        private final String itemId;

        private TransferMode(String menuId, String itemId) {
            this.menuId = menuId;
            this.itemId = itemId;
        }
    }

    private static final class MenuHolder implements InventoryHolder {
        private final String menuId;
        private Inventory inventory;

        private MenuHolder(String menuId) {
            this.menuId = menuId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class AdminHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class MenuManagerHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class MenuSettingsHolder implements InventoryHolder {
        private final String menuId;
        private Inventory inventory;

        private MenuSettingsHolder(String menuId) {
            this.menuId = menuId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class MenuEditorHolder implements InventoryHolder {
        private final String menuId;
        private Inventory inventory;

        private MenuEditorHolder(String menuId) {
            this.menuId = menuId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class ItemEditorHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private Inventory inventory;

        private ItemEditorHolder(String menuId, String itemId) {
            this.menuId = menuId;
            this.itemId = itemId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class MaterialPickerHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final MaterialCategory category;
        private int page;
        private Inventory inventory;

        private MaterialPickerHolder(String menuId, String itemId, MaterialCategory category, int page) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.category = category;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class TextDesignHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final TextTarget target;
        private Inventory inventory;

        private TextDesignHolder(String menuId, String itemId, TextTarget target) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.target = target;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CommandEditorHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private Inventory inventory;

        private CommandEditorHolder(String menuId, String itemId) {
            this.menuId = menuId;
            this.itemId = itemId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class PickerHolder implements InventoryHolder {
        private final PickerKind kind;
        private final String menuId;
        private final String itemId;
        private final int index;
        private final String group;
        private int page;
        private Inventory inventory;

        private PickerHolder(PickerKind kind, String menuId, String itemId, int index, String group, int page) {
            this.kind = kind;
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.group = group;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class NumberPickerHolder implements InventoryHolder {
        private final NumberKind kind;
        private final String menuId;
        private final String itemId;
        private final int index;
        private Inventory inventory;

        private NumberPickerHolder(NumberKind kind, String menuId, String itemId, int index) {
            this.kind = kind;
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CommandBrowserHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final int index;
        private final String group;
        private int page;
        private Inventory inventory;

        private CommandBrowserHolder(String menuId, String itemId, int index, String group, int page) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.group = group;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CommandBuilderHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final int index;
        private final CommandMode mode;
        private final String command;
        private final List<String> args;
        private final String group;
        private Inventory inventory;

        private CommandBuilderHolder(String menuId, String itemId, int index, CommandMode mode, String command, List<String> args, String group) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.mode = mode;
            this.command = command;
            this.args = new ArrayList<>(args);
            this.group = group;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class AnvilInputHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final int index;
        private final CommandMode mode;
        private final String command;
        private final List<String> args;
        private final String group;
        private Inventory inventory;

        private AnvilInputHolder(String menuId, String itemId, int index, CommandMode mode, String command, List<String> args, String group) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.mode = mode;
            this.command = command;
            this.args = new ArrayList<>(args);
            this.group = group;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CommandArgumentHolder implements InventoryHolder {
        private final String menuId;
        private final String itemId;
        private final int index;
        private final CommandMode mode;
        private final String command;
        private final String group;
        private Inventory inventory;

        private CommandArgumentHolder(String menuId, String itemId, int index, CommandMode mode, String command, String group) {
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
            this.mode = mode;
            this.command = command;
            this.group = group;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class PickerOption {
        private final String value;
        private final String label;
        private final Material material;
        private final List<String> lore;

        private PickerOption(String value, String label, Material material, String... lore) {
            this.value = value;
            this.label = label;
            this.material = material;
            this.lore = Arrays.asList(lore);
        }
    }

    private static final class CommandEntry {
        private final String label;
        private final String group;
        private final String plugin;
        private final String description;
        private final String usage;

        private CommandEntry(String label, String group, String plugin, String description, String usage) {
            this.label = label;
            this.group = group;
            this.plugin = plugin;
            this.description = description;
            this.usage = usage;
        }
    }

    private static final class TextFormatState {
        private String color = "";
        private final List<String> styles = new ArrayList<>();

        private String prefix() {
            return color + String.join("", styles);
        }
    }

    private static final class SettingsHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class ConfirmHolder implements InventoryHolder {
        private final ConfirmType type;
        private final String menuId;
        private final String itemId;
        private final int index;
        private Inventory inventory;

        private ConfirmHolder(ConfirmType type, String menuId, String itemId, int index) {
            this.type = type;
            this.menuId = menuId;
            this.itemId = itemId;
            this.index = index;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}

package de.rsl.spawn;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class RSLSpawnPlugin extends JavaPlugin implements Listener, TabExecutor {
    private static final List<String> SUBCOMMANDS = Arrays.asList("set", "setworld", "tp", "status", "reload");

    private boolean enabled;
    private boolean teleportOnJoin;
    private boolean teleportOnRespawn;
    private boolean setBedSpawnOnJoin;
    private boolean playSound;
    private int joinDelayTicks;
    private String soundName;
    private float soundVolume;
    private float soundPitch;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Objects.requireNonNull(getCommand("rslspawn"), "rslspawn command missing").setExecutor(this);
        Objects.requireNonNull(getCommand("rslspawn"), "rslspawn command missing").setTabCompleter(this);
        Objects.requireNonNull(getCommand("spawn"), "spawn command missing").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);

        if (isMultiversePresent()) {
            getLogger().info("Multiverse-Core erkannt. RSLSpawn nutzt weiterhin den gespeicherten Welt-Namen.");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("spawn")) {
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            if (!sender.hasPermission("rslspawn.spawn") && !sender.hasPermission("rslspawn.admin")) {
                send(sender, "no-permission");
                return true;
            }
            teleportToSpawn(player, true);
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sendStatus(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            if (!sender.hasPermission("rslspawn.admin")) {
                send(sender, "no-permission");
                return true;
            }
            reloadConfig();
            loadSettings();
            send(sender, "reloaded");
            return true;
        }

        if (sub.equals("set")) {
            if (!sender.hasPermission("rslspawn.admin")) {
                send(sender, "no-permission");
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            saveSpawn(player.getLocation());
            sendRaw(sender, format("spawn-set", player.getWorld().getName(), player.getLocation()));
            return true;
        }

        if (sub.equals("setworld")) {
            if (!sender.hasPermission("rslspawn.admin")) {
                send(sender, "no-permission");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(color(prefix() + "&cNutze: &e/rslspawn setworld <welt>"));
                return true;
            }
            World world = Bukkit.getWorld(args[1]);
            if (world == null) {
                sendRaw(sender, message("world-not-found").replace("<world>", args[1]));
                return true;
            }
            Location spawn = world.getSpawnLocation().add(0.5, 0.0, 0.5);
            saveSpawn(spawn);
            sendRaw(sender, message("spawn-set-world").replace("<world>", world.getName()));
            return true;
        }

        if (sub.equals("tp")) {
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            if (!sender.hasPermission("rslspawn.tp") && !sender.hasPermission("rslspawn.spawn") && !sender.hasPermission("rslspawn.admin")) {
                send(sender, "no-permission");
                return true;
            }
            teleportToSpawn(player, true);
            return true;
        }

        sender.sendMessage(color(prefix() + "&cUnbekannter Befehl. Nutze &e/rslspawn status&c."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String typed = args[0].toLowerCase(Locale.ROOT);
            return SUBCOMMANDS.stream()
                .filter(value -> value.startsWith(typed))
                .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setworld")) {
            String typed = args[1].toLowerCase(Locale.ROOT);
            return Bukkit.getWorlds().stream()
                .map(World::getName)
                .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(typed))
                .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!enabled || !teleportOnJoin) {
            return;
        }
        Player player = event.getPlayer();
        BukkitTask ignored = Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) {
                return;
            }
            Location spawn = getSpawnLocation();
            if (spawn == null) {
                return;
            }
            if (setBedSpawnOnJoin) {
                player.setBedSpawnLocation(spawn, true);
            }
            player.teleport(spawn);
            playTeleportSound(player);
        }, Math.max(0, joinDelayTicks));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (!enabled || !teleportOnRespawn) {
            return;
        }
        Location spawn = getSpawnLocation();
        if (spawn != null) {
            event.setRespawnLocation(spawn);
        }
    }

    private void loadSettings() {
        FileConfiguration config = getConfig();
        enabled = config.getBoolean("settings.enabled", true);
        teleportOnJoin = config.getBoolean("settings.teleport-on-join", true);
        teleportOnRespawn = config.getBoolean("settings.teleport-on-respawn", false);
        setBedSpawnOnJoin = config.getBoolean("settings.set-bed-spawn-on-join", false);
        playSound = config.getBoolean("settings.play-sound", true);
        joinDelayTicks = config.getInt("settings.join-delay-ticks", 20);
        soundName = config.getString("settings.sound", "ENTITY_ENDERMAN_TELEPORT");
        soundVolume = (float) config.getDouble("settings.sound-volume", 0.7);
        soundPitch = (float) config.getDouble("settings.sound-pitch", 1.15);
    }

    private void saveSpawn(Location location) {
        FileConfiguration config = getConfig();
        config.set("spawn.world", location.getWorld().getName());
        config.set("spawn.x", location.getX());
        config.set("spawn.y", location.getY());
        config.set("spawn.z", location.getZ());
        config.set("spawn.yaw", location.getYaw());
        config.set("spawn.pitch", location.getPitch());
        saveConfig();
    }

    private Location getSpawnLocation() {
        FileConfiguration config = getConfig();
        String worldName = config.getString("spawn.world", "");
        if (worldName == null || worldName.isBlank()) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(
            world,
            config.getDouble("spawn.x", 0.5),
            config.getDouble("spawn.y", 64.0),
            config.getDouble("spawn.z", 0.5),
            (float) config.getDouble("spawn.yaw", 0.0),
            (float) config.getDouble("spawn.pitch", 0.0)
        );
    }

    private void teleportToSpawn(Player player, boolean sendMessage) {
        Location spawn = getSpawnLocation();
        if (spawn == null) {
            send(player, "spawn-not-set");
            return;
        }
        player.teleport(spawn);
        playTeleportSound(player);
        if (sendMessage) {
            send(player, "teleported");
        }
    }

    private void playTeleportSound(Player player) {
        if (!playSound || soundName == null || soundName.isBlank()) {
            return;
        }
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, soundVolume, soundPitch);
        } catch (IllegalArgumentException ignored) {
            getLogger().warning("Unbekannter Sound in config.yml: " + soundName);
        }
    }

    private void sendStatus(CommandSender sender) {
        String world = getConfig().getString("spawn.world", "");
        if (world == null || world.isBlank()) {
            world = "nicht gesetzt";
        }
        send(sender, "status-header");
        String line = message("status-line")
            .replace("<world>", world)
            .replace("<x>", trim(getConfig().getDouble("spawn.x", 0.5)))
            .replace("<y>", trim(getConfig().getDouble("spawn.y", 64.0)))
            .replace("<z>", trim(getConfig().getDouble("spawn.z", 0.5)))
            .replace("<join>", String.valueOf(teleportOnJoin))
            .replace("<respawn>", String.valueOf(teleportOnRespawn))
            .replace("<mv>", isMultiversePresent() ? "erkannt" : "nicht installiert");
        sendRaw(sender, line);
    }

    private String format(String key, String world, Location location) {
        return message(key)
            .replace("<world>", world)
            .replace("<x>", trim(location.getX()))
            .replace("<y>", trim(location.getY()))
            .replace("<z>", trim(location.getZ()));
    }

    private String trim(double value) {
        return String.format(Locale.US, "%.2f", value);
    }

    private boolean isMultiversePresent() {
        return Bukkit.getPluginManager().isPluginEnabled("Multiverse-Core");
    }

    private void send(CommandSender sender, String key) {
        sender.sendMessage(color(prefix() + message(key)));
    }

    private void sendRaw(CommandSender sender, String rawMessage) {
        sender.sendMessage(color(prefix() + rawMessage));
    }

    private String message(String key) {
        return getConfig().getString("messages." + key, "");
    }

    private String prefix() {
        return message("prefix");
    }

    private String color(String value) {
        return ChatColor.translateAlternateColorCodes('&', value == null ? "" : value);
    }
}

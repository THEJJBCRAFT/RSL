RSL Plugin Sammlung

Stand: 2026-06-15

Enthaltene Plugins:
- RSLRanks 1.0.0
  Rang- und Rechte-System mit Vault/TAB Support.
- RSLBalance 1.0.0
  Eigene Vault Economy fuer Balance, TAB und andere Plugins.
- RSLWelcome 1.0.0
  Join-Welcome mit animiertem Title, Spielername-Schreibeffekt und Sounds.
- RSLSpawn 1.0.0
  Fester Join-Spawn mit eigenem /spawn Command und optionalem Multiverse-Core Welt-Support.
- RSLNavigator 1.0.0
  Server-Navigator GUI mit Punkt-Trigger, Untermenue-Wizard, vollem Item-/Schrift-Designer, Command-Browser und passenden Command-Layouts.
- RSLCrates 1.0.0
  Crate-Key System mit GUI-Baukasten, Varianten, Timings, Reward-Funktionen, Loesch-/Overlap-Schutz, Name-Designer, Mega-Animationen, Effekt-Staerken und TextDisplay-Anzeige.

Ordner:
- 01_Server_Ready
  Diese Struktur kann direkt in einen Paper/Spigot-Server kopiert werden.
  Enthalten sind Jars, wichtige Plugin-Configs und die aktuelle TAB-Integration.

- 02_Jars
  Nur die fertigen Plugin-Jars.

- 03_Source
  Die Projektquellen zum Weiterentwickeln und Neubauen.

Installation:
1. Server stoppen.
2. Inhalt von 01_Server_Ready in den Serverordner kopieren.
3. Vault, TAB und PlaceholderAPI koennen zusaetzlich installiert sein.
4. Server starten.

Wichtig:
- RSLRanks ist fuer Raenge und Rechte.
- RSLBalance ist fuer Geld/Balance.
- RSLWelcome ist fuer Join-Title und Willkommensnachricht.
- RSLSpawn ist fuer festen Join-Spawn und den Spieler-Befehl /spawn, z. B. in einer Multiverse Spawn-Welt.
- RSLNavigator ist fuer Server-Navigation, Kategorien, Untermenues, Items, Sounds, Commands und GUI-Bearbeitung ohne manuelle Config-Pflicht. Items koennen aus allen Minecraft-Materialien gewaehlt werden; Name/Lore bekommen Farben, Styles, Hex-Codes, RSL-Presets und Gold-Gradient. Untermenues koennen direkt aus Items erstellt werden; bekannte Commands bekommen passende Builder-Layouts.
- RSLCrates ist fuer Crates, Keys, Reward-Chancen, Vorlagen, TextDisplays und Oeffnen mit Key oder Geld ueber Vault/RSLBalance. Varianten, Animationen, Effekt-Staerke, Timing, Crate-Loeschen und Crate-Name-Design sind im GUI einstellbar; doppelte Crates auf demselben Block werden blockiert. Neue Mega-Animationen wie Rainbow Roll, Firework Burst, Lightning Strike, Dragon Spin, Beacon Beam, Ender Portal, Treasure Chest, Lucky Wheel, Meteor Drop, Gold Rush, Soul Storm, Redstone Overload, Crate Shake und Final Reveal sind enthalten.
- TAB nutzt die RSLRanks/Vault Gruppen und RSLBalance/Vault Economy.

Test-Befehle:
- /rank help
- /rslbalance
- /rsleco reload
- /rslwelcome test
- /rslwelcome reload
- /rslspawn status
- /rslspawn set
- /spawn
- .
- /rslnav admin
- /rslnav edit main
- /rslcrates admin
- /rslcrates create vote
- /rslcrates key give <spieler> vote 1

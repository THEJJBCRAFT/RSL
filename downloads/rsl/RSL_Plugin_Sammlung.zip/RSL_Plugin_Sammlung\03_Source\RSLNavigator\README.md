# RSLNavigator

RSLNavigator ist ein Paper/Spigot Plugin fuer ein komplettes Server-Navigator-GUI mit eingebautem Admin-Editor.

## Features

- Spieler oeffnen den Navigator mit `.` im Chat.
- Spieler koennen auch `/.`, `/rslnav` oder `/rslnav open [menu]` nutzen.
- Menues, Kategorien, Untermenues, Items, Sounds, Glow, Rechte, Filler und Aktionen liegen in `config.yml`.
- Voller Admin-Editor mit `/rslnav admin`.
- Visueller Layout-Editor mit `/rslnav edit <menu>`.
- Fast alles wird per GUI-Picker gesetzt; Chat wird nur fuer freie Texte wie Menue-ID, Titel, Item-Name und Lore genutzt.
- Commands werden automatisch aus den geladenen Server-/Plugin-Commands gelesen und im GUI angezeigt.
- Command-Argumente werden im Builder zusammengestellt, inklusive Selector, Koordinaten, Platzhalter und Amboss-Freitext.
- Untermenues koennen direkt aus dem Item-Editor erstellt, verlinkt und sofort bearbeitet werden.
- Sichtbare Items koennen per kompletter Material-Auswahl mit Kategorien gesetzt werden.
- Name und Lore bekommen einen Text-Designer mit Minecraft-Farben, Styles, Hex-Farben, RSL-Presets und Gold-Gradient.
- Optional passend fuer Multiverse-Core, z. B. Welt-Auswahl ueber `/mvtp`.

## Spieler

- `.` im Chat oeffnet das Hauptmenue.
- `/.` oeffnet das Hauptmenue als Befehl.
- `/rslnav open [menu]` oeffnet ein bestimmtes Menue.

Wichtig: Ein reines Paper/Spigot Plugin kann keine echte Tastaturtaste abfangen, solange der Spieler nichts an den Server sendet. Deshalb funktioniert der Punkt serverseitig als Chat-Eingabe `.` oder als Befehl `/.`. Eine echte Keybind-Taste ohne Chat braucht einen Client-Mod.

## Admin-Dashboard

`/rslnav admin` oeffnet das Dashboard. Dort gibt es Buttons fuer:

- Hauptmenue oeffnen
- Hauptmenue bearbeiten
- Menues verwalten
- Neues Menue erstellen
- Globale Settings
- Speichern
- Reload

## Menue-Verwaltung

Im Menue-Manager werden alle Menues angezeigt.

- Linksklick: Layout-Editor oeffnen
- Rechtsklick: Menue-Settings oeffnen
- Shift-Rechtsklick: Menue loeschen mit Bestaetigung
- Button `Neues Menue`: fragt per Chat die Menue-ID und den Titel ab; Groesse und Settings werden danach per GUI gesetzt.

Im Menue-Settings-GUI kann man Titel, Groesse, Open-Sound, Filler, Filler-Material, Duplizieren und Loeschen bearbeiten. Groesse und Sound laufen ueber GUI-Picker.

## Visueller Layout-Editor

`/rslnav edit <menu>` oeffnet das Menue im visuellen Editor.

- Linksklick auf einen Slot: Item aus der Hand hinzufuegen oder ersetzen
- Linksklick auf einen leeren Slot ohne Hand-Item: erstellt ein Standard-Item und oeffnet direkt den Item-Editor
- Rechtsklick auf ein Item: Item-Editor oeffnen
- Shift-Rechtsklick auf ein Item: Item entfernen mit Bestaetigung
- Shift-Linksklick auf ein Item: Verschieben/Kopieren starten
- Danach Linksklick auf Zielslot: verschieben
- Danach Shift-Linksklick auf Zielslot: kopieren

## Item-Editor

Der Item-Editor wird per Rechtsklick auf ein Item im Layout-Editor geoeffnet. Bearbeitbar sind:

- Name
- Name-Design
- Lore
- Lore-Design
- Material waehlen
- Material aus Hand
- Kategorie
- Sound
- Glow
- Permission
- Untermenue
- Commands
- Neues Untermenue erstellen und direkt verlinken
- Menge
- CustomModelData
- Close-after-click
- Verschieben/Kopieren
- Loeschen

Name und Lore laufen fuer den reinen Text weiter ueber den Chat-Prompt, weil das freie Texte sind. Das Design wird im GUI gesetzt: Farben `&0` bis `&f`, fett/kursiv/unterstrichen/durchgestrichen, Reset, RSL-Presets und Hex-Codes wie `&#E0B11E` oder `<#E0B11E>`.

Der Material-Browser zeigt alle Minecraft-Items in Kategorien:

- Favoriten
- Bloecke
- Deko
- Tools/Waffen
- Ruestung
- Essen
- Redstone
- Natur
- Utility
- Spawn-Eggs
- Alle

Sound, Kategorie, Permission, Untermenue, Menge, CustomModelData, Close-after-click, Material und Design laufen direkt per GUI.

## Command-Editor

Im Item-Editor oeffnet `Commands` den Command-Editor.

- Linksklick auf einen bestehenden Command: Argument-Builder oeffnen und bearbeiten
- Rechtsklick auf einen Command: loeschen mit Bestaetigung
- Button `Server-Command hinzufuegen`: zeigt alle aktuell geladenen Bukkit/Paper Commands inklusive Plugin-Commands und Aliase
- Linksklick im Browser startet den Builder als `player:<command>`
- Rechtsklick im Browser startet den Builder als `console:<command>`
- Button `Close-Aktion hinzufuegen`: fuegt `close` ohne Chat hinzu

## Command-Argument-Builder

Nach der Command-Auswahl wird der Builder geoeffnet. Dort sieht man eine Vorschau, z. B.:

```txt
player:minecraft:teleport @a 100 64 100
```

Moegliche Bausteine:

- Selector: `@a`, `@p`, `@s`, `@r`, `@e`
- Platzhalter: `<player>`, `<world>`
- Laufzeit-Koordinaten: `<x> <y> <z>`
- Laufzeit-Blockkoordinaten: `<block_x> <block_y> <block_z>`
- Feste Admin-Koordinaten: Position des Admins beim Bearbeiten
- Relative Koordinaten: `~ ~ ~`
- Blickrichtung: `<yaw> <pitch>`
- Zahlen: `1`, `10`, `64`, `100`
- Eigener Wert: Amboss-GUI, ohne Chat

Bekannte Commands bekommen passende Layouts:

- `teleport`, `tp`, `minecraft:teleport`: Ziel, feste Koordinaten, Laufzeit-Koordinaten, relativ, Blickrichtung
- `give`: Ziel, Item per Amboss oder Preset, Menge
- `gamemode`: survival, creative, adventure, spectator und Ziel
- `effect`: give/clear, Ziel, Effekt, Dauer und Staerke
- `mvtp`, `mv`: Unterbefehl `tp`, geladene Welten oder Welt per Amboss
- `spawn`, `rslspawn`: direkt speicherbar, optional Ziel
- `warp`, `home`, `sethome`: Name per Amboss oder Preset
- `tell`, `msg`, `teammsg`: Ziel und Nachricht per Amboss

Unbekannte Plugin-Commands bekommen automatisch den generischen Builder.

Builder-Aktionen:

- Modus wechseln zwischen `player:` und `console:`
- Letztes Argument loeschen
- Alle Argumente leeren
- Anderen Command waehlen
- Speichern

Unterstuetzte Aktionen:

```txt
player:spawn
console:give <player> diamond 1
message:&6Discord: &fdiscord.gg/Kvk4tExqZJ
menu:worlds
sound:UI_BUTTON_CLICK
close
```

Platzhalter:

- `<player>` oder `%player%`
- `<world>`
- `<x>`, `<y>`, `<z>`
- `<block_x>`, `<block_y>`, `<block_z>`
- `<yaw>`, `<pitch>`

## Globale Settings

Im Settings-GUI kann man diese Optionen direkt im Spiel bearbeiten:

- Plugin aktiv/an
- Chat-Punkt `.` aktiv/an
- Befehl `/.` aktiv/an
- Punkt-Nachricht abbrechen/an
- Klick-Cooldown in Millisekunden per Zahlen-Picker

## Rechte

- `rslnavigator.open` fuer Spieler.
- `rslnavigator.admin` fuer Dashboard, Editor und Verwaltung.

## Wichtige Befehle

```txt
/rslnav
/.
/rslnav open [menu]
/rslnav admin
/rslnav edit <menu>
/rslnav reload
/rslnav save
```

Die alten Verwaltungsbefehle fuer `menu` und `item` bleiben kompatibel, aber der Hauptweg ist jetzt der GUI-first Editor.

## Build

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.10.7-hotspot'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat clean build
```

Jar: `build/libs/RSLNavigator-1.0.0.jar`

# RSLBalance

Eigenes Vault-Economy-Plugin fuer Paper/Spigot 1.20.1 bis 1.21.x.

## Wichtig

- Die Jar gehoert in den `plugins` Ordner eines Paper/Spigot-Servers.
- Vault muss installiert sein, damit TAB und andere Plugins den Kontostand sehen.
- TAB kann den Kontostand mit `%vault_eco_balance_formatted%` anzeigen.
- PlaceholderAPI bekommt zusaetzlich `%rslbalance_balance%` und `%rslbalance_balance_formatted%`.

## Befehle

- `/rslbalance` zeigt den eigenen Kontostand.
- `/rslbalance <spieler>` zeigt als Admin den Kontostand eines Spielers.
- `/rsleco set <spieler> <betrag>` setzt Geld.
- `/rsleco add <spieler> <betrag>` gibt Geld.
- `/rsleco take <spieler> <betrag>` nimmt Geld.
- `/rsleco reload` laedt Config und Balances neu.

## Rechte

- `rslbalance.admin` fuer Admin-Befehle. OPs haben die Rechte automatisch.

package de.rsl.welcome;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

public class RSLWelcomePlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private File serverNameFile;
    private FileConfiguration serverNameConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadServerNameConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("rslwelcome") != null) {
            getCommand("rslwelcome").setExecutor(this);
            getCommand("rslwelcome").setTabCompleter(this);
        }
        getLogger().info("RSLWelcome enabled.");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        long delay = Math.max(0L, getConfig().getLong("welcome.join-delay-ticks", 18L));
        Bukkit.getScheduler().runTaskLater(this, () -> playWelcome(player), delay);
    }

    private void playWelcome(Player player) {
        if (!player.isOnline()) {
            return;
        }
        if (getConfig().getBoolean("title-animation.enabled", true)) {
            playTitleAnimation(player);
        }
        if (getConfig().getBoolean("welcome.chat-message-enabled", true)) {
            sendPrivateChatMessage(player);
        }
    }

    private void playTitleAnimation(Player player) {
        if (getConfig().getBoolean("title-animation.spell-player-name.enabled", true)) {
            playSpelledPlayerTitle(player);
            return;
        }

        List<TitleFrame> frames = loadFrames();
        if (frames.isEmpty()) {
            return;
        }

        long interval = Math.max(1L, getConfig().getLong("title-animation.frame-interval-ticks", 8L));
        int fadeIn = Math.max(0, getConfig().getInt("title-animation.fade-in-ticks", 0));
        int stay = Math.max(1, getConfig().getInt("title-animation.stay-ticks", 14));
        int fadeOut = Math.max(0, getConfig().getInt("title-animation.fade-out-ticks", 6));

        for (int index = 0; index < frames.size(); index++) {
            TitleFrame frame = frames.get(index);
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!player.isOnline()) {
                    return;
                }
                Title title = Title.title(
                        render(player, frame.title()),
                        render(player, frame.subtitle()),
                        Title.Times.times(ticks(fadeIn), ticks(stay), ticks(fadeOut))
                );
                player.showTitle(title);
            }, index * interval);
        }
    }

    private void playSpelledPlayerTitle(Player player) {
        int fadeIn = Math.max(0, getConfig().getInt("title-animation.fade-in-ticks", 0));
        int stay = Math.max(1, getConfig().getInt("title-animation.stay-ticks", 14));
        int fadeOut = Math.max(0, getConfig().getInt("title-animation.fade-out-ticks", 6));

        String introTitle = getConfig().getString("title-animation.spell-player-name.intro-title", "<#C9852E>&lWILLKOMMEN");
        String introSubtitle = getConfig().getString("title-animation.spell-player-name.intro-subtitle", "<#D9A441>bei <server_smp>");
        int introStay = Math.max(1, getConfig().getInt("title-animation.spell-player-name.intro-stay-ticks", 24));
        int introPause = Math.max(0, getConfig().getInt("title-animation.spell-player-name.pause-after-intro-ticks", 12));
        int letterInterval = Math.max(1, getConfig().getInt("title-animation.spell-player-name.letter-interval-ticks", 4));
        int finalDelay = Math.max(0, getConfig().getInt("title-animation.spell-player-name.final-delay-ticks", 8));
        boolean uppercaseName = getConfig().getBoolean("title-animation.spell-player-name.uppercase-player-name", false);

        showTitle(player, introTitle, introSubtitle, fadeIn, introStay, fadeOut, Map.of());
        playConfiguredSound(player, "title-animation.spell-player-name.sounds.intro",
                "ENTITY_PLAYER_LEVELUP",
                (float) getConfig().getDouble("title-animation.spell-player-name.sounds.volume", 0.8D),
                (float) getConfig().getDouble("title-animation.spell-player-name.sounds.intro-pitch", 0.85D));

        String playerName = uppercaseName ? player.getName().toUpperCase(Locale.ROOT) : player.getName();
        String spellTitle = getConfig().getString("title-animation.spell-player-name.spell-title",
                "<gradient:#FFF1B8:#E0B11E:#B86A3B>&l<typed_player><cursor></gradient>");
        String spellSubtitle = getConfig().getString("title-animation.spell-player-name.spell-subtitle",
                "<#C9852E>dein Abenteuer startet gleich");
        String cursor = getConfig().getString("title-animation.spell-player-name.cursor", "_");

        long spellStart = introStay + introPause;
        for (int index = 1; index <= playerName.length(); index++) {
            String typedName = playerName.substring(0, index);
            int letterIndex = index;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                showTitle(player, spellTitle, spellSubtitle, fadeIn, stay, fadeOut, Map.of(
                        "<typed_player>", escapeMiniMessage(typedName),
                        "<cursor>", cursor
                ));
                float basePitch = (float) getConfig().getDouble("title-animation.spell-player-name.sounds.letter-pitch-start", 1.0D);
                float pitchStep = (float) getConfig().getDouble("title-animation.spell-player-name.sounds.letter-pitch-step", 0.035D);
                playConfiguredSound(player, "title-animation.spell-player-name.sounds.letter",
                        "BLOCK_NOTE_BLOCK_PLING",
                        (float) getConfig().getDouble("title-animation.spell-player-name.sounds.volume", 0.8D),
                        Math.min(2.0F, basePitch + (letterIndex * pitchStep)));
            }, spellStart + ((long) (index - 1) * letterInterval));
        }

        String finalTitle = getConfig().getString("title-animation.spell-player-name.final-title",
                "<gradient:#8B5A2B:#E0B11E:#FFF1B8>&l<server_smp></gradient>");
        String finalSubtitle = getConfig().getString("title-animation.spell-player-name.final-subtitle",
                "<#F2D16B>Willkommen, <player>");
        long finalStart = spellStart + ((long) playerName.length() * letterInterval) + finalDelay;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            showTitle(player, finalTitle, finalSubtitle, fadeIn, Math.max(stay, 34), fadeOut, Map.of());
            playConfiguredSound(player, "title-animation.spell-player-name.sounds.final",
                    "UI_TOAST_CHALLENGE_COMPLETE",
                    (float) getConfig().getDouble("title-animation.spell-player-name.sounds.volume", 0.8D),
                    (float) getConfig().getDouble("title-animation.spell-player-name.sounds.final-pitch", 1.15D));
        }, finalStart);
    }

    private void playConfiguredSound(Player player, String path, String fallback, float volume, float pitch) {
        if (!getConfig().getBoolean("title-animation.spell-player-name.sounds.enabled", true) || !player.isOnline()) {
            return;
        }

        String soundName = getConfig().getString(path, fallback);
        if (soundName == null || soundName.isBlank()) {
            return;
        }

        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, SoundCategory.MASTER, volume, pitch);
        } catch (IllegalArgumentException exception) {
            getLogger().warning("Unknown sound in config: " + soundName);
        }
    }

    private void showTitle(Player player, String titleText, String subtitleText, int fadeIn, int stay,
                           int fadeOut, Map<String, String> extraPlaceholders) {
        if (!player.isOnline()) {
            return;
        }
        Title title = Title.title(
                render(player, titleText, extraPlaceholders),
                render(player, subtitleText, extraPlaceholders),
                Title.Times.times(ticks(fadeIn), ticks(stay), ticks(fadeOut))
        );
        player.showTitle(title);
    }

    private void sendPrivateChatMessage(Player player) {
        for (String line : getConfig().getStringList("welcome.chat-lines")) {
            player.sendMessage(render(player, line));
        }
    }

    private List<TitleFrame> loadFrames() {
        List<TitleFrame> frames = new ArrayList<>();
        List<Map<?, ?>> rawFrames = getConfig().getMapList("title-animation.frames");
        for (Map<?, ?> rawFrame : rawFrames) {
            frames.add(new TitleFrame(value(rawFrame.get("title")), value(rawFrame.get("subtitle"))));
        }
        return frames;
    }

    private String value(Object object) {
        return object == null ? "" : String.valueOf(object);
    }

    private Component render(Player player, String template) {
        return render(player, template, Map.of());
    }

    private Component render(Player player, String template, Map<String, String> extraPlaceholders) {
        String rendered = applyPlaceholders(player, template);
        for (Map.Entry<String, String> entry : extraPlaceholders.entrySet()) {
            rendered = rendered.replace(entry.getKey(), entry.getValue());
        }
        return miniMessage.deserialize(rendered);
    }

    private String applyPlaceholders(Player player, String text) {
        String serverName = detectServerName();
        String serverSmp = serverSmpName(serverName);
        return text
                .replace("<player>", escapeMiniMessage(player.getName()))
                .replace("<server>", escapeMiniMessage(serverName))
                .replace("<server_smp>", escapeMiniMessage(serverSmp));
    }

    private String detectServerName() {
        String configured = cleanName(serverNameConfig.getString("server-name", ""));
        if (serverNameConfig.getBoolean("enabled", true) && !configured.isBlank()) {
            return configured;
        }

        FileConfiguration config = getConfig();
        String forced = cleanName(config.getString("server.forced-name", ""));
        if (!forced.isBlank()) {
            return forced;
        }

        if (!config.getBoolean("server.auto-detect-name", true)) {
            return cleanName(config.getString("server.fallback-name", "NeyexSMP"));
        }

        List<String> candidates = new ArrayList<>();
        candidates.add(readServerProperty("motd"));
        candidates.add(readServerProperty("server-name"));
        candidates.add(Bukkit.getMotd());
        candidates.add(Bukkit.getServer().getName());

        for (String candidate : candidates) {
            String clean = cleanName(candidate);
            if (isUsefulName(clean)) {
                return clean;
            }
        }

        return cleanName(config.getString("server.fallback-name", "NeyexSMP"));
    }

    private void loadServerNameConfig() {
        serverNameFile = new File(getDataFolder(), "server-name.yml");
        if (!serverNameFile.exists()) {
            saveResource("server-name.yml", false);
        }
        serverNameConfig = YamlConfiguration.loadConfiguration(serverNameFile);
    }

    private String serverSmpName(String serverName) {
        if (!getConfig().getBoolean("server.append-smp-if-missing", true)) {
            return serverName;
        }
        if (serverName.toLowerCase(Locale.ROOT).contains("smp")) {
            return serverName;
        }
        return serverName + " SMP";
    }

    private String readServerProperty(String key) {
        File serverFolder = getDataFolder().getParentFile() == null ? null : getDataFolder().getParentFile().getParentFile();
        if (serverFolder == null) {
            return "";
        }

        File serverProperties = new File(serverFolder, "server.properties");
        if (!serverProperties.exists()) {
            return "";
        }

        Properties properties = new Properties();
        try (FileInputStream inputStream = new FileInputStream(serverProperties)) {
            properties.load(inputStream);
            return properties.getProperty(key, "");
        } catch (IOException exception) {
            return "";
        }
    }

    private boolean isUsefulName(String name) {
        if (name.isBlank()) {
            return false;
        }
        String lowered = name.toLowerCase(Locale.ROOT);
        return !lowered.equals("a minecraft server")
                && !lowered.equals("minecraft server")
                && !lowered.equals("dedicated server")
                && !lowered.equals("paper")
                && !lowered.equals("spigot")
                && !lowered.equals("craftbukkit")
                && !lowered.contains("synhost")
                && !lowered.contains("powered by")
                && !lowered.contains("hosting");
    }

    private String cleanName(String input) {
        if (input == null) {
            return "";
        }
        String clean = input
                .replaceAll("(?i)&[0-9a-fk-or]", "")
                .replaceAll("(?i)§[0-9a-fk-or]", "")
                .replaceAll("<[^>]+>", "")
                .replace("\\n", " ")
                .replace("|", " ");
        clean = clean.replaceAll("\\s+", " ").trim();
        if (clean.toLowerCase(Locale.ROOT).endsWith(".de")) {
            clean = clean.substring(0, clean.length() - 3);
        }
        return clean;
    }

    private String escapeMiniMessage(String input) {
        return input.replace("\\", "\\\\").replace("<", "\\<").replace(">", "\\>");
    }

    private Duration ticks(int ticks) {
        return Duration.ofMillis(ticks * 50L);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("rslwelcome.admin")) {
            sender.sendMessage(miniMessage.deserialize("<red>Dazu hast du keine Rechte."));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(miniMessage.deserialize("<#E0B11E>Nutze: /rslwelcome <reload|test>"));
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            loadServerNameConfig();
            sender.sendMessage(miniMessage.deserialize("<#E0B11E>RSLWelcome wurde neu geladen."));
            return true;
        }

        if (args[0].equalsIgnoreCase("test")) {
            if (sender instanceof Player player) {
                playWelcome(player);
                sender.sendMessage(miniMessage.deserialize("<#E0B11E>Welcome-Test gestartet."));
            } else {
                sender.sendMessage(miniMessage.deserialize("<red>Der Test geht nur als Spieler."));
            }
            return true;
        }

        sender.sendMessage(miniMessage.deserialize("<#E0B11E>Nutze: /rslwelcome <reload|test>"));
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1 && sender.hasPermission("rslwelcome.admin")) {
            String current = args[0].toLowerCase(Locale.ROOT);
            return List.of("reload", "test").stream()
                    .filter(value -> value.startsWith(current))
                    .toList();
        }
        return List.of();
    }

    private record TitleFrame(String title, String subtitle) {
    }
}

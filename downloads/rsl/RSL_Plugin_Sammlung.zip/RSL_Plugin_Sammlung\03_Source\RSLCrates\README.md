# RSLCrates

RSLCrates ist ein Paper/Spigot Plugin fuer Crates mit Keys, Vault/RSLBalance-Preis, GUI-Editor, Reward-Chancen und TextDisplay-Anzeige.

## Features

- Admin schaut einen Block an und erstellt daraus eine Crate.
- `/rslcrates admin` oeffnet den GUI-Baukasten.
- Crates koennen mit Key oder optional mit Geld ueber Vault/RSLBalance geoeffnet werden.
- Rewards: Items, Commands, Money und Nachrichten.
- Chancen werden automatisch aus Reward-Gewichten berechnet.
- Keys sind echte Items mit PersistentDataContainer.
- TextDisplay ueber der Crate zeigt Name, Preis, Key-Hinweis und Top-Chancen.
- Vorlagen: Vote, Daily, Epic, Legendary, Event.
- Crate-Varianten: KEY, PAID, KEY_OR_PAID, FREE, TIMED, PREVIEW, MYSTERY, EVENT, VIP, JACKPOT, STREAK, LEVEL.
- Animationen: NONE, QUICK_ROLL, CLASSIC_ROLL, SLOT_MACHINE, SPIN_CIRCLE, COUNTDOWN, MYSTERY_REVEAL, JACKPOT_BUILDUP, RAINBOW_ROLL, FIREWORK_BURST, LIGHTNING_STRIKE, DRAGON_SPIN, BEACON_BEAM, ENDER_PORTAL, TREASURE_CHEST, LUCKY_WHEEL, CARD_FLIP, CRYSTAL_CHARGE, RUNE_CIRCLE, METEOR_DROP, GOLD_RUSH, SOUL_STORM, REDSTONE_OVERLOAD, CRATE_SHAKE, FINAL_REVEAL.
- Effekt-Staerke pro Crate: CALM, NORMAL oder EPIC fuer Partikel, Sounds, TextDisplay-Status und Reveal-Wucht.
- Timing pro Crate: Cooldown, Roll-Dauer, Roll-Speed, Final-Delay und Event-Fenster.
- Reward-Funktionen koennen kombiniert werden: Item, Command, Money, Message, Permission geben/nehmen, XP-Level, Sound und Broadcast.
- `data.yml` speichert Cooldowns und Streaks pro Spieler.
- Crates koennen im Editor oder per Rechtsklick in der Crate-Liste geloescht werden.
- RSLCrates verhindert neue ueberlappende Crates auf demselben Block.
- Der Crate-Name hat einen GUI-Designer fuer Farben, Hex-Codes, Gradient und Font-Presets.

## GUI-Baukasten

Im Crate-Editor gibt es eigene Untermenues fuer:

- Crate-Variante
- Timing
- Requirements
- Jackpot/Streak
- Animation
- Effekt-Staerke
- Rewards und Reward-Funktionen
- Crate loeschen mit Bestaetigung
- Crate-Name Design mit Farbcodes und Font-Generator

Alte Crates bleiben kompatibel. Fehlende neue Werte bekommen Defaults beim Laden.

## Commands

```txt
/rslcrates admin
/rslcrates create <id>
/rslcrates edit <id>
/rslcrates key give <spieler> <crate> [anzahl]
/rslcrates reload
/rslcrates save
/rslcrates list
```

## Permissions

```txt
rslcrates.open
rslcrates.admin
rslcrates.key.give
```

## Build

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.10.7-hotspot'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat clean build
```

Jar: `build/libs/RSLCrates-1.0.0.jar`

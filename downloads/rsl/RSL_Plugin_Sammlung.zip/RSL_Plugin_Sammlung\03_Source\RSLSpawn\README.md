# RSLSpawn

RSLSpawn ist ein kleines Paper/Spigot Plugin fuer einen festen Join-Spawn.

## Idee

Wenn ein Spieler joined, wird er nach kurzer Verzoegerung immer an denselben festgelegten Spawn teleportiert.
Das passt besonders fuer Server mit Multiverse-Core, bei denen eine eigene Spawn-Welt existiert.

RSLSpawn braucht Multiverse-Core nicht zwingend. Es speichert nur den Welt-Namen. Wenn Multiverse die Welt geladen hat, funktioniert der Spawn automatisch.

## Befehle

- `/spawn` teleportiert dich zum gesetzten RSL Spawn.
- `/rslspawn set` setzt den Spawn auf deine aktuelle Position.
- `/rslspawn setworld <welt>` setzt den Spawn auf den Weltspawn einer geladenen Welt.
- `/rslspawn tp` teleportiert dich zum RSL Spawn.
- `/rslspawn status` zeigt die aktuelle Einstellung.
- `/rslspawn reload` laedt die Config neu.

## Rechte

- `rslspawn.spawn` fuer `/spawn` standardmaessig fuer alle Spieler.
- `rslspawn.admin` fuer Setzen, Reload und Status.
- `rslspawn.tp` fuer `/rslspawn tp`.
- OPs haben die Rechte automatisch.

## Multiverse-Core

1. Spawn-Welt mit Multiverse erstellen oder laden.
2. In die Spawn-Welt gehen.
3. An die richtige Stelle stellen.
4. `/rslspawn set` ausfuehren.

Alternativ:

`/rslspawn setworld spawn`

## Config

```yml
settings:
  teleport-on-join: true
  join-delay-ticks: 20
  teleport-on-respawn: false
```

`teleport-on-respawn` ist standardmaessig aus, damit nur der Join erzwungen wird.

## Build

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.10.7-hotspot'
$env:Path="$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat clean build
```

Die fertige Jar liegt danach in `build/libs/RSLSpawn-1.0.0.jar`.

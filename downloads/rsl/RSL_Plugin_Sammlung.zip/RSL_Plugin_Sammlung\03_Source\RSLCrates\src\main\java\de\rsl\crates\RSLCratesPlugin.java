package de.rsl.crates;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public final class RSLCratesPlugin extends JavaPlugin implements Listener, TabExecutor {
    private static final List<String> ROOT_COMMANDS = Arrays.asList("admin", "create", "edit", "key", "reload", "save", "list", "help");
    private static final String DISPLAY_TAG = "rslcrates_display";
    private static final Pattern HEX_AMP_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final Pattern HEX_TAG_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");

    private final Map<String, Crate> crates = new LinkedHashMap<>();
    private final Map<UUID, PendingInput> pendingInputs = new ConcurrentHashMap<>();
    private final Map<String, TextDisplay> displays = new HashMap<>();
    private final Random random = new Random();
    private NamespacedKey keyCrateId;
    private File cratesFile;
    private FileConfiguration cratesConfig;
    private File dataFile;
    private FileConfiguration dataConfig;
    private Economy economy;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("crates.yml", false);
        keyCrateId = new NamespacedKey(this, "crate_id");
        cratesFile = new File(getDataFolder(), "crates.yml");
        dataFile = new File(getDataFolder(), "data.yml");
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("rslcrates"), "rslcrates command missing").setExecutor(this);
        Objects.requireNonNull(getCommand("rslcrates"), "rslcrates command missing").setTabCompleter(this);
        setupEconomy();
        loadPlayerData();
        loadCrates();
        Bukkit.getScheduler().runTaskLater(this, this::refreshDisplays, 20L);
    }

    @Override
    public void onDisable() {
        removeDisplays();
        savePlayerData();
        saveCrates();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("admin")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            openAdmin(player);
            return true;
        }
        if (sub.equals("create")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(color(prefix() + "&cNutze: &e/rslcrates create <id>"));
                return true;
            }
            createCrateFromTarget(player, cleanId(args[1]));
            return true;
        }
        if (sub.equals("edit")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            if (!(sender instanceof Player player)) {
                send(sender, "only-player");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(color(prefix() + "&cNutze: &e/rslcrates edit <id>"));
                return true;
            }
            openCrateEditor(player, cleanId(args[1]));
            return true;
        }
        if (sub.equals("key")) {
            return handleKeyCommand(sender, args);
        }
        if (sub.equals("reload")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            reloadConfig();
            setupEconomy();
            loadCrates();
            refreshDisplays();
            send(sender, "reloaded");
            return true;
        }
        if (sub.equals("save")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            saveCrates();
            send(sender, "saved");
            return true;
        }
        if (sub.equals("list")) {
            if (!requireAdmin(sender)) {
                return true;
            }
            sender.sendMessage(color(prefix() + "&6Crates: &f" + String.join("&7, &f", crates.keySet())));
            return true;
        }
        sendHelp(sender);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(ROOT_COMMANDS, args[0]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("edit") || args[0].equalsIgnoreCase("create"))) {
            return filter(new ArrayList<>(crates.keySet()), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("key")) {
            return filter(Collections.singletonList("give"), args[1]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("key") && args[1].equalsIgnoreCase("give")) {
            return filter(new ArrayList<>(crates.keySet()), args[3]);
        }
        return Collections.emptyList();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        PendingInput input = pendingInputs.get(event.getPlayer().getUniqueId());
        if (input == null) {
            return;
        }
        event.setCancelled(true);
        Bukkit.getScheduler().runTask(this, () -> handlePendingInput(event.getPlayer(), event.getMessage()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onCrateClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) {
            return;
        }
        Crate crate = crateAt(event.getClickedBlock().getLocation()).orElse(null);
        if (crate == null) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!player.hasPermission("rslcrates.open")) {
            send(player, "no-permission");
            return;
        }
        openCrate(player, crate);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (holder instanceof AdminHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleAdminClick(player, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof CrateListHolder crateListHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCrateListClick(player, crateListHolder.page, event.getRawSlot(), event.getClick());
            }
            return;
        }
        if (holder instanceof CrateEditorHolder crateEditorHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleCrateEditorClick(player, crateEditorHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof RewardListHolder rewardListHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleRewardListClick(player, rewardListHolder.crateId, rewardListHolder.page, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof RewardEditorHolder rewardEditorHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleRewardEditorClick(player, rewardEditorHolder.crateId, rewardEditorHolder.rewardId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof TemplateHolder templateHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleTemplateClick(player, templateHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof VariantHolder variantHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleVariantClick(player, variantHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof AnimationHolder animationHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleAnimationClick(player, animationHolder.crateId, animationHolder.page, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof EffectLevelHolder effectLevelHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleEffectLevelClick(player, effectLevelHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof TimingHolder timingHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleTimingClick(player, timingHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof RequirementHolder requirementHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleRequirementClick(player, requirementHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof JackpotHolder jackpotHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleJackpotClick(player, jackpotHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof TextDesignHolder textDesignHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleTextDesignClick(player, textDesignHolder.crateId, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof ConfirmHolder confirmHolder) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) {
                handleConfirmClick(player, confirmHolder, event.getRawSlot());
            }
            return;
        }
        if (holder instanceof RollHolder) {
            event.setCancelled(true);
        }
    }

    private void createCrateFromTarget(Player player, String crateId) {
        if (crateId.isBlank()) {
            player.sendMessage(color(prefix() + "&cCrate-ID ist leer."));
            return;
        }
        if (crates.containsKey(crateId)) {
            player.sendMessage(color(prefix() + "&cDiese Crate existiert schon."));
            return;
        }
        Block block = player.getTargetBlockExact(8);
        if (block == null || block.getType().isAir()) {
            send(player, "no-target-block");
            return;
        }
        Optional<Crate> existingAtTarget = crateAt(block.getLocation());
        if (existingAtTarget.isPresent()) {
            sendRaw(player, "&cAuf diesem Block liegt schon die Crate &e" + existingAtTarget.get().id + "&c.");
            return;
        }
        Crate crate = Crate.defaultCrate(crateId, block.getLocation(), block.getType(), getConfig().getDouble("settings.default-crate-price", 250.0D));
        crates.put(crateId, crate);
        saveCrates();
        refreshDisplays();
        sendRaw(player, message("crate-created").replace("<crate>", crateId));
        openCrateEditor(player, crateId);
    }

    private boolean handleKeyCommand(CommandSender sender, String[] args) {
        if (args.length < 2 || !args[1].equalsIgnoreCase("give")) {
            sender.sendMessage(color(prefix() + "&cNutze: &e/rslcrates key give <spieler> <crate> [anzahl]"));
            return true;
        }
        if (!sender.hasPermission("rslcrates.key.give")) {
            send(sender, "no-permission");
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(color(prefix() + "&cNutze: &e/rslcrates key give <spieler> <crate> [anzahl]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(color(prefix() + "&cSpieler nicht gefunden."));
            return true;
        }
        Crate crate = crates.get(cleanId(args[3]));
        if (crate == null) {
            sendRaw(sender, message("crate-not-found").replace("<crate>", args[3]));
            return true;
        }
        int amount = args.length >= 5 ? clamp(parseInt(args[4], 1), 1, 64) : 1;
        target.getInventory().addItem(crate.keyItem(amount, keyCrateId));
        sendRaw(sender, message("key-given").replace("<crate>", crate.id));
        return true;
    }

    private void openCrate(Player player, Crate crate) {
        OpenResult result = checkAndPay(player, crate);
        if (!result.success) {
            sendRaw(player, result.message);
            return;
        }
        if (crate.variant == CrateVariant.PREVIEW) {
            openPreview(player, crate);
            return;
        }
        Reward reward = crate.roll(random);
        if (reward == null) {
            player.sendMessage(color(prefix() + "&cDiese Crate hat noch keine Rewards."));
            return;
        }
        play(player, "sounds.click");
        animateReward(player, crate, reward, result);
    }

    private OpenResult checkAndPay(Player player, Crate crate) {
        long now = System.currentTimeMillis();
        long lastOpened = lastOpened(player, crate.id);
        if (crate.cooldownSeconds > 0 && now - lastOpened < crate.cooldownSeconds * 1000L) {
            return OpenResult.fail("&cCooldown aktiv: &e" + formatDuration(crate.cooldownSeconds * 1000L - (now - lastOpened)));
        }
        if ((crate.variant == CrateVariant.TIMED || crate.variant == CrateVariant.EVENT) && !crate.eventActive(now)) {
            return OpenResult.fail("&cDiese Crate ist gerade nicht aktiv.");
        }
        if (crate.variant == CrateVariant.VIP && !crate.vipPermission.isBlank() && !player.hasPermission(crate.vipPermission)) {
            return OpenResult.fail("&cDu brauchst die Permission &e" + crate.vipPermission + "&c.");
        }
        if (crate.variant == CrateVariant.LEVEL && player.getLevel() < crate.minLevel) {
            return OpenResult.fail("&cDu brauchst mindestens Level &e" + crate.minLevel + "&c.");
        }
        boolean usedKey = false;
        boolean paid = false;
        if (crate.variant == CrateVariant.KEY) {
            if (!consumeKey(player, crate.id)) {
                return OpenResult.fail("&cDu brauchst einen Key fuer diese Crate.");
            }
            usedKey = true;
        } else if (crate.variant == CrateVariant.PAID) {
            if (!pay(player, crate.price)) {
                return OpenResult.fail(paymentFailure(crate));
            }
            paid = crate.price > 0.0D;
        } else if (crate.variant == CrateVariant.FREE || crate.variant == CrateVariant.TIMED || crate.variant == CrateVariant.PREVIEW) {
            // free by variant
        } else {
            if (consumeKey(player, crate.id)) {
                usedKey = true;
            } else if (crate.price > 0.0D) {
                if (!pay(player, crate.price)) {
                    return OpenResult.fail(paymentFailure(crate));
                }
                paid = true;
            }
        }
        return OpenResult.success(usedKey, paid);
    }

    private boolean pay(Player player, double price) {
        if (price <= 0.0D) {
            return true;
        }
        if (economy == null || !economy.has(player, price)) {
            return false;
        }
        economy.withdrawPlayer(player, price);
        return true;
    }

    private String paymentFailure(Crate crate) {
        if (crate.price <= 0.0D) {
            return "&cDiese Crate kann gerade nicht geoeffnet werden.";
        }
        if (economy == null) {
            return message("economy-missing");
        }
        return message("not-enough-money").replace("<price>", formatMoney(crate.price));
    }

    private void openPreview(Player player, Crate crate) {
        Inventory inventory = Bukkit.createInventory(new RollHolder(), 54, color(crate.name + " &8Preview"));
        int total = crate.totalWeight();
        for (int i = 0; i < Math.min(45, crate.rewards.size()); i++) {
            inventory.setItem(i, crate.rewards.get(i).previewWithChance(crate, total));
        }
        inventory.setItem(49, button(Material.BARRIER, "&cNur Vorschau", "&7Diese Variante gibt keinen Gewinn aus."));
        player.openInventory(inventory);
    }

    private void animateReward(Player player, Crate crate, Reward reward, OpenResult result) {
        if (crate.animationType == AnimationType.NONE) {
            finishOpening(player, crate, reward, result);
            return;
        }
        Inventory inventory = Bukkit.createInventory(new RollHolder(), 27, color(crate.name));
        player.openInventory(inventory);
        updateDisplayStatus(crate, animationStatus(crate, 0, false));
        List<Reward> pool = crate.rewards.isEmpty() ? Collections.singletonList(reward) : crate.rewards;
        long maxTicks = Math.max(10L, crate.rollTicks);
        long interval = Math.max(1L, crate.rollIntervalTicks);
        new BukkitRunnable() {
            private int tick = 0;
            private int frame = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    resetDisplay(crate);
                    cancel();
                    return;
                }
                tick += interval;
                frame++;
                renderAnimationFrame(player, crate, inventory, pool, reward, tick >= maxTicks, frame);
                worldEffect(crate, frame);
                if (frame % 4 == 0 || tick >= maxTicks) {
                    updateDisplayStatus(crate, animationStatus(crate, frame, tick >= maxTicks));
                }
                if (tick >= maxTicks) {
                    cancel();
                    Bukkit.getScheduler().runTaskLater(RSLCratesPlugin.this, () -> {
                        player.closeInventory();
                        finishOpening(player, crate, reward, result);
                        resetDisplay(crate);
                    }, Math.max(1L, crate.finalDelayTicks));
                }
            }
        }.runTaskTimer(this, 0L, interval);
    }

    private void renderAnimationFrame(Player player, Crate crate, Inventory inventory, List<Reward> pool, Reward reward, boolean finalFrame, int frame) {
        playAnimationSound(player, crate, finalFrame, frame);
        if (finalFrame || crate.animationType == AnimationType.FINAL_REVEAL) {
            renderFinalReveal(inventory, crate, reward, frame);
            return;
        }
        switch (crate.animationType) {
            case COUNTDOWN -> renderCountdown(inventory, frame);
            case MYSTERY_REVEAL -> renderMysteryReveal(inventory, crate, pool, frame);
            case SPIN_CIRCLE, LUCKY_WHEEL, DRAGON_SPIN -> renderSpinCircle(inventory, crate, pool, frame);
            case SLOT_MACHINE, JACKPOT_BUILDUP -> renderSlotMachine(inventory, crate, pool);
            case RAINBOW_ROLL -> renderRainbowRoll(inventory, crate, pool, frame);
            case FIREWORK_BURST -> renderFireworkBurst(inventory, crate, pool, frame);
            case LIGHTNING_STRIKE -> renderLightningStrike(inventory, crate, pool, frame);
            case BEACON_BEAM -> renderBeaconBeam(inventory, crate, pool, frame);
            case ENDER_PORTAL -> renderEnderPortal(inventory, crate, pool, frame);
            case TREASURE_CHEST -> renderTreasureChest(inventory, crate, pool, frame);
            case CARD_FLIP -> renderCardFlip(inventory, crate, pool, frame);
            case CRYSTAL_CHARGE -> renderCrystalCharge(inventory, crate, pool, frame);
            case RUNE_CIRCLE -> renderRuneCircle(inventory, crate, pool, frame);
            case METEOR_DROP -> renderMeteorDrop(inventory, crate, pool, frame);
            case GOLD_RUSH -> renderGoldRush(inventory, crate, pool, frame);
            case SOUL_STORM -> renderSoulStorm(inventory, crate, pool, frame);
            case REDSTONE_OVERLOAD -> renderRedstoneOverload(inventory, crate, pool, frame);
            case CRATE_SHAKE -> renderCrateShake(inventory, crate, pool, frame);
            default -> renderClassicRoll(inventory, crate, pool, frame);
        }
    }

    private void worldEffect(Crate crate, int frame) {
        if (crate.location == null || crate.location.getWorld() == null) {
            return;
        }
        Location location = crate.location.clone().add(0.5D, 1.15D, 0.5D);
        World world = location.getWorld();
        int base = crate.animationType == AnimationType.QUICK_ROLL ? 4 : 10;
        switch (crate.animationType) {
            case FIREWORK_BURST -> {
                spawnParticle(world, "FIREWORKS_SPARK", location, particleCount(crate, 14), 0.55D, 0.65D, 0.55D, 0.03D);
                spawnParticle(world, "END_ROD", location, particleCount(crate, 5), 0.2D, 0.45D, 0.2D, 0.01D);
            }
            case LIGHTNING_STRIKE -> {
                spawnParticle(world, "ELECTRIC_SPARK", location, particleCount(crate, 12), 0.35D, 0.75D, 0.35D, 0.03D);
                if (frame % Math.max(6, 12 - crate.effectLevel.weight) == 0) {
                    world.strikeLightningEffect(location);
                }
            }
            case DRAGON_SPIN -> {
                spawnParticle(world, "DRAGON_BREATH", location, particleCount(crate, 12), 0.55D, 0.35D, 0.55D, 0.02D);
                spawnParticle(world, "PORTAL", location, particleCount(crate, 8), 0.4D, 0.25D, 0.4D, 0.01D);
            }
            case BEACON_BEAM, CRYSTAL_CHARGE -> spawnParticle(world, "END_ROD", location, particleCount(crate, 14), 0.18D, 0.95D, 0.18D, 0.02D);
            case ENDER_PORTAL, MYSTERY_REVEAL -> spawnParticle(world, "PORTAL", location, particleCount(crate, 18), 0.55D, 0.45D, 0.55D, 0.03D);
            case METEOR_DROP -> {
                spawnParticle(world, "FLAME", location.clone().add(0.0D, 0.8D, 0.0D), particleCount(crate, 16), 0.4D, 0.8D, 0.4D, 0.02D);
                spawnParticle(world, "LAVA", location, particleCount(crate, 4), 0.25D, 0.25D, 0.25D, 0.01D);
            }
            case GOLD_RUSH, JACKPOT_BUILDUP -> spawnParticle(world, "TOTEM", location, particleCount(crate, 12), 0.45D, 0.55D, 0.45D, 0.02D);
            case SOUL_STORM -> {
                spawnParticle(world, "SOUL_FIRE_FLAME", location, particleCount(crate, 10), 0.45D, 0.45D, 0.45D, 0.02D);
                spawnParticle(world, "ASH", location, particleCount(crate, 8), 0.55D, 0.35D, 0.55D, 0.01D);
            }
            case REDSTONE_OVERLOAD -> spawnParticle(world, "ELECTRIC_SPARK", location, particleCount(crate, 16), 0.5D, 0.35D, 0.5D, 0.04D);
            case RAINBOW_ROLL, LUCKY_WHEEL -> {
                spawnParticle(world, "VILLAGER_HAPPY", location, particleCount(crate, 8), 0.55D, 0.45D, 0.55D, 0.01D);
                spawnParticle(world, "FIREWORKS_SPARK", location, particleCount(crate, 6), 0.35D, 0.35D, 0.35D, 0.01D);
            }
            case TREASURE_CHEST -> spawnParticle(world, "COMPOSTER", location, particleCount(crate, 10), 0.3D, 0.35D, 0.3D, 0.02D);
            case CRATE_SHAKE -> spawnParticle(world, "CLOUD", location, particleCount(crate, 8), 0.35D, 0.25D, 0.35D, 0.02D);
            default -> spawnParticle(world, "CRIT", location, particleCount(crate, base), 0.35D, 0.35D, 0.35D, 0.02D);
        }
        if (frame % 8 == 0 && crate.animationType != AnimationType.QUICK_ROLL) {
            spawnParticle(world, "FIREWORKS_SPARK", location, particleCount(crate, 6), 0.25D, 0.5D, 0.25D, 0.01D);
        }
    }

    private void renderFinalReveal(Inventory inventory, Crate crate, Reward reward, int frame) {
        fill(inventory, frame % 2 == 0 ? Material.YELLOW_STAINED_GLASS_PANE : Material.ORANGE_STAINED_GLASS_PANE, "&6&lGEWINN");
        int[] border = borderSlots();
        for (int i = 0; i < border.length; i++) {
            inventory.setItem(border[i], button(rainbowPane(frame, i), "&6✦"));
        }
        inventory.setItem(4, button(Material.NETHER_STAR, "&6&lFINAL REVEAL", "&7Dein Gewinn ist bereit."));
        inventory.setItem(11, button(Material.GOLD_BLOCK, "&e✦"));
        inventory.setItem(13, reward.preview(crate));
        inventory.setItem(15, button(Material.GOLD_BLOCK, "&e✦"));
        inventory.setItem(22, button(Material.FIREWORK_ROCKET, "&aAusgegeben", "&7Reward wird jetzt vergeben."));
    }

    private void renderCountdown(Inventory inventory, int frame) {
        int number = Math.max(1, 4 - Math.min(3, frame / 5));
        fill(inventory, Material.BLACK_STAINED_GLASS_PANE, " ");
        inventory.setItem(4, button(Material.CLOCK, "&e&lCOUNTDOWN"));
        inventory.setItem(13, button(Material.CLOCK, "&e&l" + number, "&7Gewinn wird geladen..."));
    }

    private void renderMysteryReveal(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, frame % 2 == 0 ? Material.PURPLE_STAINED_GLASS_PANE : Material.MAGENTA_STAINED_GLASS_PANE, "&d???", "&7Mystery Reward");
        inventory.setItem(4, button(Material.ENDER_EYE, "&d&lMYSTERY", "&7Chancen bleiben versteckt."));
        inventory.setItem(13, frame % 3 == 0 ? randomPreview(pool, crate) : button(Material.NETHER_STAR, "&d???", "&7Gleich wird aufgedeckt."));
    }

    private void renderSpinCircle(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        int[] circle = {0, 1, 2, 5, 8, 17, 26, 25, 24, 21, 18, 9};
        fill(inventory, crate.animationType == AnimationType.DRAGON_SPIN ? Material.PURPLE_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < circle.length; i++) {
            inventory.setItem(circle[i], randomPreview(pool, crate));
        }
        Material marker = crate.animationType == AnimationType.DRAGON_SPIN ? Material.DRAGON_BREATH : Material.GOLD_BLOCK;
        inventory.setItem(circle[frame % circle.length], button(marker, "&6Rollt..."));
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderSlotMachine(Inventory inventory, Crate crate, List<Reward> pool) {
        fill(inventory, Material.BLACK_STAINED_GLASS_PANE, " ");
        inventory.setItem(4, crate.animationType == AnimationType.JACKPOT_BUILDUP
            ? button(Material.NETHER_STAR, "&6&lJACKPOT", "&7Chance: &e" + String.format(Locale.US, "%.1f%%", crate.jackpotChancePermille / 10.0D))
            : button(Material.DROPPER, "&eSlot Machine"));
        int[] slots = {11, 13, 15};
        for (int slot : slots) {
            inventory.setItem(slot, randomPreview(pool, crate));
        }
    }

    private void renderRainbowRoll(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, button(rainbowPane(frame, i), "&f✦"));
        }
        inventory.setItem(10, randomPreview(pool, crate));
        inventory.setItem(13, button(Material.FIREWORK_ROCKET, "&d&lRAINBOW ROLL"));
        inventory.setItem(16, randomPreview(pool, crate));
    }

    private void renderFireworkBurst(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.BLUE_STAINED_GLASS_PANE, " ");
        int[] burst = {4, 10, 12, 13, 14, 16, 22};
        for (int i = 0; i < burst.length; i++) {
            inventory.setItem(burst[i], button(rainbowPane(frame, i), "&e✦"));
        }
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderLightningStrike(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.BLACK_STAINED_GLASS_PANE, " ");
        int[] bolt = frame % 2 == 0 ? new int[] {2, 5, 13, 21, 24} : new int[] {4, 12, 13, 14, 22};
        for (int slot : bolt) {
            inventory.setItem(slot, button(Material.YELLOW_STAINED_GLASS_PANE, "&e&l⚡"));
        }
        inventory.setItem(13, frame % 3 == 0 ? button(Material.BLAZE_ROD, "&e&lLIGHTNING") : randomPreview(pool, crate));
    }

    private void renderBeaconBeam(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.LIGHT_BLUE_STAINED_GLASS_PANE, " ");
        int[] beam = {4, 13, 22};
        for (int slot : beam) {
            inventory.setItem(slot, button(Material.BEACON, "&b&lBEAM"));
        }
        inventory.setItem(10 + (frame % 7), randomPreview(pool, crate));
    }

    private void renderEnderPortal(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int slot : borderSlots()) {
            inventory.setItem(slot, button(frame % 2 == 0 ? Material.PURPLE_STAINED_GLASS_PANE : Material.OBSIDIAN, "&5Portal"));
        }
        inventory.setItem(12, button(Material.ENDER_EYE, "&5Portal"));
        inventory.setItem(13, randomPreview(pool, crate));
        inventory.setItem(14, button(Material.ENDER_EYE, "&5Portal"));
    }

    private void renderTreasureChest(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.BROWN_STAINED_GLASS_PANE, " ");
        inventory.setItem(4, button(Material.TRIPWIRE_HOOK, "&6Schloss"));
        inventory.setItem(11, button(Material.CHEST, "&6Treasure"));
        inventory.setItem(13, frame % 4 == 0 ? button(Material.BARREL, "&eOeffnet...") : randomPreview(pool, crate));
        inventory.setItem(15, button(Material.CHEST, "&6Treasure"));
        inventory.setItem(22, button(Material.GOLD_INGOT, "&eGoldstaub"));
    }

    private void renderCardFlip(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.WHITE_STAINED_GLASS_PANE, " ");
        Material card = switch (frame % 3) {
            case 0 -> Material.PAPER;
            case 1 -> Material.MAP;
            default -> Material.BOOK;
        };
        inventory.setItem(11, button(card, "&fKarte"));
        inventory.setItem(13, frame % 2 == 0 ? button(card, "&eWird gedreht...") : randomPreview(pool, crate));
        inventory.setItem(15, button(card, "&fKarte"));
    }

    private void renderCrystalCharge(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.PURPLE_STAINED_GLASS_PANE, " ");
        for (int slot : new int[] {4, 10, 12, 14, 16, 22}) {
            inventory.setItem(slot, button(Material.AMETHYST_SHARD, "&dEnergie"));
        }
        inventory.setItem(13, frame % 3 == 0 ? button(Material.END_CRYSTAL, "&d&lCRYSTAL") : randomPreview(pool, crate));
    }

    private void renderRuneCircle(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.BLUE_STAINED_GLASS_PANE, " ");
        int[] runes = {1, 3, 5, 7, 9, 17, 19, 21, 23, 25};
        for (int i = 0; i < runes.length; i++) {
            inventory.setItem(runes[i], button(i == frame % runes.length ? Material.ENCHANTED_BOOK : Material.LAPIS_LAZULI, "&9Rune"));
        }
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderMeteorDrop(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.GRAY_STAINED_GLASS_PANE, " ");
        int rowSlot = Math.min(22, 4 + (frame % 5) * 5);
        inventory.setItem(rowSlot, button(Material.FIRE_CHARGE, "&cMeteor"));
        inventory.setItem(13, randomPreview(pool, crate));
        inventory.setItem(22, button(Material.OBSIDIAN, "&8Einschlag"));
    }

    private void renderGoldRush(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.YELLOW_STAINED_GLASS_PANE, "&6Gold");
        for (int slot : new int[] {3, 5, 11, 15, 21, 23}) {
            inventory.setItem(slot, button(frame % 2 == 0 ? Material.GOLD_INGOT : Material.GOLD_BLOCK, "&6&lGOLD RUSH"));
        }
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderSoulStorm(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.CYAN_STAINED_GLASS_PANE, " ");
        for (int slot : borderSlots()) {
            inventory.setItem(slot, button(frame % 2 == 0 ? Material.SOUL_LANTERN : Material.SOUL_SAND, "&bSoul"));
        }
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderRedstoneOverload(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, frame % 2 == 0 ? Material.RED_STAINED_GLASS_PANE : Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int slot : new int[] {4, 10, 12, 14, 16, 22}) {
            inventory.setItem(slot, button(frame % 2 == 0 ? Material.REDSTONE_BLOCK : Material.REDSTONE, "&c&lOVERLOAD"));
        }
        inventory.setItem(13, randomPreview(pool, crate));
    }

    private void renderCrateShake(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        fill(inventory, Material.GRAY_STAINED_GLASS_PANE, " ");
        int center = switch (frame % 4) {
            case 0 -> 12;
            case 1 -> 14;
            case 2 -> 13;
            default -> 13;
        };
        inventory.setItem(center, button(Material.CHEST, "&6&lSHAKE"));
        inventory.setItem(4, randomPreview(pool, crate));
        inventory.setItem(22, randomPreview(pool, crate));
    }

    private void renderClassicRoll(Inventory inventory, Crate crate, List<Reward> pool, int frame) {
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, randomPreview(pool, crate));
        }
        inventory.setItem(13, frame % 2 == 0 ? button(Material.CHEST, "&6Rollt...") : randomPreview(pool, crate));
    }

    private void fill(Inventory inventory, Material material, String name, String... lore) {
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, button(material, name, lore));
        }
    }

    private int[] borderSlots() {
        return new int[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
    }

    private ItemStack randomPreview(List<Reward> pool, Crate crate) {
        return pool.get(random.nextInt(pool.size())).preview(crate);
    }

    private Material rainbowPane(int frame, int offset) {
        Material[] panes = {
            Material.RED_STAINED_GLASS_PANE,
            Material.ORANGE_STAINED_GLASS_PANE,
            Material.YELLOW_STAINED_GLASS_PANE,
            Material.LIME_STAINED_GLASS_PANE,
            Material.LIGHT_BLUE_STAINED_GLASS_PANE,
            Material.BLUE_STAINED_GLASS_PANE,
            Material.PURPLE_STAINED_GLASS_PANE,
            Material.MAGENTA_STAINED_GLASS_PANE
        };
        return panes[Math.floorMod(frame + offset, panes.length)];
    }

    private int particleCount(Crate crate, int base) {
        return clamp((int) Math.round(base * crate.effectLevel.multiplier), 1, 80);
    }

    private void spawnParticle(World world, String particleName, Location location, int count, double offsetX, double offsetY, double offsetZ, double speed) {
        Particle particle;
        try {
            particle = Particle.valueOf(particleName);
        } catch (IllegalArgumentException exception) {
            particle = Particle.CRIT;
        }
        try {
            world.spawnParticle(particle, location, count, offsetX, offsetY, offsetZ, speed);
        } catch (IllegalArgumentException exception) {
            world.spawnParticle(Particle.CRIT, location, Math.max(1, count / 2), offsetX, offsetY, offsetZ, speed);
        }
    }

    private void playAnimationSound(Player player, Crate crate, boolean finalFrame, int frame) {
        if (finalFrame) {
            playDirect(player, animationFinalSound(crate.animationType), effectVolume(crate), 1.15F);
            return;
        }
        int every = switch (crate.effectLevel) {
            case CALM -> 5;
            case NORMAL -> 3;
            case EPIC -> 2;
        };
        if (frame % every != 0) {
            return;
        }
        playDirect(player, animationTickSound(crate.animationType), effectVolume(crate), animationPitch(crate, frame));
    }

    private String animationTickSound(AnimationType type) {
        return switch (type) {
            case FIREWORK_BURST, RAINBOW_ROLL -> "ENTITY_FIREWORK_ROCKET_BLAST";
            case LIGHTNING_STRIKE, REDSTONE_OVERLOAD -> "BLOCK_NOTE_BLOCK_BIT";
            case DRAGON_SPIN, ENDER_PORTAL, SOUL_STORM -> "BLOCK_PORTAL_AMBIENT";
            case BEACON_BEAM, CRYSTAL_CHARGE -> "BLOCK_AMETHYST_BLOCK_CHIME";
            case TREASURE_CHEST, CRATE_SHAKE -> "BLOCK_CHEST_OPEN";
            case GOLD_RUSH, JACKPOT_BUILDUP -> "ENTITY_EXPERIENCE_ORB_PICKUP";
            case METEOR_DROP -> "ENTITY_BLAZE_SHOOT";
            case COUNTDOWN -> "BLOCK_NOTE_BLOCK_HAT";
            default -> getConfig().getString("sounds.roll", "BLOCK_NOTE_BLOCK_PLING");
        };
    }

    private String animationFinalSound(AnimationType type) {
        return switch (type) {
            case JACKPOT_BUILDUP, GOLD_RUSH -> "UI_TOAST_CHALLENGE_COMPLETE";
            case FIREWORK_BURST, RAINBOW_ROLL -> "ENTITY_FIREWORK_ROCKET_TWINKLE";
            case LIGHTNING_STRIKE -> "ENTITY_LIGHTNING_BOLT_THUNDER";
            case ENDER_PORTAL, DRAGON_SPIN -> "BLOCK_END_PORTAL_SPAWN";
            case BEACON_BEAM, CRYSTAL_CHARGE -> "BLOCK_BEACON_ACTIVATE";
            default -> getConfig().getString("sounds.win", "UI_TOAST_CHALLENGE_COMPLETE");
        };
    }

    private float animationPitch(Crate crate, int frame) {
        return (float) Math.min(1.8D, 0.85D + (frame % 8) * 0.05D + crate.effectLevel.pitchBoost);
    }

    private float effectVolume(Crate crate) {
        return (float) Math.min(1.6D, getConfig().getDouble("sounds.volume", 0.8D) * crate.effectLevel.soundMultiplier);
    }

    private String animationStatus(Crate crate, int frame, boolean finalFrame) {
        if (finalFrame) {
            return "&6&lGEWINN WIRD GELADEN";
        }
        return switch (crate.animationType) {
            case COUNTDOWN -> "&eCOUNTDOWN &f" + Math.max(1, 4 - Math.min(3, frame / 5));
            case JACKPOT_BUILDUP -> "&6&lJACKPOT?";
            case MYSTERY_REVEAL -> "&dMYSTERY REVEAL";
            case FIREWORK_BURST -> "&cFEUERWERK STARTET";
            case LIGHTNING_STRIKE -> "&eBLITZ ENERGIE";
            case DRAGON_SPIN -> "&5DRAGON SPIN";
            case BEACON_BEAM -> "&bBEACON WIRD GELADEN";
            case ENDER_PORTAL -> "&5PORTAL OEFFNET";
            case TREASURE_CHEST -> "&6SCHATZTRUHE OEFFNET";
            case LUCKY_WHEEL -> "&aLUCKY WHEEL";
            case CARD_FLIP -> "&fKARTEN WERDEN GEDECKT";
            case CRYSTAL_CHARGE -> "&dCRYSTAL CHARGE";
            case RUNE_CIRCLE -> "&9RUNEN KREIS";
            case METEOR_DROP -> "&cMETEOR FAELLT";
            case GOLD_RUSH -> "&6GOLD RUSH";
            case SOUL_STORM -> "&bSOUL STORM";
            case REDSTONE_OVERLOAD -> "&cREDSTONE OVERLOAD";
            case CRATE_SHAKE -> "&eCRATE SHAKE";
            default -> "&eROLLT...";
        };
    }

    private void updateDisplayStatus(Crate crate, String status) {
        TextDisplay display = displays.get(crate.id);
        if (display != null && !display.isDead()) {
            display.setText(color(crate.name + "\n" + status + "\n&7Effekt: &e" + crate.effectLevel.label));
        }
    }

    private void resetDisplay(Crate crate) {
        TextDisplay display = displays.get(crate.id);
        if (display != null && !display.isDead()) {
            display.setText(color(crate.displayText()));
        }
    }

    private void finishOpening(Player player, Crate crate, Reward reward, OpenResult result) {
        markOpened(player, crate);
        giveReward(player, crate, reward);
        handlePostReward(player, crate);
    }

    private void giveReward(Player player, Crate crate, Reward reward) {
        if (reward.type == RewardType.ITEM && reward.item != null) {
            player.getInventory().addItem(reward.item.clone());
        } else if (reward.type == RewardType.COMMAND && !reward.command.isBlank()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), replace(reward.command, player));
        } else if (reward.type == RewardType.MONEY && reward.money > 0.0D) {
            if (economy != null) {
                economy.depositPlayer(player, reward.money);
            } else {
                player.sendMessage(color(prefix() + "&cMoney-Reward braucht Vault/RSLBalance."));
            }
        } else if (reward.type == RewardType.MESSAGE && !reward.message.isBlank()) {
            player.sendMessage(color(replace(reward.message, player)));
        }
        if (!reward.permissionGive.isBlank()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + player.getName() + " permission set " + reward.permissionGive + " true");
        }
        if (!reward.permissionTake.isBlank()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + player.getName() + " permission unset " + reward.permissionTake);
        }
        if (reward.xpLevels != 0) {
            player.giveExpLevels(reward.xpLevels);
        }
        if (!reward.sound.isBlank()) {
            playDirect(player, reward.sound);
        }
        if (!reward.broadcast.isBlank()) {
            Bukkit.broadcastMessage(color(replace(reward.broadcast, player)));
        }
        play(player, "sounds.win");
        sendRaw(player, message("won").replace("<reward>", reward.displayName(crate)));
    }

    private void handlePostReward(Player player, Crate crate) {
        if (crate.variant == CrateVariant.JACKPOT && crate.jackpotChancePermille > 0 && random.nextInt(1000) < crate.jackpotChancePermille) {
            if (economy != null && crate.jackpotMoney > 0.0D) {
                economy.depositPlayer(player, crate.jackpotMoney);
            }
            Bukkit.broadcastMessage(color("&6&lJACKPOT! &e" + player.getName() + " &7hat bei &f" + crate.id + " &6" + formatMoney(crate.jackpotMoney) + " Coins &7gewonnen!"));
        }
        if (crate.variant == CrateVariant.STREAK) {
            int streak = updateStreak(player, crate.id);
            if (streak >= crate.streakRequired && economy != null && crate.streakBonusMoney > 0.0D) {
                economy.depositPlayer(player, crate.streakBonusMoney);
                player.sendMessage(color(prefix() + "&6Streak Bonus: &e" + formatMoney(crate.streakBonusMoney) + " &7bei Serie &e" + streak));
            }
        }
    }

    private boolean consumeKey(Player player, String crateId) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack stack = contents[i];
            if (!isKeyFor(stack, crateId)) {
                continue;
            }
            if (stack.getAmount() <= 1) {
                contents[i] = null;
            } else {
                stack.setAmount(stack.getAmount() - 1);
            }
            player.getInventory().setContents(contents);
            return true;
        }
        return false;
    }

    private boolean isKeyFor(ItemStack stack, String crateId) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) {
            return false;
        }
        String stored = stack.getItemMeta().getPersistentDataContainer().get(keyCrateId, PersistentDataType.STRING);
        return crateId.equals(stored);
    }

    private void openAdmin(Player player) {
        AdminHolder holder = new AdminHolder();
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&6&lRSLCrates Admin"));
        holder.inventory = inventory;
        inventory.setItem(10, button(Material.CHEST, "&eCrates verwalten", "&7Alle Crates anzeigen und bearbeiten."));
        inventory.setItem(12, button(Material.LIME_DYE, "&aNeue Crate", "&7Schaue auf einen Block und nutze:", "&e/rslcrates create <id>"));
        inventory.setItem(14, button(Material.NETHER_STAR, "&6Vorlagen", "&7Erst eine Crate bearbeiten,", "&7dann Vorlage anwenden."));
        inventory.setItem(16, button(Material.EMERALD, "&aSave/Reload", "&7Linksklick speichert.", "&7Rechtsklick geht per /rslcrates reload."));
        player.openInventory(inventory);
    }

    private void handleAdminClick(Player player, int rawSlot) {
        if (rawSlot == 10) {
            openCrateList(player, 0);
        } else if (rawSlot == 12) {
            player.closeInventory();
            player.sendMessage(color(prefix() + "&eSchaue auf einen Block und schreibe &f/rslcrates create <id>&e."));
        } else if (rawSlot == 16) {
            saveCrates();
            send(player, "saved");
            openAdmin(player);
        }
    }

    private void openCrateList(Player player, int page) {
        CrateListHolder holder = new CrateListHolder(page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Crates"));
        holder.inventory = inventory;
        List<Crate> values = crates.values().stream().sorted(Comparator.comparing(crate -> crate.id)).collect(Collectors.toList());
        int maxPage = Math.max(0, (values.size() - 1) / 45);
        int safePage = clamp(page, 0, maxPage);
        holder.page = safePage;
        int start = safePage * 45;
        for (int i = 0; i < 45 && start + i < values.size(); i++) {
            Crate crate = values.get(start + i);
            boolean duplicate = duplicateLocationIds().contains(crate.id);
            inventory.setItem(i, button(crate.blockType, crate.name,
                "&7ID: &e" + crate.id,
                "&7Preis: &e" + formatMoney(crate.price),
                "&7Rewards: &e" + crate.rewards.size(),
                duplicate ? "&cKonflikt: Position doppelt belegt" : "&aPosition frei",
                "&7Linksklick: bearbeiten",
                "&7Rechtsklick: loeschen"));
        }
        inventory.setItem(45, button(Material.ARROW, "&eVorherige Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        inventory.setItem(49, button(Material.BARRIER, "&cZurueck", "&7Zum Admin-Dashboard."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handleCrateListClick(Player player, int page, int rawSlot, ClickType click) {
        if (rawSlot == 45) {
            openCrateList(player, page - 1);
            return;
        }
        if (rawSlot == 49) {
            openAdmin(player);
            return;
        }
        if (rawSlot == 53) {
            openCrateList(player, page + 1);
            return;
        }
        List<Crate> values = crates.values().stream().sorted(Comparator.comparing(crate -> crate.id)).collect(Collectors.toList());
        int index = page * 45 + rawSlot;
        if (rawSlot >= 0 && rawSlot < 45 && index >= 0 && index < values.size()) {
            Crate crate = values.get(index);
            if (click.isRightClick()) {
                openConfirm(player, ConfirmType.DELETE_CRATE, crate.id, "&cCrate loeschen?", "&7Crate: &e" + crate.id);
            } else {
                openCrateEditor(player, crate.id);
            }
        }
    }

    private void openCrateEditor(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            sendRaw(player, message("crate-not-found").replace("<crate>", crateId));
            return;
        }
        CrateEditorHolder holder = new CrateEditorHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Crate Editor &8- &e" + crateId));
        holder.inventory = inventory;
        inventory.setItem(4, button(crate.blockType, crate.name,
            "&7ID: &e" + crate.id,
            "&7Variante: &e" + crate.variant.label,
            "&7Animation: &e" + crate.animationType.label,
            "&7Effekt: &e" + crate.effectLevel.label,
            "&7Preis ohne Key: &e" + formatMoney(crate.price),
            "&7Rewards: &e" + crate.rewards.size(),
            duplicateLocationIds().contains(crate.id) ? "&cKonflikt: Position doppelt belegt" : "&aPosition frei"));
        inventory.setItem(10, button(Material.NAME_TAG, "&eName schreiben", "&7Freier Text per Chat.", "&7Aktuell: &f" + crate.name));
        inventory.setItem(18, button(Material.PAINTING, "&6Name Design", "&7Farben, Hex, Gradient und Font-Presets."));
        inventory.setItem(11, button(Material.REDSTONE, "&cPreis -100", "&7Aktuell: &e" + formatMoney(crate.price)));
        inventory.setItem(12, button(Material.REDSTONE_TORCH, "&cPreis -10", "&7Aktuell: &e" + formatMoney(crate.price)));
        inventory.setItem(13, button(Material.GOLD_INGOT, "&6Preis ohne Key", "&7Spieler zahlen diesen Betrag,", "&7wenn sie keinen Key haben.", "&e" + formatMoney(crate.price)));
        inventory.setItem(14, button(Material.EMERALD, "&aPreis +10", "&7Aktuell: &e" + formatMoney(crate.price)));
        inventory.setItem(15, button(Material.EMERALD_BLOCK, "&aPreis +100", "&7Aktuell: &e" + formatMoney(crate.price)));
        inventory.setItem(16, crate.keyItem(1, keyCrateId));
        inventory.setItem(19, button(Material.TRIPWIRE_HOOK, "&eKey aus Hand setzen", "&7Nimmt Material, Name und Lore aus deiner Hand."));
        inventory.setItem(20, button(Material.CHEST, "&dRewards", "&7Rewards und Chancen bearbeiten."));
        inventory.setItem(21, button(Material.OAK_SIGN, "&bTextDisplay", "&7Aktuell: &e" + crate.textDisplay, "&7Klick schaltet um."));
        inventory.setItem(22, button(Material.NOTE_BLOCK, "&6Animation", "&7Typ per GUI waehlen.", "&7Aktuell: &e" + crate.animationType.label));
        inventory.setItem(23, button(Material.NETHER_STAR, "&6Vorlagen", "&7Vote, Daily, Epic, Legendary, Event."));
        inventory.setItem(24, button(Material.COMPASS, "&eBlock neu setzen", "&7Schaue auf neuen Block und klicke."));
        inventory.setItem(25, button(Material.DROPPER, "&aKey geben", "&7Gibt dir einen Test-Key."));
        inventory.setItem(28, button(Material.ENDER_CHEST, "&6Crate-Variante", "&7KEY, PAID, FREE, TIMED,", "&7MYSTERY, EVENT, VIP, JACKPOT,", "&7STREAK, LEVEL...", "&7Aktuell: &e" + crate.variant.label));
        inventory.setItem(29, button(Material.CLOCK, "&bTiming", "&7Cooldown, Roll-Dauer,", "&7Tick-Speed, Final-Delay,", "&7Event-Zeit per GUI."));
        inventory.setItem(30, button(Material.IRON_DOOR, "&cRequirements", "&7VIP-Permission und Mindest-Level.", "&7Permission: &e" + blankDash(crate.vipPermission), "&7Level: &e" + crate.minLevel));
        inventory.setItem(31, button(Material.NETHER_STAR, "&6Jackpot/Streak", "&7Jackpot-Chance, Bonus-Geld,", "&7Streak-Limit und Streak-Bonus."));
        inventory.setItem(32, button(crate.effectLevel.icon, "&dEffekt-Staerke", "&7Partikel, Sounds und Reveal-Wucht.", "&7Aktuell: &e" + crate.effectLevel.label));
        inventory.setItem(45, button(Material.ARROW, "&eZurueck", "&7Zur Crate-Liste."));
        inventory.setItem(53, button(Material.BARRIER, "&cCrate loeschen", "&7Mit Bestaetigung loeschen."));
        inventory.setItem(49, button(Material.EMERALD, "&aSpeichern", "&7Speichert crates.yml und aktualisiert Displays."));
        player.openInventory(inventory);
    }

    private void handleCrateEditorClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 10) {
            beginInput(player, new PendingInput(InputType.CRATE_NAME, crateId, ""), "&eNeuen Crate-Namen eingeben. &7Farbcodes mit &.");
        } else if (rawSlot == 11) {
            crate.price = Math.max(0.0D, crate.price - 100.0D);
            saveCrates();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 12) {
            crate.price = Math.max(0.0D, crate.price - 10.0D);
            saveCrates();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 14) {
            crate.price += 10.0D;
            saveCrates();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 15) {
            crate.price += 100.0D;
            saveCrates();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 18) {
            openTextDesign(player, crateId);
        } else if (rawSlot == 19) {
            setKeyFromHand(player, crate);
            openCrateEditor(player, crateId);
        } else if (rawSlot == 20) {
            openRewardList(player, crateId, 0);
        } else if (rawSlot == 21) {
            crate.textDisplay = !crate.textDisplay;
            saveCrates();
            refreshDisplays();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 22) {
            openAnimationPicker(player, crateId);
        } else if (rawSlot == 23) {
            openTemplates(player, crateId);
        } else if (rawSlot == 24) {
            Block block = player.getTargetBlockExact(8);
            if (block == null || block.getType().isAir()) {
                send(player, "no-target-block");
                return;
            }
            Optional<Crate> existing = crateAtExcept(block.getLocation(), crateId);
            if (existing.isPresent()) {
                sendRaw(player, "&cAuf diesem Block liegt schon die Crate &e" + existing.get().id + "&c.");
                openCrateEditor(player, crateId);
                return;
            }
            crate.location = block.getLocation();
            crate.blockType = block.getType();
            saveCrates();
            refreshDisplays();
            openCrateEditor(player, crateId);
        } else if (rawSlot == 25) {
            player.getInventory().addItem(crate.keyItem(1, keyCrateId));
            openCrateEditor(player, crateId);
        } else if (rawSlot == 28) {
            openVariantPicker(player, crateId);
        } else if (rawSlot == 29) {
            openTimingEditor(player, crateId);
        } else if (rawSlot == 30) {
            openRequirementEditor(player, crateId);
        } else if (rawSlot == 31) {
            openJackpotEditor(player, crateId);
        } else if (rawSlot == 32) {
            openEffectLevelPicker(player, crateId);
        } else if (rawSlot == 45) {
            openCrateList(player, 0);
        } else if (rawSlot == 49) {
            saveCrates();
            refreshDisplays();
            send(player, "saved");
            openCrateEditor(player, crateId);
        } else if (rawSlot == 53) {
            openConfirm(player, ConfirmType.DELETE_CRATE, crateId, "&cCrate loeschen?", "&7Crate: &e" + crateId);
        }
    }

    private void openVariantPicker(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        VariantHolder holder = new VariantHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&6Crate-Variante"));
        holder.inventory = inventory;
        CrateVariant[] variants = CrateVariant.values();
        for (int i = 0; i < Math.min(18, variants.length); i++) {
            CrateVariant variant = variants[i];
            inventory.setItem(i, button(variant.icon, variant.label, variant == crate.variant ? "&aAktiv" : "&7Klick zum Setzen.", "&8" + variant.name()));
        }
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleVariantClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 22) {
            openCrateEditor(player, crateId);
            return;
        }
        CrateVariant[] variants = CrateVariant.values();
        if (rawSlot >= 0 && rawSlot < variants.length) {
            crate.variant = variants[rawSlot];
            if (crate.variant == CrateVariant.JACKPOT && crate.animationType == AnimationType.CLASSIC_ROLL) {
                crate.animationType = AnimationType.JACKPOT_BUILDUP;
            } else if (crate.variant == CrateVariant.MYSTERY) {
                crate.animationType = AnimationType.MYSTERY_REVEAL;
            }
            saveCrates();
            refreshDisplays();
            openVariantPicker(player, crateId);
        }
    }

    private void openAnimationPicker(Player player, String crateId) {
        openAnimationPicker(player, crateId, 0);
    }

    private void openAnimationPicker(Player player, String crateId, int page) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        AnimationType[] types = AnimationType.values();
        int maxPage = Math.max(0, (types.length - 1) / 45);
        int safePage = clamp(page, 0, maxPage);
        AnimationHolder holder = new AnimationHolder(crateId, safePage);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Animation waehlen"));
        holder.inventory = inventory;
        int start = safePage * 45;
        for (int i = 0; i < 45 && start + i < types.length; i++) {
            AnimationType type = types[start + i];
            inventory.setItem(i, button(type.icon, type.label, type == crate.animationType ? "&aAktiv" : "&7Klick zum Setzen.", "&8" + type.name()));
        }
        inventory.setItem(45, button(Material.ARROW, "&eVorherige Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        inventory.setItem(49, button(Material.BARRIER, "&eZurueck", "&7Zum Crate-Editor."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handleAnimationClick(Player player, String crateId, int page, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        AnimationType[] types = AnimationType.values();
        int maxPage = Math.max(0, (types.length - 1) / 45);
        if (rawSlot == 45) {
            openAnimationPicker(player, crateId, page - 1);
            return;
        }
        if (rawSlot == 49) {
            openCrateEditor(player, crateId);
            return;
        }
        if (rawSlot == 53) {
            openAnimationPicker(player, crateId, page + 1);
            return;
        }
        int index = page * 45 + rawSlot;
        if (rawSlot >= 0 && rawSlot < 45 && index < types.length) {
            crate.animationType = types[index];
            crate.animation = crate.animationType != AnimationType.NONE;
            saveCrates();
            refreshDisplays();
            openAnimationPicker(player, crateId, clamp(page, 0, maxPage));
        }
    }

    private void openEffectLevelPicker(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        EffectLevelHolder holder = new EffectLevelHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&dEffekt-Staerke"));
        holder.inventory = inventory;
        EffectLevel[] levels = EffectLevel.values();
        for (int i = 0; i < levels.length; i++) {
            EffectLevel level = levels[i];
            inventory.setItem(11 + i * 2, button(level.icon, level.label, level == crate.effectLevel ? "&aAktiv" : "&7Klick zum Setzen.", "&7Partikel: &e" + Math.round(level.multiplier * 100.0D) + "%"));
        }
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleEffectLevelClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 22) {
            openCrateEditor(player, crateId);
            return;
        }
        EffectLevel[] levels = EffectLevel.values();
        for (int i = 0; i < levels.length; i++) {
            if (rawSlot == 11 + i * 2) {
                crate.effectLevel = levels[i];
                saveCrates();
                refreshDisplays();
                openEffectLevelPicker(player, crateId);
                return;
            }
        }
    }

    private void openTimingEditor(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        TimingHolder holder = new TimingHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&bTiming &8- &e" + crateId));
        holder.inventory = inventory;
        inventory.setItem(4, button(Material.CLOCK, "&bTiming", "&7Cooldown: &e" + formatDuration(crate.cooldownSeconds * 1000L), "&7Roll: &e" + crate.rollTicks + " ticks", "&7Speed: &e" + crate.rollIntervalTicks + " ticks", "&7Final: &e" + crate.finalDelayTicks + " ticks", "&7Event: &e" + crate.eventText()));
        inventory.setItem(10, button(Material.REDSTONE_BLOCK, "&cCooldown -1h"));
        inventory.setItem(11, button(Material.REDSTONE, "&cCooldown -5m"));
        inventory.setItem(12, button(Material.EMERALD, "&aCooldown +5m"));
        inventory.setItem(13, button(Material.EMERALD_BLOCK, "&aCooldown +1h"));
        inventory.setItem(19, button(Material.REDSTONE, "&cRoll -10 ticks"));
        inventory.setItem(20, button(Material.EMERALD, "&aRoll +10 ticks"));
        inventory.setItem(21, button(Material.REDSTONE_TORCH, "&cSpeed -1"));
        inventory.setItem(22, button(Material.TORCH, "&aSpeed +1"));
        inventory.setItem(23, button(Material.REDSTONE_TORCH, "&cFinal -5"));
        inventory.setItem(24, button(Material.TORCH, "&aFinal +5"));
        inventory.setItem(28, button(Material.LIME_DYE, "&aEvent Start jetzt", "&7Setzt Start auf jetzt."));
        inventory.setItem(29, button(Material.CLOCK, "&eEvent Ende +1h", "&7Setzt Ende auf jetzt + 1 Stunde."));
        inventory.setItem(30, button(Material.CLOCK, "&eEvent Ende +24h", "&7Setzt Ende auf jetzt + 24 Stunden."));
        inventory.setItem(31, button(Material.BARRIER, "&cEvent loeschen"));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleTimingClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        long now = System.currentTimeMillis() / 1000L;
        if (rawSlot == 10) {
            crate.cooldownSeconds = Math.max(0L, crate.cooldownSeconds - 3600L);
        } else if (rawSlot == 11) {
            crate.cooldownSeconds = Math.max(0L, crate.cooldownSeconds - 300L);
        } else if (rawSlot == 12) {
            crate.cooldownSeconds += 300L;
        } else if (rawSlot == 13) {
            crate.cooldownSeconds += 3600L;
        } else if (rawSlot == 19) {
            crate.rollTicks = Math.max(10L, crate.rollTicks - 10L);
        } else if (rawSlot == 20) {
            crate.rollTicks = Math.min(240L, crate.rollTicks + 10L);
        } else if (rawSlot == 21) {
            crate.rollIntervalTicks = Math.max(1L, crate.rollIntervalTicks - 1L);
        } else if (rawSlot == 22) {
            crate.rollIntervalTicks = Math.min(20L, crate.rollIntervalTicks + 1L);
        } else if (rawSlot == 23) {
            crate.finalDelayTicks = Math.max(1L, crate.finalDelayTicks - 5L);
        } else if (rawSlot == 24) {
            crate.finalDelayTicks = Math.min(100L, crate.finalDelayTicks + 5L);
        } else if (rawSlot == 28) {
            crate.eventStartEpochSeconds = now;
            if (crate.eventEndEpochSeconds <= now) {
                crate.eventEndEpochSeconds = now + 3600L;
            }
        } else if (rawSlot == 29) {
            crate.eventEndEpochSeconds = now + 3600L;
        } else if (rawSlot == 30) {
            crate.eventEndEpochSeconds = now + 86400L;
        } else if (rawSlot == 31) {
            crate.eventStartEpochSeconds = 0L;
            crate.eventEndEpochSeconds = 0L;
        } else if (rawSlot == 49) {
            openCrateEditor(player, crateId);
            return;
        } else {
            return;
        }
        saveCrates();
        refreshDisplays();
        openTimingEditor(player, crateId);
    }

    private void openRequirementEditor(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        RequirementHolder holder = new RequirementHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&cRequirements"));
        holder.inventory = inventory;
        inventory.setItem(4, button(Material.IRON_DOOR, "&cRequirements", "&7Permission: &e" + blankDash(crate.vipPermission), "&7Mindest-Level: &e" + crate.minLevel));
        inventory.setItem(10, button(Material.NAME_TAG, "&eVIP-Permission setzen", "&7Freier Text per Chat."));
        inventory.setItem(11, button(Material.BARRIER, "&cPermission loeschen"));
        inventory.setItem(13, button(Material.REDSTONE, "&cLevel -1", "&7Aktuell: &e" + crate.minLevel));
        inventory.setItem(15, button(Material.EMERALD, "&aLevel +1", "&7Aktuell: &e" + crate.minLevel));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleRequirementClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 10) {
            beginInput(player, new PendingInput(InputType.CRATE_PERMISSION, crateId, ""), "&ePermission eingeben, z. B. &frslcrates.vip");
            return;
        }
        if (rawSlot == 11) {
            crate.vipPermission = "";
        } else if (rawSlot == 13) {
            crate.minLevel = Math.max(0, crate.minLevel - 1);
        } else if (rawSlot == 15) {
            crate.minLevel = Math.min(1000, crate.minLevel + 1);
        } else if (rawSlot == 22) {
            openCrateEditor(player, crateId);
            return;
        } else {
            return;
        }
        saveCrates();
        refreshDisplays();
        openRequirementEditor(player, crateId);
    }

    private void openJackpotEditor(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        JackpotHolder holder = new JackpotHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Jackpot & Streak"));
        holder.inventory = inventory;
        inventory.setItem(4, button(Material.NETHER_STAR, "&6Jackpot/Streak", "&7Jackpot: &e" + String.format(Locale.US, "%.1f%%", crate.jackpotChancePermille / 10.0D), "&7Jackpot-Geld: &e" + formatMoney(crate.jackpotMoney), "&7Streak benoetigt: &e" + crate.streakRequired, "&7Streak-Bonus: &e" + formatMoney(crate.streakBonusMoney)));
        inventory.setItem(10, button(Material.REDSTONE, "&cJackpot -1%"));
        inventory.setItem(11, button(Material.EMERALD, "&aJackpot +1%"));
        inventory.setItem(12, button(Material.REDSTONE_BLOCK, "&cJackpot Geld -100"));
        inventory.setItem(13, button(Material.EMERALD_BLOCK, "&aJackpot Geld +100"));
        inventory.setItem(19, button(Material.REDSTONE, "&cStreak -1"));
        inventory.setItem(20, button(Material.EMERALD, "&aStreak +1"));
        inventory.setItem(21, button(Material.REDSTONE_BLOCK, "&cStreak Bonus -100"));
        inventory.setItem(22, button(Material.EMERALD_BLOCK, "&aStreak Bonus +100"));
        inventory.setItem(31, button(Material.BARRIER, "&cReset"));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleJackpotClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 10) {
            crate.jackpotChancePermille = Math.max(0, crate.jackpotChancePermille - 10);
        } else if (rawSlot == 11) {
            crate.jackpotChancePermille = Math.min(1000, crate.jackpotChancePermille + 10);
        } else if (rawSlot == 12) {
            crate.jackpotMoney = Math.max(0.0D, crate.jackpotMoney - 100.0D);
        } else if (rawSlot == 13) {
            crate.jackpotMoney += 100.0D;
        } else if (rawSlot == 19) {
            crate.streakRequired = Math.max(1, crate.streakRequired - 1);
        } else if (rawSlot == 20) {
            crate.streakRequired += 1;
        } else if (rawSlot == 21) {
            crate.streakBonusMoney = Math.max(0.0D, crate.streakBonusMoney - 100.0D);
        } else if (rawSlot == 22) {
            crate.streakBonusMoney += 100.0D;
        } else if (rawSlot == 31) {
            crate.jackpotChancePermille = 50;
            crate.jackpotMoney = 1000.0D;
            crate.streakRequired = 3;
            crate.streakBonusMoney = 500.0D;
        } else if (rawSlot == 49) {
            openCrateEditor(player, crateId);
            return;
        } else {
            return;
        }
        saveCrates();
        refreshDisplays();
        openJackpotEditor(player, crateId);
    }

    private void openConfirm(Player player, ConfirmType type, String crateId, String title, String... lore) {
        ConfirmHolder holder = new ConfirmHolder(type, crateId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color(title));
        holder.inventory = inventory;
        inventory.setItem(11, button(Material.LIME_CONCRETE, "&aBestaetigen", lore));
        inventory.setItem(15, button(Material.RED_CONCRETE, "&cAbbrechen", "&7Zurueck ohne Aenderung."));
        player.openInventory(inventory);
    }

    private void handleConfirmClick(Player player, ConfirmHolder holder, int rawSlot) {
        if (rawSlot == 11 && holder.type == ConfirmType.DELETE_CRATE) {
            deleteCrate(holder.crateId);
            sendRaw(player, "&aCrate &e" + holder.crateId + " &awurde geloescht.");
            openCrateList(player, 0);
            return;
        }
        if (rawSlot == 15) {
            if (crates.containsKey(holder.crateId)) {
                openCrateEditor(player, holder.crateId);
            } else {
                openCrateList(player, 0);
            }
        }
    }

    private void openTextDesign(Player player, String crateId) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        TextDesignHolder holder = new TextDesignHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&6Crate Name Design"));
        holder.inventory = inventory;
        inventory.setItem(4, button(Material.NAME_TAG, crate.name, "&7Aktueller Name", "&7Roh: &f" + crate.name));
        String[] colors = {"&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", "&8", "&9", "&a", "&b", "&c", "&d", "&e", "&f"};
        Material[] colorMaterials = {
            Material.BLACK_CONCRETE, Material.BLUE_CONCRETE, Material.GREEN_CONCRETE, Material.CYAN_CONCRETE,
            Material.RED_CONCRETE, Material.PURPLE_CONCRETE, Material.ORANGE_CONCRETE, Material.LIGHT_GRAY_CONCRETE,
            Material.GRAY_CONCRETE, Material.LIGHT_BLUE_CONCRETE, Material.LIME_CONCRETE, Material.LIGHT_BLUE_STAINED_GLASS,
            Material.RED_STAINED_GLASS, Material.MAGENTA_CONCRETE, Material.YELLOW_CONCRETE, Material.WHITE_CONCRETE
        };
        for (int i = 0; i < colors.length; i++) {
            inventory.setItem(9 + i, button(colorMaterials[i], colors[i] + "Farbe " + colors[i], "&7Klick setzt diese Farbe."));
        }
        inventory.setItem(27, button(Material.GOLD_INGOT, "&lFett", "&7Fuegt &f&lBold&7 hinzu."));
        inventory.setItem(28, button(Material.FEATHER, "&oKursiv", "&7Fuegt &f&oKursiv&7 hinzu."));
        inventory.setItem(29, button(Material.STRING, "&nUnterstrichen", "&7Fuegt &f&nUnterstrichen&7 hinzu."));
        inventory.setItem(30, button(Material.IRON_BARS, "&mDurchgestrichen", "&7Fuegt &f&mDurchgestrichen&7 hinzu."));
        inventory.setItem(31, button(Material.BARRIER, "&cReset", "&7Entfernt fuehrende Codes."));

        FontPreset[] presets = FontPreset.values();
        for (int i = 0; i < Math.min(9, presets.length); i++) {
            FontPreset preset = presets[i];
            inventory.setItem(36 + i, button(preset.icon, preset.label, "&7Klick wendet diesen Generator an."));
        }
        inventory.setItem(48, button(Material.NAME_TAG, "&eName schreiben", "&7Freien Namen per Chat eingeben."));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleTextDesignClick(Player player, String crateId, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        String[] colors = {"&0", "&1", "&2", "&3", "&4", "&5", "&6", "&7", "&8", "&9", "&a", "&b", "&c", "&d", "&e", "&f"};
        if (rawSlot >= 9 && rawSlot < 25) {
            crate.name = applyNameColor(crate.name, colors[rawSlot - 9]);
        } else if (rawSlot == 27) {
            crate.name = applyNameStyle(crate.name, "&l");
        } else if (rawSlot == 28) {
            crate.name = applyNameStyle(crate.name, "&o");
        } else if (rawSlot == 29) {
            crate.name = applyNameStyle(crate.name, "&n");
        } else if (rawSlot == 30) {
            crate.name = applyNameStyle(crate.name, "&m");
        } else if (rawSlot == 31) {
            crate.name = stripLeadingFormatting(crate.name);
        } else if (rawSlot >= 36 && rawSlot < 45) {
            FontPreset[] presets = FontPreset.values();
            int index = rawSlot - 36;
            if (index < presets.length) {
                crate.name = applyFontPreset(crate.name, presets[index]);
            }
        } else if (rawSlot == 48) {
            beginInput(player, new PendingInput(InputType.CRATE_NAME, crateId, ""), "&eNeuen Crate-Namen eingeben. &7Farbcodes mit &.");
            return;
        } else if (rawSlot == 49) {
            openCrateEditor(player, crateId);
            return;
        } else {
            return;
        }
        saveCrates();
        refreshDisplays();
        openTextDesign(player, crateId);
    }

    private void deleteCrate(String crateId) {
        TextDisplay display = displays.remove(crateId);
        if (display != null && !display.isDead()) {
            display.remove();
        }
        crates.remove(crateId);
        if (dataConfig != null) {
            ConfigurationSection players = dataConfig.getConfigurationSection("players");
            if (players != null) {
                for (String playerId : players.getKeys(false)) {
                    dataConfig.set("players." + playerId + ".crates." + crateId, null);
                }
                savePlayerData();
            }
        }
        saveCrates();
        refreshDisplays();
    }

    private void setKeyFromHand(Player player, Crate crate) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            player.sendMessage(color(prefix() + "&cHalte ein Key-Item in der Hand."));
            return;
        }
        crate.keyTemplate = hand.clone();
        crate.keyTemplate.setAmount(1);
        markKey(crate.keyTemplate, crate.id);
        saveCrates();
    }

    private void openRewardList(Player player, String crateId, int page) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        RewardListHolder holder = new RewardListHolder(crateId, page);
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&dRewards &8- &e" + crateId));
        holder.inventory = inventory;
        int maxPage = Math.max(0, (crate.rewards.size() - 1) / 45);
        int safePage = clamp(page, 0, maxPage);
        holder.page = safePage;
        int start = safePage * 45;
        int total = crate.totalWeight();
        for (int i = 0; i < 45 && start + i < crate.rewards.size(); i++) {
            Reward reward = crate.rewards.get(start + i);
            inventory.setItem(i, reward.previewWithChance(crate, total));
        }
        inventory.setItem(45, button(Material.DIAMOND, "&aItem-Reward aus Hand", "&7Nimmt dein Hand-Item als Reward."));
        inventory.setItem(46, button(Material.COMMAND_BLOCK, "&cCommand-Reward", "&7Command per Chat eingeben.", "&7Platzhalter: <player>"));
        inventory.setItem(47, button(Material.GOLD_INGOT, "&6Money-Reward", "&7Betrag per Chat eingeben."));
        inventory.setItem(48, button(Material.PAPER, "&eMessage-Reward", "&7Nachricht per Chat eingeben."));
        inventory.setItem(49, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        inventory.setItem(53, button(Material.ARROW, "&eNaechste Seite", "&7Seite: &e" + (safePage + 1) + "/" + (maxPage + 1)));
        player.openInventory(inventory);
    }

    private void handleRewardListClick(Player player, String crateId, int page, int rawSlot) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            openCrateList(player, 0);
            return;
        }
        int index = page * 45 + rawSlot;
        if (rawSlot >= 0 && rawSlot < 45 && index < crate.rewards.size()) {
            openRewardEditor(player, crateId, crate.rewards.get(index).id);
            return;
        }
        if (rawSlot == 45) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand == null || hand.getType().isAir()) {
                player.sendMessage(color(prefix() + "&cHalte ein Item in der Hand."));
                return;
            }
            Reward reward = Reward.item(uniqueRewardId(crate), hand.clone());
            crate.rewards.add(reward);
            saveCrates();
            send(player, "reward-added");
            openRewardList(player, crateId, page);
        } else if (rawSlot == 46) {
            beginInput(player, new PendingInput(InputType.REWARD_COMMAND, crateId, ""), "&eCommand eingeben. &7Ohne /, Platzhalter: &f<player>");
        } else if (rawSlot == 47) {
            beginInput(player, new PendingInput(InputType.REWARD_MONEY, crateId, ""), "&eMoney-Betrag eingeben.");
        } else if (rawSlot == 48) {
            beginInput(player, new PendingInput(InputType.REWARD_MESSAGE, crateId, ""), "&eNachricht eingeben. &7Farbcodes mit &.");
        } else if (rawSlot == 49) {
            openCrateEditor(player, crateId);
        } else if (rawSlot == 53) {
            openRewardList(player, crateId, page + 1);
        }
    }

    private void openRewardEditor(Player player, String crateId, String rewardId) {
        Crate crate = crates.get(crateId);
        Reward reward = crate == null ? null : crate.reward(rewardId);
        if (crate == null || reward == null) {
            openRewardList(player, crateId, 0);
            return;
        }
        RewardEditorHolder holder = new RewardEditorHolder(crateId, rewardId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&dReward Editor"));
        holder.inventory = inventory;
        inventory.setItem(4, reward.previewWithChance(crate, crate.totalWeight()));
        inventory.setItem(10, button(Material.REDSTONE, "&cGewicht -10", "&7Aktuell: &e" + reward.weight));
        inventory.setItem(11, button(Material.REDSTONE_TORCH, "&cGewicht -1", "&7Aktuell: &e" + reward.weight));
        inventory.setItem(12, button(Material.IRON_DOOR, "&cPermission nehmen", "&7Freier Text per Chat.", "&7Aktuell: &e" + blankDash(reward.permissionTake)));
        inventory.setItem(13, button(Material.PAPER, "&eChance", "&7Gewicht: &e" + reward.weight, "&7Chance: &e" + crate.chanceText(reward)));
        inventory.setItem(15, button(Material.EMERALD, "&aGewicht +1", "&7Aktuell: &e" + reward.weight));
        inventory.setItem(16, button(Material.EMERALD_BLOCK, "&aGewicht +10", "&7Aktuell: &e" + reward.weight));
        inventory.setItem(18, button(Material.DIAMOND, "&aItem aus Hand", "&7Setzt/ersetzt das Item dieses Rewards."));
        inventory.setItem(19, button(Material.COMMAND_BLOCK, "&cCommand setzen", "&7Freier Text per Chat."));
        inventory.setItem(20, button(Material.GOLD_INGOT, "&6Money setzen", "&7Betrag per Chat."));
        inventory.setItem(21, button(Material.BARRIER, "&cLoeschen", "&7Entfernt diesen Reward."));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zur Reward-Liste."));
        inventory.setItem(23, button(Material.EXPERIENCE_BOTTLE, "&bXP-Level +1", "&7Aktuell: &e" + reward.xpLevels));
        inventory.setItem(24, button(Material.REDSTONE, "&cXP-Level -1", "&7Aktuell: &e" + reward.xpLevels));
        inventory.setItem(25, button(Material.NOTE_BLOCK, "&dSound wechseln", "&7Aktuell: &e" + blankDash(reward.sound)));
        inventory.setItem(26, button(Material.BOOK, "&eMehr Funktionen", "&7Linksklick: Permission geben", "&7Rechtsklick leider nicht im Plan,", "&7nutze Buttons/Chat: Broadcast folgt ueber Slot 17."));
        inventory.setItem(17, button(Material.PAPER, "&eBroadcast setzen", "&7Freier Text per Chat."));
        player.openInventory(inventory);
    }

    private void handleRewardEditorClick(Player player, String crateId, String rewardId, int rawSlot) {
        Crate crate = crates.get(crateId);
        Reward reward = crate == null ? null : crate.reward(rewardId);
        if (crate == null || reward == null) {
            openRewardList(player, crateId, 0);
            return;
        }
        if (rawSlot == 10) {
            reward.weight = Math.max(1, reward.weight - 10);
        } else if (rawSlot == 11) {
            reward.weight = Math.max(1, reward.weight - 1);
        } else if (rawSlot == 12) {
            beginInput(player, new PendingInput(InputType.REWARD_PERMISSION_TAKE, crateId, rewardId), "&ePermission zum Entfernen eingeben.");
            return;
        } else if (rawSlot == 15) {
            reward.weight += 1;
        } else if (rawSlot == 16) {
            reward.weight += 10;
        } else if (rawSlot == 17) {
            beginInput(player, new PendingInput(InputType.REWARD_BROADCAST, crateId, rewardId), "&eBroadcast-Text eingeben. &7Platzhalter: &f<player>");
            return;
        } else if (rawSlot == 18) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (hand == null || hand.getType().isAir()) {
                player.sendMessage(color(prefix() + "&cHalte ein Item in der Hand."));
                return;
            }
            reward.type = RewardType.ITEM;
            reward.item = hand.clone();
        } else if (rawSlot == 19) {
            beginInput(player, new PendingInput(InputType.REWARD_SET_COMMAND, crateId, rewardId), "&eCommand eingeben. &7Ohne /, Platzhalter: &f<player>");
            return;
        } else if (rawSlot == 20) {
            beginInput(player, new PendingInput(InputType.REWARD_SET_MONEY, crateId, rewardId), "&eMoney-Betrag eingeben.");
            return;
        } else if (rawSlot == 21) {
            crate.rewards.removeIf(existing -> existing.id.equals(rewardId));
            saveCrates();
            openRewardList(player, crateId, 0);
            return;
        } else if (rawSlot == 22) {
            openRewardList(player, crateId, 0);
            return;
        } else if (rawSlot == 23) {
            reward.xpLevels = Math.min(1000, reward.xpLevels + 1);
        } else if (rawSlot == 24) {
            reward.xpLevels = Math.max(-1000, reward.xpLevels - 1);
        } else if (rawSlot == 25) {
            reward.sound = nextRewardSound(reward.sound);
        } else if (rawSlot == 26) {
            beginInput(player, new PendingInput(InputType.REWARD_PERMISSION_GIVE, crateId, rewardId), "&ePermission zum Geben eingeben.");
            return;
        } else {
            return;
        }
        saveCrates();
        openRewardEditor(player, crateId, rewardId);
    }

    private void openTemplates(Player player, String crateId) {
        TemplateHolder holder = new TemplateHolder(crateId);
        Inventory inventory = Bukkit.createInventory(holder, 27, color("&6Crate Vorlagen"));
        holder.inventory = inventory;
        inventory.setItem(10, button(Material.TRIPWIRE_HOOK, "&aVote", "&7Einfach, guenstig, viele kleine Gewinne."));
        inventory.setItem(11, button(Material.CLOCK, "&bDaily", "&7Taegliche Crate mit nuetzlichen Items."));
        inventory.setItem(12, button(Material.AMETHYST_SHARD, "&dEpic", "&7Staerkere Rewards."));
        inventory.setItem(13, button(Material.NETHER_STAR, "&6Legendary", "&7Sehr wertvolle Rewards."));
        inventory.setItem(14, button(Material.FIREWORK_ROCKET, "&cEvent", "&7Bunte Event-Crate."));
        inventory.setItem(22, button(Material.ARROW, "&eZurueck", "&7Zum Crate-Editor."));
        player.openInventory(inventory);
    }

    private void handleTemplateClick(Player player, String crateId, int rawSlot) {
        if (rawSlot == 22) {
            openCrateEditor(player, crateId);
            return;
        }
        String template = switch (rawSlot) {
            case 10 -> "vote";
            case 11 -> "daily";
            case 12 -> "epic";
            case 13 -> "legendary";
            case 14 -> "event";
            default -> "";
        };
        if (!template.isBlank()) {
            applyTemplate(crateId, template);
            saveCrates();
            refreshDisplays();
            openCrateEditor(player, crateId);
        }
    }

    private void applyTemplate(String crateId, String template) {
        Crate crate = crates.get(crateId);
        if (crate == null) {
            return;
        }
        crate.rewards.clear();
        if (template.equals("vote")) {
            crate.name = "&a&lVote Crate";
            crate.price = 250.0D;
            crate.rewards.add(Reward.item("diamonds", item(Material.DIAMOND, 3, "&bDiamanten")));
            crate.rewards.add(Reward.item("emeralds", item(Material.EMERALD, 6, "&aEmeralds")));
            crate.rewards.add(Reward.money("coins", 150.0D));
        } else if (template.equals("daily")) {
            crate.name = "&b&lDaily Crate";
            crate.price = 500.0D;
            crate.rewards.add(Reward.item("iron", item(Material.IRON_INGOT, 16, "&fEisen")));
            crate.rewards.add(Reward.item("food", item(Material.COOKED_BEEF, 24, "&6Essen")));
            crate.rewards.add(Reward.command("xp", "experience add <player> 5 levels"));
        } else if (template.equals("epic")) {
            crate.name = "&d&lEpic Crate";
            crate.price = 1500.0D;
            crate.rewards.add(Reward.item("diamond_block", item(Material.DIAMOND_BLOCK, 1, "&bDiamantblock")));
            crate.rewards.add(Reward.item("gold", item(Material.GOLD_INGOT, 24, "&6Gold")));
            crate.rewards.add(Reward.money("coins", 1000.0D));
        } else if (template.equals("legendary")) {
            crate.name = "&6&lLegendary Crate";
            crate.price = 5000.0D;
            crate.rewards.add(Reward.item("netherite", item(Material.NETHERITE_INGOT, 1, "&8Netherite")));
            crate.rewards.add(Reward.item("beacon", item(Material.BEACON, 1, "&bBeacon")));
            crate.rewards.add(Reward.money("coins", 5000.0D));
        } else if (template.equals("event")) {
            crate.name = "&c&lEvent Crate";
            crate.price = 1000.0D;
            crate.rewards.add(Reward.item("fireworks", item(Material.FIREWORK_ROCKET, 16, "&cFeuerwerk")));
            crate.rewards.add(Reward.item("cake", item(Material.CAKE, 3, "&dKuchen")));
            crate.rewards.add(Reward.message("message", "&6Event-Gewinn fuer &f<player>&6!"));
        }
        for (Reward reward : crate.rewards) {
            reward.weight = 10;
        }
    }

    private void handlePendingInput(Player player, String rawInput) {
        PendingInput input = pendingInputs.remove(player.getUniqueId());
        if (input == null) {
            return;
        }
        String value = rawInput.trim();
        if (value.equalsIgnoreCase("cancel")) {
            player.sendMessage(color(prefix() + "&cEingabe abgebrochen."));
            reopenAfterInput(player, input);
            return;
        }
        Crate crate = crates.get(input.crateId);
        if (crate == null) {
            openAdmin(player);
            return;
        }
        switch (input.type) {
            case CRATE_NAME -> {
                crate.name = value;
                saveCrates();
                refreshDisplays();
                openCrateEditor(player, crate.id);
            }
            case CRATE_PERMISSION -> {
                crate.vipPermission = value;
                saveCrates();
                refreshDisplays();
                openRequirementEditor(player, crate.id);
            }
            case REWARD_COMMAND -> {
                crate.rewards.add(Reward.command(uniqueRewardId(crate), value.startsWith("/") ? value.substring(1) : value));
                saveCrates();
                openRewardList(player, crate.id, 0);
            }
            case REWARD_MONEY -> {
                double amount = Math.max(0.0D, parseDouble(value, 0.0D));
                crate.rewards.add(Reward.money(uniqueRewardId(crate), amount));
                saveCrates();
                openRewardList(player, crate.id, 0);
            }
            case REWARD_MESSAGE -> {
                crate.rewards.add(Reward.message(uniqueRewardId(crate), value));
                saveCrates();
                openRewardList(player, crate.id, 0);
            }
            case REWARD_SET_COMMAND -> {
                Reward reward = crate.reward(input.rewardId);
                if (reward != null) {
                    reward.type = RewardType.COMMAND;
                    reward.command = value.startsWith("/") ? value.substring(1) : value;
                    saveCrates();
                    openRewardEditor(player, crate.id, reward.id);
                }
            }
            case REWARD_SET_MONEY -> {
                Reward reward = crate.reward(input.rewardId);
                if (reward != null) {
                    reward.type = RewardType.MONEY;
                    reward.money = Math.max(0.0D, parseDouble(value, 0.0D));
                    saveCrates();
                    openRewardEditor(player, crate.id, reward.id);
                }
            }
            case REWARD_PERMISSION_GIVE -> {
                Reward reward = crate.reward(input.rewardId);
                if (reward != null) {
                    reward.permissionGive = value;
                    saveCrates();
                    openRewardEditor(player, crate.id, reward.id);
                }
            }
            case REWARD_PERMISSION_TAKE -> {
                Reward reward = crate.reward(input.rewardId);
                if (reward != null) {
                    reward.permissionTake = value;
                    saveCrates();
                    openRewardEditor(player, crate.id, reward.id);
                }
            }
            case REWARD_BROADCAST -> {
                Reward reward = crate.reward(input.rewardId);
                if (reward != null) {
                    reward.broadcast = value;
                    saveCrates();
                    openRewardEditor(player, crate.id, reward.id);
                }
            }
        }
    }

    private void reopenAfterInput(Player player, PendingInput input) {
        if (input.type == InputType.CRATE_NAME) {
            openCrateEditor(player, input.crateId);
        } else if (input.type == InputType.CRATE_PERMISSION) {
            openRequirementEditor(player, input.crateId);
        } else if (input.rewardId != null && !input.rewardId.isBlank()) {
            openRewardEditor(player, input.crateId, input.rewardId);
        } else {
            openRewardList(player, input.crateId, 0);
        }
    }

    private void beginInput(Player player, PendingInput input, String prompt) {
        pendingInputs.put(player.getUniqueId(), input);
        player.closeInventory();
        player.sendMessage(color(prefix() + prompt));
        player.sendMessage(color(prefix() + "&7Schreibe &ccancel&7 zum Abbrechen."));
    }

    private void loadCrates() {
        crates.clear();
        cratesConfig = YamlConfiguration.loadConfiguration(cratesFile);
        ConfigurationSection section = cratesConfig.getConfigurationSection("crates");
        if (section == null) {
            return;
        }
        for (String id : section.getKeys(false)) {
            Crate crate = Crate.load(id, section.getConfigurationSection(id), keyCrateId);
            if (crate != null) {
                crates.put(id, crate);
            }
        }
    }

    private void loadPlayerData() {
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException exception) {
                getLogger().warning("Could not create data.yml: " + exception.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void savePlayerData() {
        if (dataConfig == null) {
            return;
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException exception) {
            getLogger().warning("Could not save data.yml: " + exception.getMessage());
        }
    }

    private long lastOpened(Player player, String crateId) {
        if (dataConfig == null) {
            return 0L;
        }
        return dataConfig.getLong(playerCratePath(player, crateId) + ".last-opened", 0L);
    }

    private void markOpened(Player player, Crate crate) {
        if (dataConfig == null) {
            return;
        }
        dataConfig.set(playerCratePath(player, crate.id) + ".last-opened", System.currentTimeMillis());
        savePlayerData();
    }

    private int updateStreak(Player player, String crateId) {
        if (dataConfig == null) {
            return 1;
        }
        String path = playerCratePath(player, crateId);
        long today = System.currentTimeMillis() / 86400000L;
        long lastDay = dataConfig.getLong(path + ".streak-day", -10L);
        int streak = dataConfig.getInt(path + ".streak", 0);
        if (lastDay == today) {
            return Math.max(1, streak);
        }
        if (lastDay == today - 1) {
            streak += 1;
        } else {
            streak = 1;
        }
        dataConfig.set(path + ".streak", streak);
        dataConfig.set(path + ".streak-day", today);
        savePlayerData();
        return streak;
    }

    private String playerCratePath(Player player, String crateId) {
        return "players." + player.getUniqueId() + ".crates." + crateId;
    }

    private void saveCrates() {
        if (cratesConfig == null) {
            cratesConfig = new YamlConfiguration();
        }
        cratesConfig.set("crates", null);
        for (Crate crate : crates.values()) {
            crate.save(cratesConfig.createSection("crates." + crate.id));
        }
        try {
            cratesConfig.save(cratesFile);
        } catch (IOException exception) {
            getLogger().severe("Could not save crates.yml: " + exception.getMessage());
        }
    }

    private void refreshDisplays() {
        removeDisplays();
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity.getScoreboardTags().contains(DISPLAY_TAG)) {
                    entity.remove();
                }
            }
        }
        for (Crate crate : crates.values()) {
            if (!crate.textDisplay || crate.location == null || crate.location.getWorld() == null) {
                continue;
            }
            Location location = crate.location.clone().add(0.5D, 1.35D, 0.5D);
            TextDisplay display = crate.location.getWorld().spawn(location, TextDisplay.class, entity -> {
                entity.addScoreboardTag(DISPLAY_TAG);
                entity.addScoreboardTag("rslcrates_" + crate.id);
                entity.setBillboard(Display.Billboard.CENTER);
                entity.setSeeThrough(false);
                entity.setShadowed(true);
                entity.setText(color(crate.displayText()));
            });
            displays.put(crate.id, display);
        }
    }

    private void removeDisplays() {
        for (TextDisplay display : displays.values()) {
            if (display != null && !display.isDead()) {
                display.remove();
            }
        }
        displays.clear();
    }

    private Optional<Crate> crateAt(Location location) {
        return crates.values().stream().filter(crate -> crate.isAt(location)).findFirst();
    }

    private Optional<Crate> crateAtExcept(Location location, String excludedCrateId) {
        return crates.values().stream()
            .filter(crate -> !crate.id.equals(excludedCrateId))
            .filter(crate -> crate.isAt(location))
            .findFirst();
    }

    private String locationKey(Location location) {
        if (location == null || location.getWorld() == null) {
            return "missing";
        }
        return location.getWorld().getUID() + ":" + location.getBlockX() + ":" + location.getBlockY() + ":" + location.getBlockZ();
    }

    private List<String> duplicateLocationIds() {
        Map<String, List<String>> byLocation = new HashMap<>();
        for (Crate crate : crates.values()) {
            byLocation.computeIfAbsent(locationKey(crate.location), ignored -> new ArrayList<>()).add(crate.id);
        }
        List<String> duplicates = new ArrayList<>();
        for (List<String> ids : byLocation.values()) {
            if (ids.size() > 1) {
                duplicates.addAll(ids);
            }
        }
        return duplicates;
    }

    private void setupEconomy() {
        economy = null;
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return;
        }
        RegisteredServiceProvider<Economy> provider = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (provider != null) {
            economy = provider.getProvider();
        }
    }

    private boolean requireAdmin(CommandSender sender) {
        if (!sender.hasPermission("rslcrates.admin")) {
            send(sender, "no-permission");
            return false;
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(color(prefix() + "&6RSLCrates Befehle:"));
        sender.sendMessage(color("&e/rslcrates admin &7- GUI-Baukasten"));
        sender.sendMessage(color("&e/rslcrates create <id> &7- Zielblock als Crate setzen"));
        sender.sendMessage(color("&e/rslcrates edit <id> &7- Crate bearbeiten"));
        sender.sendMessage(color("&e/rslcrates key give <spieler> <crate> [anzahl]"));
        sender.sendMessage(color("&e/rslcrates reload &7- Neu laden"));
    }

    private void send(CommandSender sender, String key) {
        sender.sendMessage(color(prefix() + message(key)));
    }

    private void sendRaw(CommandSender sender, String raw) {
        sender.sendMessage(color(prefix() + raw));
    }

    private String message(String key) {
        return getConfig().getString("messages." + key, "");
    }

    private String prefix() {
        return message("prefix");
    }

    private String color(String value) {
        return ChatColor.translateAlternateColorCodes('&', translateHexColors(value == null ? "" : value));
    }

    private String translateHexColors(String value) {
        String translated = replaceHexPattern(HEX_AMP_PATTERN, value);
        return replaceHexPattern(HEX_TAG_PATTERN, translated);
    }

    private String replaceHexPattern(Pattern pattern, String value) {
        Matcher matcher = pattern.matcher(value);
        StringBuffer buffer = new StringBuffer();
        while (matcher.find()) {
            String replacement;
            try {
                replacement = net.md_5.bungee.api.ChatColor.of("#" + matcher.group(1)).toString();
            } catch (IllegalArgumentException ignored) {
                replacement = matcher.group(0);
            }
            matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(buffer);
        return buffer.toString();
    }

    private String applyNameColor(String name, String colorCode) {
        TextFormatState state = readFormatState(name);
        state.color = colorCode;
        return state.prefix() + stripLeadingFormatting(name);
    }

    private String applyNameStyle(String name, String styleCode) {
        TextFormatState state = readFormatState(name);
        if (!state.styles.contains(styleCode)) {
            state.styles.add(styleCode);
        }
        return state.prefix() + stripLeadingFormatting(name);
    }

    private String applyFontPreset(String name, FontPreset preset) {
        String plain = stripLeadingFormatting(name);
        return switch (preset) {
            case NORMAL -> plain;
            case BOLD_CODE -> "&l" + plain;
            case SMALL_CAPS -> "&6" + toSmallCaps(plain);
            case FULLWIDTH -> "&e" + toFullwidth(plain);
            case RSL_GOLD -> gradientText(plain, "#FFF1B8", "#B86A3B", "&l");
            case WARNING -> "&c&l" + plain;
            case VIP -> gradientText(plain, "#B9F2FF", "#FFD700", "&l");
            case MYSTERY -> gradientText(plain, "#B86AEE", "#FFF1B8", "&l");
            case JACKPOT -> gradientText(plain, "#FFF1B8", "#FF3D00", "&l");
        };
    }

    private TextFormatState readFormatState(String value) {
        TextFormatState state = new TextFormatState();
        String text = value == null ? "" : value;
        int index = 0;
        while (index < text.length()) {
            String code = readFormatCode(text, index);
            if (code == null) {
                break;
            }
            String lower = code.toLowerCase(Locale.ROOT);
            if (lower.equals("&r")) {
                state.color = "";
                state.styles.clear();
            } else if (isColorFormat(lower)) {
                state.color = code;
            } else if (isStyleFormat(lower) && !state.styles.contains(lower)) {
                state.styles.add(lower);
            }
            index += code.length();
        }
        return state;
    }

    private String stripLeadingFormatting(String value) {
        String text = value == null ? "" : value;
        int index = 0;
        while (index < text.length()) {
            String code = readFormatCode(text, index);
            if (code == null) {
                break;
            }
            index += code.length();
        }
        return text.substring(index);
    }

    private String readFormatCode(String text, int index) {
        if (index + 2 <= text.length() && text.charAt(index) == '&') {
            if (index + 8 <= text.length() && text.charAt(index + 1) == '#'
                && text.substring(index + 2, index + 8).matches("[A-Fa-f0-9]{6}")) {
                return text.substring(index, index + 8);
            }
            char code = Character.toLowerCase(text.charAt(index + 1));
            if ("0123456789abcdefklmnor".indexOf(code) >= 0) {
                return text.substring(index, index + 2).toLowerCase(Locale.ROOT);
            }
        }
        if (index + 9 <= text.length() && text.charAt(index) == '<' && text.charAt(index + 1) == '#'
            && text.charAt(index + 8) == '>' && text.substring(index + 2, index + 8).matches("[A-Fa-f0-9]{6}")) {
            return text.substring(index, index + 9);
        }
        return null;
    }

    private boolean isColorFormat(String code) {
        return code.matches("&[0-9a-f]") || code.matches("&#[A-Fa-f0-9]{6}") || code.matches("<#[A-Fa-f0-9]{6}>");
    }

    private boolean isStyleFormat(String code) {
        return code.equals("&l") || code.equals("&o") || code.equals("&n") || code.equals("&m") || code.equals("&k");
    }

    private String gradientText(String text, String startHex, String endHex, String styles) {
        if (text == null || text.isBlank()) {
            return text == null ? "" : text;
        }
        int start = Integer.parseInt(startHex.substring(1), 16);
        int end = Integer.parseInt(endHex.substring(1), 16);
        int visible = Math.max(1, text.length() - 1);
        int sr = (start >> 16) & 0xFF;
        int sg = (start >> 8) & 0xFF;
        int sb = start & 0xFF;
        int er = (end >> 16) & 0xFF;
        int eg = (end >> 8) & 0xFF;
        int eb = end & 0xFF;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            double t = (double) i / visible;
            int r = (int) Math.round(sr + (er - sr) * t);
            int g = (int) Math.round(sg + (eg - sg) * t);
            int b = (int) Math.round(sb + (eb - sb) * t);
            builder.append(String.format(Locale.US, "&#%02X%02X%02X", r, g, b)).append(styles).append(text.charAt(i));
        }
        return builder.toString();
    }

    private String toSmallCaps(String text) {
        StringBuilder builder = new StringBuilder();
        for (char c : text.toCharArray()) {
            builder.append(smallCap(c));
        }
        return builder.toString();
    }

    private char smallCap(char c) {
        return switch (Character.toLowerCase(c)) {
            case 'a' -> 'ᴀ';
            case 'b' -> 'ʙ';
            case 'c' -> 'ᴄ';
            case 'd' -> 'ᴅ';
            case 'e' -> 'ᴇ';
            case 'f' -> 'ꜰ';
            case 'g' -> 'ɢ';
            case 'h' -> 'ʜ';
            case 'i' -> 'ɪ';
            case 'j' -> 'ᴊ';
            case 'k' -> 'ᴋ';
            case 'l' -> 'ʟ';
            case 'm' -> 'ᴍ';
            case 'n' -> 'ɴ';
            case 'o' -> 'ᴏ';
            case 'p' -> 'ᴘ';
            case 'q' -> 'ǫ';
            case 'r' -> 'ʀ';
            case 's' -> 'ꜱ';
            case 't' -> 'ᴛ';
            case 'u' -> 'ᴜ';
            case 'v' -> 'ᴠ';
            case 'w' -> 'ᴡ';
            case 'x' -> 'x';
            case 'y' -> 'ʏ';
            case 'z' -> 'ᴢ';
            default -> c;
        };
    }

    private String toFullwidth(String text) {
        StringBuilder builder = new StringBuilder();
        for (char c : text.toCharArray()) {
            if (c >= 33 && c <= 126) {
                builder.append((char) (c + 65248));
            } else if (c == ' ') {
                builder.append(' ');
            } else {
                builder.append(c);
            }
        }
        return builder.toString();
    }

    private String replace(String value, Player player) {
        return value.replace("<player>", player.getName()).replace("%player%", player.getName()).replace("<world>", player.getWorld().getName());
    }

    private void play(Player player, String path) {
        String soundName = getConfig().getString(path, "");
        if (soundName == null || soundName.isBlank()) {
            return;
        }
        playDirect(player, soundName);
    }

    private void playDirect(Player player, String soundName) {
        playDirect(player, soundName, (float) getConfig().getDouble("sounds.volume", 0.8D), (float) getConfig().getDouble("sounds.pitch", 1.1D));
    }

    private void playDirect(Player player, String soundName, float volume, float pitch) {
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ignored) {
            // Unknown sounds should not break the crate.
        }
    }

    private String nextRewardSound(String current) {
        List<String> sounds = Arrays.asList("", "UI_BUTTON_CLICK", "BLOCK_NOTE_BLOCK_PLING", "ENTITY_PLAYER_LEVELUP", "ENTITY_EXPERIENCE_ORB_PICKUP", "UI_TOAST_CHALLENGE_COMPLETE");
        int index = sounds.indexOf(current == null ? "" : current);
        return sounds.get((index + 1) % sounds.size());
    }

    private ItemStack button(Material material, String name, String... loreLines) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            meta.setLore(Arrays.stream(loreLines).map(this::color).collect(Collectors.toList()));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack item(Material material, int amount, String name) {
        ItemStack stack = new ItemStack(material, clamp(amount, 1, 64));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void markKey(ItemStack stack, String crateId) {
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(keyCrateId, PersistentDataType.STRING, crateId);
            stack.setItemMeta(meta);
        }
    }

    private String uniqueRewardId(Crate crate) {
        int index = crate.rewards.size() + 1;
        String id = "reward_" + index;
        while (crate.reward(id) != null) {
            index++;
            id = "reward_" + index;
        }
        return id;
    }

    private String cleanId(String raw) {
        return raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]", "_");
    }

    private List<String> filter(List<String> values, String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(lower)).collect(Collectors.toList());
    }

    private int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private double parseDouble(String value, double fallback) {
        try {
            return Double.parseDouble(value.replace(",", "."));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private String formatMoney(double value) {
        return String.format(Locale.US, "%.2f", value);
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0L, millis / 1000L);
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long rest = seconds % 60L;
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        }
        if (minutes > 0) {
            return minutes + "m " + rest + "s";
        }
        return rest + "s";
    }

    private String blankDash(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }

    private enum InputType {
        CRATE_NAME,
        CRATE_PERMISSION,
        REWARD_COMMAND,
        REWARD_MONEY,
        REWARD_MESSAGE,
        REWARD_SET_COMMAND,
        REWARD_SET_MONEY,
        REWARD_PERMISSION_GIVE,
        REWARD_PERMISSION_TAKE,
        REWARD_BROADCAST
    }

    private enum RewardType {
        ITEM,
        COMMAND,
        MONEY,
        MESSAGE
    }

    private enum ConfirmType {
        DELETE_CRATE
    }

    private enum FontPreset {
        NORMAL("&fNormal", Material.PAPER),
        BOLD_CODE("&lBold-Code", Material.GOLD_INGOT),
        SMALL_CAPS("&6Small-Caps", Material.BOOK),
        FULLWIDTH("&eFullwidth", Material.MAP),
        RSL_GOLD("&6RSL-Gold", Material.AMETHYST_SHARD),
        WARNING("&cWarnung", Material.REDSTONE_BLOCK),
        VIP("&bVIP", Material.DIAMOND),
        MYSTERY("&dMystery", Material.ENDER_EYE),
        JACKPOT("&6Jackpot", Material.NETHER_STAR);

        private final String label;
        private final Material icon;

        FontPreset(String label, Material icon) {
            this.label = label;
            this.icon = icon;
        }
    }

    private enum CrateVariant {
        KEY("Key", Material.TRIPWIRE_HOOK),
        PAID("Paid", Material.GOLD_INGOT),
        KEY_OR_PAID("Key oder Paid", Material.EMERALD),
        FREE("Free", Material.LIME_DYE),
        TIMED("Timed", Material.CLOCK),
        PREVIEW("Preview", Material.ENDER_EYE),
        MYSTERY("Mystery", Material.PURPLE_DYE),
        EVENT("Event", Material.FIREWORK_ROCKET),
        VIP("VIP", Material.DIAMOND),
        JACKPOT("Jackpot", Material.NETHER_STAR),
        STREAK("Streak", Material.EXPERIENCE_BOTTLE),
        LEVEL("Level", Material.ENCHANTING_TABLE);

        private final String label;
        private final Material icon;

        CrateVariant(String label, Material icon) {
            this.label = label;
            this.icon = icon;
        }
    }

    private enum AnimationType {
        NONE("Keine", Material.BARRIER),
        QUICK_ROLL("Quick Roll", Material.MINECART),
        CLASSIC_ROLL("Classic Roll", Material.CHEST),
        SLOT_MACHINE("Slot Machine", Material.DROPPER),
        SPIN_CIRCLE("Spin Circle", Material.COMPASS),
        COUNTDOWN("Countdown", Material.CLOCK),
        MYSTERY_REVEAL("Mystery Reveal", Material.ENDER_EYE),
        JACKPOT_BUILDUP("Jackpot Buildup", Material.NETHER_STAR),
        RAINBOW_ROLL("Rainbow Roll", Material.MAGENTA_DYE),
        FIREWORK_BURST("Firework Burst", Material.FIREWORK_ROCKET),
        LIGHTNING_STRIKE("Lightning Strike", Material.BLAZE_ROD),
        DRAGON_SPIN("Dragon Spin", Material.DRAGON_BREATH),
        BEACON_BEAM("Beacon Beam", Material.BEACON),
        ENDER_PORTAL("Ender Portal", Material.ENDER_EYE),
        TREASURE_CHEST("Treasure Chest", Material.CHEST),
        LUCKY_WHEEL("Lucky Wheel", Material.EMERALD),
        CARD_FLIP("Card Flip", Material.PAPER),
        CRYSTAL_CHARGE("Crystal Charge", Material.AMETHYST_SHARD),
        RUNE_CIRCLE("Rune Circle", Material.ENCHANTED_BOOK),
        METEOR_DROP("Meteor Drop", Material.FIRE_CHARGE),
        GOLD_RUSH("Gold Rush", Material.GOLD_BLOCK),
        SOUL_STORM("Soul Storm", Material.SOUL_LANTERN),
        REDSTONE_OVERLOAD("Redstone Overload", Material.REDSTONE_BLOCK),
        CRATE_SHAKE("Crate Shake", Material.BARREL),
        FINAL_REVEAL("Final Reveal", Material.NETHER_STAR);

        private final String label;
        private final Material icon;

        AnimationType(String label, Material icon) {
            this.label = label;
            this.icon = icon;
        }
    }

    private enum EffectLevel {
        CALM("Calm", Material.FEATHER, 0.65D, 0.75D, 1, 0.0D),
        NORMAL("Normal", Material.AMETHYST_SHARD, 1.0D, 1.0D, 2, 0.08D),
        EPIC("Epic", Material.NETHER_STAR, 1.75D, 1.25D, 4, 0.16D);

        private final String label;
        private final Material icon;
        private final double multiplier;
        private final double soundMultiplier;
        private final int weight;
        private final double pitchBoost;

        EffectLevel(String label, Material icon, double multiplier, double soundMultiplier, int weight, double pitchBoost) {
            this.label = label;
            this.icon = icon;
            this.multiplier = multiplier;
            this.soundMultiplier = soundMultiplier;
            this.weight = weight;
            this.pitchBoost = pitchBoost;
        }
    }

    private record PendingInput(InputType type, String crateId, String rewardId) {
    }

    private static final class OpenResult {
        private final boolean success;
        private final boolean usedKey;
        private final boolean paid;
        private final String message;

        private OpenResult(boolean success, boolean usedKey, boolean paid, String message) {
            this.success = success;
            this.usedKey = usedKey;
            this.paid = paid;
            this.message = message;
        }

        private static OpenResult success(boolean usedKey, boolean paid) {
            return new OpenResult(true, usedKey, paid, "");
        }

        private static OpenResult fail(String message) {
            return new OpenResult(false, false, false, message);
        }
    }

    private static final class Crate {
        private final String id;
        private String name;
        private Location location;
        private Material blockType;
        private double price;
        private CrateVariant variant = CrateVariant.KEY_OR_PAID;
        private AnimationType animationType = AnimationType.CLASSIC_ROLL;
        private EffectLevel effectLevel = EffectLevel.NORMAL;
        private boolean textDisplay = true;
        private boolean animation = true;
        private long cooldownSeconds = 0L;
        private long rollTicks = 45L;
        private long rollIntervalTicks = 3L;
        private long finalDelayTicks = 8L;
        private long displayRefreshTicks = 40L;
        private long eventStartEpochSeconds = 0L;
        private long eventEndEpochSeconds = 0L;
        private String vipPermission = "";
        private int minLevel = 0;
        private int jackpotChancePermille = 50;
        private double jackpotMoney = 1000.0D;
        private int streakRequired = 3;
        private double streakBonusMoney = 500.0D;
        private ItemStack keyTemplate;
        private final List<Reward> rewards = new ArrayList<>();

        private Crate(String id) {
            this.id = id;
        }

        private static Crate defaultCrate(String id, Location location, Material blockType, double price) {
            Crate crate = new Crate(id);
            crate.name = "&6&l" + id + " Crate";
            crate.location = location;
            crate.blockType = blockType;
            crate.price = price;
            crate.cooldownSeconds = 0L;
            crate.keyTemplate = new ItemStack(Material.TRIPWIRE_HOOK);
            ItemMeta meta = crate.keyTemplate.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&6" + id + " Key"));
                meta.setLore(Collections.singletonList(ChatColor.translateAlternateColorCodes('&', "&7Oeffnet die " + id + " Crate.")));
                crate.keyTemplate.setItemMeta(meta);
            }
            crate.rewards.add(Reward.item("diamond", new ItemStack(Material.DIAMOND, 3)));
            crate.rewards.add(Reward.money("coins", 100.0D));
            return crate;
        }

        private static Crate load(String id, ConfigurationSection section, NamespacedKey keyCrateId) {
            if (section == null) {
                return null;
            }
            World world = Bukkit.getWorld(section.getString("location.world", ""));
            if (world == null) {
                return null;
            }
            Crate crate = new Crate(id);
            crate.name = section.getString("name", "&6&l" + id + " Crate");
            crate.location = new Location(world, section.getInt("location.x"), section.getInt("location.y"), section.getInt("location.z"));
            crate.blockType = Material.matchMaterial(section.getString("block", "CHEST"));
            if (crate.blockType == null) {
                crate.blockType = Material.CHEST;
            }
            crate.price = section.getDouble("price", 0.0D);
            crate.variant = parseEnum(CrateVariant.class, section.getString("variant", "KEY_OR_PAID"), CrateVariant.KEY_OR_PAID);
            crate.animationType = parseEnum(AnimationType.class, section.getString("animation-type", section.getBoolean("animation.enabled", true) ? "CLASSIC_ROLL" : "NONE"), AnimationType.CLASSIC_ROLL);
            crate.effectLevel = parseEnum(EffectLevel.class, section.getString("effect-level", "NORMAL"), EffectLevel.NORMAL);
            crate.textDisplay = section.getBoolean("text-display.enabled", true);
            crate.animation = section.getBoolean("animation.enabled", true);
            crate.cooldownSeconds = Math.max(0L, section.getLong("timing.cooldown-seconds", 0L));
            crate.rollTicks = Math.max(10L, section.getLong("timing.roll-ticks", 45L));
            crate.rollIntervalTicks = Math.max(1L, section.getLong("timing.roll-interval-ticks", 3L));
            crate.finalDelayTicks = Math.max(1L, section.getLong("timing.final-delay-ticks", 8L));
            crate.displayRefreshTicks = Math.max(20L, section.getLong("timing.text-refresh-ticks", 40L));
            crate.eventStartEpochSeconds = Math.max(0L, section.getLong("event-window.start-epoch-seconds", 0L));
            crate.eventEndEpochSeconds = Math.max(0L, section.getLong("event-window.end-epoch-seconds", 0L));
            crate.vipPermission = section.getString("requirements.vip-permission", "");
            crate.minLevel = Math.max(0, section.getInt("requirements.min-level", 0));
            crate.jackpotChancePermille = Math.max(0, Math.min(1000, section.getInt("jackpot.chance-permille", 50)));
            crate.jackpotMoney = Math.max(0.0D, section.getDouble("jackpot.money", 1000.0D));
            crate.streakRequired = Math.max(1, section.getInt("streak.required", 3));
            crate.streakBonusMoney = Math.max(0.0D, section.getDouble("streak.bonus-money", 500.0D));
            crate.keyTemplate = section.getItemStack("key.item");
            if (crate.keyTemplate == null) {
                crate.keyTemplate = new ItemStack(Material.TRIPWIRE_HOOK);
            }
            ItemMeta meta = crate.keyTemplate.getItemMeta();
            if (meta != null) {
                meta.getPersistentDataContainer().set(keyCrateId, PersistentDataType.STRING, id);
                crate.keyTemplate.setItemMeta(meta);
            }
            ConfigurationSection rewardsSection = section.getConfigurationSection("rewards");
            if (rewardsSection != null) {
                for (String rewardId : rewardsSection.getKeys(false)) {
                    Reward reward = Reward.load(rewardId, rewardsSection.getConfigurationSection(rewardId));
                    if (reward != null) {
                        crate.rewards.add(reward);
                    }
                }
            }
            return crate;
        }

        private static <E extends Enum<E>> E parseEnum(Class<E> type, String value, E fallback) {
            try {
                return Enum.valueOf(type, value == null ? fallback.name() : value.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ignored) {
                return fallback;
            }
        }

        private void save(ConfigurationSection section) {
            section.set("name", name);
            section.set("location.world", location.getWorld() == null ? "" : location.getWorld().getName());
            section.set("location.x", location.getBlockX());
            section.set("location.y", location.getBlockY());
            section.set("location.z", location.getBlockZ());
            section.set("block", blockType.name());
            section.set("price", price);
            section.set("variant", variant.name());
            section.set("animation-type", animationType.name());
            section.set("effect-level", effectLevel.name());
            section.set("text-display.enabled", textDisplay);
            section.set("animation.enabled", animation);
            section.set("timing.cooldown-seconds", cooldownSeconds);
            section.set("timing.roll-ticks", rollTicks);
            section.set("timing.roll-interval-ticks", rollIntervalTicks);
            section.set("timing.final-delay-ticks", finalDelayTicks);
            section.set("timing.text-refresh-ticks", displayRefreshTicks);
            section.set("event-window.start-epoch-seconds", eventStartEpochSeconds);
            section.set("event-window.end-epoch-seconds", eventEndEpochSeconds);
            section.set("requirements.vip-permission", vipPermission);
            section.set("requirements.min-level", minLevel);
            section.set("jackpot.chance-permille", jackpotChancePermille);
            section.set("jackpot.money", jackpotMoney);
            section.set("streak.required", streakRequired);
            section.set("streak.bonus-money", streakBonusMoney);
            section.set("key.item", keyTemplate);
            for (Reward reward : rewards) {
                reward.save(section.createSection("rewards." + reward.id));
            }
        }

        private boolean isAt(Location other) {
            return location != null
                && location.getWorld() != null
                && other.getWorld() != null
                && location.getWorld().getUID().equals(other.getWorld().getUID())
                && location.getBlockX() == other.getBlockX()
                && location.getBlockY() == other.getBlockY()
                && location.getBlockZ() == other.getBlockZ();
        }

        private ItemStack keyItem(int amount, NamespacedKey keyCrateId) {
            ItemStack stack = keyTemplate == null ? new ItemStack(Material.TRIPWIRE_HOOK) : keyTemplate.clone();
            stack.setAmount(amount);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.getPersistentDataContainer().set(keyCrateId, PersistentDataType.STRING, id);
                if (!meta.hasDisplayName()) {
                    meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&6" + id + " Key"));
                }
                stack.setItemMeta(meta);
            }
            return stack;
        }

        private Reward roll(Random random) {
            int total = totalWeight();
            if (total <= 0) {
                return null;
            }
            int value = random.nextInt(total) + 1;
            int cursor = 0;
            for (Reward reward : rewards) {
                cursor += Math.max(1, reward.weight);
                if (value <= cursor) {
                    return reward;
                }
            }
            return rewards.isEmpty() ? null : rewards.get(0);
        }

        private int totalWeight() {
            return rewards.stream().mapToInt(reward -> Math.max(1, reward.weight)).sum();
        }

        private Reward reward(String rewardId) {
            return rewards.stream().filter(reward -> reward.id.equals(rewardId)).findFirst().orElse(null);
        }

        private String chanceText(Reward reward) {
            int total = totalWeight();
            if (total <= 0) {
                return "0%";
            }
            return String.format(Locale.US, "%.1f%%", (Math.max(1, reward.weight) * 100.0D) / total);
        }

        private String displayText() {
            List<Reward> sorted = rewards.stream()
                .sorted(Comparator.comparingInt((Reward reward) -> reward.weight).reversed())
                .limit(3)
                .collect(Collectors.toList());
            StringBuilder builder = new StringBuilder();
            builder.append(name).append("\n");
            builder.append("&7Variante: &e").append(variant.label).append(" &8| &7Anim: &e").append(animationType.label).append("\n");
            builder.append("&7Effekt: &e").append(effectLevel.label).append("\n");
            if (variant == CrateVariant.MYSTERY) {
                builder.append("&dMystery: Chancen versteckt\n");
            } else if (variant == CrateVariant.FREE || variant == CrateVariant.TIMED || variant == CrateVariant.PREVIEW) {
                builder.append("&aKostenlos");
                if (cooldownSeconds > 0) {
                    builder.append(" &8| &7CD: &e").append(cooldownSeconds / 60L).append("m");
                }
                builder.append("\n");
            } else {
                builder.append("&7Key oder &6").append(String.format(Locale.US, "%.2f", price)).append("&7 Coins\n");
            }
            if (sorted.isEmpty()) {
                builder.append("&cKeine Rewards");
            } else {
                builder.append(variant == CrateVariant.MYSTERY ? "&eMoegliche Gewinne:" : "&eTop Chancen:");
                for (Reward reward : sorted) {
                    builder.append("\n&8- &f").append(reward.shortName());
                    if (variant != CrateVariant.MYSTERY) {
                        builder.append(" &7").append(chanceText(reward));
                    }
                }
            }
            return builder.toString();
        }

        private boolean eventActive(long nowMillis) {
            long now = nowMillis / 1000L;
            if (eventStartEpochSeconds > 0L && now < eventStartEpochSeconds) {
                return false;
            }
            return eventEndEpochSeconds <= 0L || now <= eventEndEpochSeconds;
        }

        private String eventText() {
            if (eventStartEpochSeconds <= 0L && eventEndEpochSeconds <= 0L) {
                return "kein Event";
            }
            return "Start " + eventStartEpochSeconds + " / Ende " + eventEndEpochSeconds;
        }
    }

    private static final class Reward {
        private final String id;
        private RewardType type;
        private int weight = 10;
        private ItemStack item;
        private String command = "";
        private double money;
        private String message = "";
        private String permissionGive = "";
        private String permissionTake = "";
        private int xpLevels = 0;
        private String sound = "";
        private String broadcast = "";

        private Reward(String id, RewardType type) {
            this.id = id;
            this.type = type;
        }

        private static Reward item(String id, ItemStack item) {
            Reward reward = new Reward(id, RewardType.ITEM);
            reward.item = item;
            return reward;
        }

        private static Reward command(String id, String command) {
            Reward reward = new Reward(id, RewardType.COMMAND);
            reward.command = command;
            return reward;
        }

        private static Reward money(String id, double money) {
            Reward reward = new Reward(id, RewardType.MONEY);
            reward.money = money;
            return reward;
        }

        private static Reward message(String id, String message) {
            Reward reward = new Reward(id, RewardType.MESSAGE);
            reward.message = message;
            return reward;
        }

        private static Reward load(String id, ConfigurationSection section) {
            if (section == null) {
                return null;
            }
            RewardType type;
            try {
                type = RewardType.valueOf(section.getString("type", "ITEM").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ignored) {
                type = RewardType.ITEM;
            }
            Reward reward = new Reward(id, type);
            reward.weight = Math.max(1, section.getInt("weight", 10));
            reward.item = section.getItemStack("item");
            reward.command = section.getString("command", "");
            reward.money = section.getDouble("money", 0.0D);
            reward.message = section.getString("message", "");
            reward.permissionGive = section.getString("permission-give", "");
            reward.permissionTake = section.getString("permission-take", "");
            reward.xpLevels = section.getInt("xp-levels", 0);
            reward.sound = section.getString("sound", "");
            reward.broadcast = section.getString("broadcast", "");
            return reward;
        }

        private void save(ConfigurationSection section) {
            section.set("type", type.name());
            section.set("weight", weight);
            if (item != null) {
                section.set("item", item);
            }
            if (!command.isBlank()) {
                section.set("command", command);
            }
            if (money > 0.0D) {
                section.set("money", money);
            }
            if (!message.isBlank()) {
                section.set("message", message);
            }
            if (!permissionGive.isBlank()) {
                section.set("permission-give", permissionGive);
            }
            if (!permissionTake.isBlank()) {
                section.set("permission-take", permissionTake);
            }
            if (xpLevels != 0) {
                section.set("xp-levels", xpLevels);
            }
            if (!sound.isBlank()) {
                section.set("sound", sound);
            }
            if (!broadcast.isBlank()) {
                section.set("broadcast", broadcast);
            }
        }

        private ItemStack preview(Crate crate) {
            Material material = switch (type) {
                case ITEM -> item == null ? Material.CHEST : item.getType();
                case COMMAND -> Material.COMMAND_BLOCK;
                case MONEY -> Material.GOLD_INGOT;
                case MESSAGE -> Material.PAPER;
            };
            ItemStack stack = item != null && type == RewardType.ITEM ? item.clone() : new ItemStack(material);
            stack.setAmount(Math.max(1, Math.min(64, stack.getAmount())));
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&e" + displayName(crate)));
                stack.setItemMeta(meta);
            }
            return stack;
        }

        private ItemStack previewWithChance(Crate crate, int totalWeight) {
            ItemStack stack = preview(crate);
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                List<String> lore = new ArrayList<>();
                lore.add(ChatColor.translateAlternateColorCodes('&', "&7Typ: &e" + type.name()));
                lore.add(ChatColor.translateAlternateColorCodes('&', "&7Gewicht: &e" + weight));
                String chance = totalWeight <= 0 ? "0%" : String.format(Locale.US, "%.1f%%", (Math.max(1, weight) * 100.0D) / totalWeight);
                lore.add(ChatColor.translateAlternateColorCodes('&', "&7Chance: &e" + chance));
                if (xpLevels != 0) {
                    lore.add(ChatColor.translateAlternateColorCodes('&', "&7XP-Level: &e" + xpLevels));
                }
                if (!permissionGive.isBlank()) {
                    lore.add(ChatColor.translateAlternateColorCodes('&', "&7Gibt Permission: &e" + permissionGive));
                }
                if (!permissionTake.isBlank()) {
                    lore.add(ChatColor.translateAlternateColorCodes('&', "&7Nimmt Permission: &e" + permissionTake));
                }
                if (!sound.isBlank()) {
                    lore.add(ChatColor.translateAlternateColorCodes('&', "&7Sound: &e" + sound));
                }
                if (!broadcast.isBlank()) {
                    lore.add(ChatColor.translateAlternateColorCodes('&', "&7Broadcast aktiv"));
                }
                lore.add(ChatColor.translateAlternateColorCodes('&', "&7Klick zum Bearbeiten."));
                meta.setLore(lore);
                stack.setItemMeta(meta);
            }
            return stack;
        }

        private String displayName(Crate crate) {
            return switch (type) {
                case ITEM -> item == null ? "Item" : item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
                case COMMAND -> "/" + command;
                case MONEY -> String.format(Locale.US, "%.2f Coins", money);
                case MESSAGE -> message;
            };
        }

        private String shortName() {
            return switch (type) {
                case ITEM -> item == null ? "Item" : item.getType().name();
                case COMMAND -> "Command";
                case MONEY -> String.format(Locale.US, "%.0f Coins", money);
                case MESSAGE -> "Message";
            };
        }
    }

    private static final class AdminHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CrateListHolder implements InventoryHolder {
        private int page;
        private Inventory inventory;

        private CrateListHolder(int page) {
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class CrateEditorHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private CrateEditorHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class RewardListHolder implements InventoryHolder {
        private final String crateId;
        private int page;
        private Inventory inventory;

        private RewardListHolder(String crateId, int page) {
            this.crateId = crateId;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class RewardEditorHolder implements InventoryHolder {
        private final String crateId;
        private final String rewardId;
        private Inventory inventory;

        private RewardEditorHolder(String crateId, String rewardId) {
            this.crateId = crateId;
            this.rewardId = rewardId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class TemplateHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private TemplateHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class VariantHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private VariantHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class AnimationHolder implements InventoryHolder {
        private final String crateId;
        private int page;
        private Inventory inventory;

        private AnimationHolder(String crateId, int page) {
            this.crateId = crateId;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class EffectLevelHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private EffectLevelHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class TimingHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private TimingHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class RequirementHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private RequirementHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class JackpotHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private JackpotHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class TextDesignHolder implements InventoryHolder {
        private final String crateId;
        private Inventory inventory;

        private TextDesignHolder(String crateId) {
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class ConfirmHolder implements InventoryHolder {
        private final ConfirmType type;
        private final String crateId;
        private Inventory inventory;

        private ConfirmHolder(ConfirmType type, String crateId) {
            this.type = type;
            this.crateId = crateId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private static final class TextFormatState {
        private String color = "";
        private final List<String> styles = new ArrayList<>();

        private String prefix() {
            return color + String.join("", styles);
        }
    }

    private static final class RollHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}

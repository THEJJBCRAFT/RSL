package de.rsl.ranks.rank;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public class Rank {
    private final String name;
    private final String displayName;
    private final String prefix;
    private final String suffix;
    private final String color;
    private final int priority;
    private final Set<String> permissions;
    private final Set<String> inherits;

    public Rank(String name, String displayName, String prefix, String suffix, String color, int priority,
                Set<String> permissions, Set<String> inherits) {
        this.name = name.toLowerCase();
        this.displayName = displayName;
        this.prefix = prefix;
        this.suffix = suffix;
        this.color = color;
        this.priority = priority;
        this.permissions = new LinkedHashSet<>(permissions);
        this.inherits = new LinkedHashSet<>(inherits);
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public String getColor() {
        return color;
    }

    public int getPriority() {
        return priority;
    }

    public Set<String> getPermissions() {
        return Collections.unmodifiableSet(permissions);
    }

    public Set<String> getInherits() {
        return Collections.unmodifiableSet(inherits);
    }
}

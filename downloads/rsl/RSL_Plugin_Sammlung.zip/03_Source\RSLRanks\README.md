# RSLRanks

Ein einfaches Paper/Spigot Rang- und Rechtesystem fuer Minecraft 1.20.1 bis 1.21.x.

## Installation

1. `RSLRanks-1.0.0.jar` in den `plugins` Ordner deines Paper/Spigot Servers legen.
2. Server starten.
3. `config.yml`, `players.yml` und `messages.yml` werden automatisch erstellt.
4. Raenge in `plugins/RSLRanks/config.yml` anpassen.
5. `/rank reload` ausfuehren.

## TAB, Vault und PlaceholderAPI

- Vault ist empfohlen, damit TAB Primary Groups, Prefixe und Suffixe lesen kann.
- TAB ist optional, aber fuer Tablisten-Sortierung empfohlen.
- PlaceholderAPI ist optional und stellt diese Placeholder bereit:
  - `%rslranks_rank%`
  - `%rslranks_prefix%`
  - `%rslranks_priority%`
  - `%rslranks_color%`

Nutze `/rank tabconfig`, kopiere die Ausgabe in die TAB Config und fuehre danach `/tab reload` aus.
Wenn Vault genutzt wird, sollte `assign-groups-by-permissions: false` in TAB bleiben.

## Wichtiger Hinweis zu Wildcards

RSLRanks nutzt eine stabile PermissionAttachment-Variante. Exakte Permissions wirken direkt ueber Bukkit.
Wildcards wie `rsl.*` oder `minecraft.command.*` funktionieren in RSLRanks-eigenen Checks und im Vault-Provider.
Einige Fremdplugins erkennen globale Wildcards aber nur mit tiefen Permission-Systemen wie LuckPerms.

## Build

Auf diesem Rechner ist global eventuell Java 8 aktiv. Fuer den Build Java 17+ setzen, zum Beispiel:

```powershell
$env:JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.10.7-hotspot'
$env:Path=\"$env:JAVA_HOME\bin;$env:Path\"
.\gradlew.bat clean build
```

Die fertige Jar liegt danach in `build/libs/RSLRanks-1.0.0.jar`.

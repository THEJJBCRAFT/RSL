# RSLWelcome

Paper-Plugin fuer animierte Join-Titles und private Willkommensnachrichten.

## Features

- Zeigt beim Join einen animierten Title.
- Neuer Standard: `WILLKOMMEN`, kurze Pause, danach wird der Spielername Buchstabe fuer Buchstabe geschrieben.
- Sendet eine Chat-Nachricht nur an den joinenden Spieler.
- Erkennt den Servernamen automatisch aus `server.properties` / MOTD.
- Nutzt zuerst `plugins/RSLWelcome/server-name.yml`, damit kein Hoster-Name wie SynHost angezeigt wird.
- Fallback ist `NeyexSMP`.
- Design passt zum Redstone-Labs / NeyexSMP Gold-Kupfer-Stil.

## Befehle

- `/rslwelcome reload`
- `/rslwelcome test`

## Title-Effekt

Der Schreibeffekt steht in `config.yml` unter:

```yml
title-animation:
  spell-player-name:
    enabled: true
    letter-interval-ticks: 8
    cursor: "_"
    sounds:
      enabled: true
      intro: "ENTITY_PLAYER_LEVELUP"
      letter: "BLOCK_NOTE_BLOCK_PLING"
      final: "UI_TOAST_CHALLENGE_COMPLETE"
```

## Servername

In `plugins/RSLWelcome/server-name.yml` kannst du fest einstellen:

```yml
enabled: true
server-name: "NeyexSMP"
```

## Recht

- `rslwelcome.admin`

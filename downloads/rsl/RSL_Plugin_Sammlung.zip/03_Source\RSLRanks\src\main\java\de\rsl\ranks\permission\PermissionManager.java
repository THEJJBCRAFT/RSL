package de.rsl.ranks.permission;

import de.rsl.ranks.RSLRanksPlugin;
import de.rsl.ranks.rank.Rank;
import de.rsl.ranks.rank.RankManager;
import de.rsl.ranks.user.UserData;
import de.rsl.ranks.user.UserManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.PermissionAttachment;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class PermissionManager implements Listener {
    private final RSLRanksPlugin plugin;
    private final RankManager rankManager;
    private final UserManager userManager;
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();

    public PermissionManager(RSLRanksPlugin plugin, RankManager rankManager, UserManager userManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
        this.userManager = userManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> apply(event.getPlayer()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        remove(event.getPlayer());
    }

    public void apply(Player player) {
        remove(player);
        UserData data = userManager.getOrCreate(player);
        PermissionAttachment attachment = player.addAttachment(plugin);
        attachments.put(player.getUniqueId(), attachment);

        Set<String> permissions = rankManager.resolvePermissions(data.getRank());
        permissions.addAll(data.getExtraPermissions());
        for (String permission : permissions) {
            setAttachmentPermission(attachment, permission);
        }

        player.recalculatePermissions();
        userManager.save();
        plugin.updateOwnTabName(player);
    }

    private void setAttachmentPermission(PermissionAttachment attachment, String permission) {
        attachment.setPermission(permission, true);

        if ("*".equals(permission)) {
            for (org.bukkit.permissions.Permission registered : Bukkit.getPluginManager().getPermissions()) {
                attachment.setPermission(registered.getName(), true);
            }
            return;
        }

        if (permission.endsWith(".*")) {
            String prefix = permission.substring(0, permission.length() - 1).toLowerCase(Locale.ROOT);
            for (org.bukkit.permissions.Permission registered : Bukkit.getPluginManager().getPermissions()) {
                if (registered.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    attachment.setPermission(registered.getName(), true);
                }
            }
        }
    }

    public void reloadOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            apply(player);
        }
    }

    public void remove(Player player) {
        PermissionAttachment attachment = attachments.remove(player.getUniqueId());
        if (attachment != null) {
            try {
                player.removeAttachment(attachment);
            } catch (IllegalArgumentException ignored) {
                // Bukkit can throw if another plugin already removed the attachment.
            }
        }
    }

    public boolean senderHas(CommandSender sender, String permission) {
        if (sender instanceof ConsoleCommandSender) {
            return true;
        }
        if (!(sender instanceof Player player)) {
            return sender.hasPermission(permission);
        }
        return player.isOp() || player.hasPermission(permission) || hasPermission(player, permission);
    }

    public boolean hasPermission(OfflinePlayer player, String permission) {
        UserData data = userManager.getOrCreate(player);
        for (String node : rankManager.resolvePermissions(data.getRank())) {
            if (matches(node, permission)) {
                return true;
            }
        }
        for (String node : data.getExtraPermissions()) {
            if (matches(node, permission)) {
                return true;
            }
        }
        return false;
    }

    public boolean canSetRank(CommandSender sender, String targetRankName) {
        if (sender instanceof ConsoleCommandSender) {
            return true;
        }
        if (!(sender instanceof Player player)) {
            return false;
        }
        if (player.isOp()) {
            return true;
        }

        UserData actor = userManager.getOrCreate(player);
        Rank actorRank = rankManager.getRank(actor.getRank());
        Rank targetRank = rankManager.getRank(targetRankName);
        if (actorRank == null || targetRank == null) {
            return false;
        }

        if ("inhaber".equals(targetRank.getName()) && !"inhaber".equals(actorRank.getName())) {
            return false;
        }
        if (!"inhaber".equals(actorRank.getName()) && targetRank.getPriority() <= actorRank.getPriority()) {
            return false;
        }

        for (String allowed : plugin.getConfig().getStringList("rank-set-rules." + actorRank.getName() + ".can-set")) {
            if ("*".equals(allowed) || allowed.equalsIgnoreCase(targetRank.getName())) {
                return true;
            }
        }
        return false;
    }

    public static boolean matches(String node, String requested) {
        if (node == null || requested == null) {
            return false;
        }
        String permission = node.toLowerCase(Locale.ROOT);
        String check = requested.toLowerCase(Locale.ROOT);
        if ("*".equals(permission) || permission.equals(check)) {
            return true;
        }
        if (permission.endsWith(".*")) {
            String prefix = permission.substring(0, permission.length() - 2);
            return check.equals(prefix) || check.startsWith(prefix + ".");
        }
        return false;
    }
}

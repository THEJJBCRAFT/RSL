package de.rsl.ranks.hook;

import de.rsl.ranks.RSLRanksPlugin;
import de.rsl.ranks.rank.Rank;
import de.rsl.ranks.user.UserData;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class PlaceholderHook extends PlaceholderExpansion {
    private final RSLRanksPlugin plugin;

    public PlaceholderHook(RSLRanksPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "rslranks";
    }

    @Override
    public @NotNull String getAuthor() {
        return "RedstoneLabs";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }

        UserData data = plugin.getUserManager().getOrCreate(player);
        Rank rank = plugin.getRankManager().getRank(data.getRank());
        if (rank == null) {
            return "";
        }

        return switch (params.toLowerCase(Locale.ROOT)) {
            case "rank" -> rank.getName();
            case "prefix" -> rank.getPrefix();
            case "priority" -> String.valueOf(rank.getPriority());
            case "color" -> rank.getColor();
            default -> "";
        };
    }
}
